var config = {
    map: {
        '*': {
            chosen: 'Amasty_ElasticSearch/js/chosen/chosen.jquery'
        }
    }
};
