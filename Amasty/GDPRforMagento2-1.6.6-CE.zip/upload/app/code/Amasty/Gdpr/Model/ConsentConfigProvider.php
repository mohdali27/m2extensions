<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_Gdpr
 */


namespace Amasty\Gdpr\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\UrlInterface;

class ConsentConfigProvider implements ConfigProviderInterface
{
    /**
     * @var Checkbox
     */
    private $checkbox;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var UrlInterface
     */
    private $url;

    public function __construct(
        Checkbox $checkbox,
        Config $config,
        UrlInterface $url
    ) {
        $this->checkbox = $checkbox;
        $this->config = $config;
        $this->url = $url;
    }

    /**
     * {@inheritdoc}
     */
    public function getConfig()
    {
        $agreements = [];

        $agreements['amastyGdprConsent'] = [
            'isEnabled'    => $this->checkbox->isEnabled(Checkbox::AREA_CHECKOUT),
            'isVisible'    => $this->checkbox->isVisible(Checkbox::AREA_CHECKOUT),
            'checkboxText' => $this->checkbox->getConsentText(),
            'visibleInCountries' => $this->config->isSetFlag('privacy_checkbox/eea_only')
                ? $this->config->getEEACountryCodes()
                : false,
            'textUrl' => $this->url->getUrl('gdpr/policy/policytext')
        ];

        return $agreements;
    }
}
