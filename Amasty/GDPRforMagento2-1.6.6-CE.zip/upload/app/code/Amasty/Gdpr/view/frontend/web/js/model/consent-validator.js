define(
    [
        'jquery',
        'mage/validation'
    ],
    function ($) {
        'use strict';
        var checkoutConfig = window.checkoutConfig,
            gdprConfig = checkoutConfig ? checkoutConfig.amastyGdprConsent : {};

        return {
            consentInputPath: 'div.amasty-gdpr-consent:visible input',

            /**
             * Validate checkout agreements
             *
             * @param {boolean} hideError
             * @returns {boolean}
             */
            validate: function (hideError) {
                var isValid = true,
                    consentInput;

                if (!gdprConfig.isEnabled) {
                    return true;
                }

                consentInput = $(this.consentInputPath);

                if (!consentInput.length) {
                    return true;
                }

                if (!$.validator.validateSingleElement(consentInput[0], {
                    errorElement: 'div',
                    errorClass: 'mage-error',
                    meta: 'validate',
                    hideError: Boolean(hideError),
                    errorPlacement: function (error, element) {
                        element.siblings('label').last().after(error);
                    }
                })) {
                    isValid = false;
                }

                return isValid;
            }
        };
    }
);
