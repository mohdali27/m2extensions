define(
    [
        'ko',
        'jquery',
        'uiComponent',
        'Magento_Checkout/js/model/quote'
    ],
    function (ko, $, Component, quote) {
        'use strict';
        var checkoutConfig = window.checkoutConfig,
            gdprConfig = checkoutConfig ? checkoutConfig.amastyGdprConsent : {};

        return Component.extend({
            defaults: {
                template: 'Amasty_Gdpr/checkout/gdpr-consent'
            },
            isVisible: ko.observable(gdprConfig.isVisible),
            checkboxText: gdprConfig.checkboxText,
            checkboxCount: 0,
            textUrl: gdprConfig.textUrl,

            initialize: function () {
                this._super();

                quote.billingAddress.subscribe(function (billingAddress) {
                    if (!billingAddress) {
                        return;
                    }
                    var country = billingAddress.countryId;

                    if (!country) {
                        return;
                    }

                    var isVisible = gdprConfig.isEnabled,
                        countryFilter = gdprConfig.visibleInCountries;

                    if (countryFilter) {
                        isVisible &= countryFilter.indexOf(country) !== -1;
                    }

                    this.isVisible(isVisible);
                }.bind(this));

                return this;
            },

            /**
             *
             * @return {string}
             */
            getId: function () {
                return 'amgdpr_agree_' + this.checkboxCount;
            },

            /**
             *
             * @return {string}
             */
            getNewId: function () {
                this.checkboxCount += 1;

                return 'amgdpr_agree_' + this.checkboxCount;
            },

            /**
             *
             * @return {string}
             */
            getTitle: function () {
                return $.mage.__('Accept privacy policy');
            },

            initModal: function (element) {
                var self = this;
                $(element).find('a').click(function (e) {
                    e.preventDefault();
                    $.ajax({
                        async: false,
                        url: self.textUrl,
                        success: function (data) {
                            $('#amprivacy-popup').html(data);
                        }
                    });
                    $('#amprivacy-popup').modal('openModal').on('modalclosed', function () {
                        $('#amprivacy-popup').html('');
                    });
                })
            }
        });
    }
);
