var config = {
    map: {
        '*': {
            'Magento_GoogleAnalytics/js/google-analytics':'Amasty_GdprCookie/js/google-analytics'
        }
    }
};
