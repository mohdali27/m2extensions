define([
    'uiComponent',
    'jquery',
    'mage/url',
    'mage/cookies'
], function (Component, $, urlBuilder) {
    'use strict';

    return Component.extend({
        defaults: {
            noticeType: 1,
            template: 'Amasty_GdprCookie/cookiebar',
            settingsLink: '/',
            allowLink: '/',
            websiteInteraction: '0',
            firstShowProcess: '0',
            cookiesName: [],
            domainName: ''
        },

        initialize: function () {
            this._super();

            this.analyticsCookie();

            return this;
        },

        initObservable: function () {
            this._super()
                .observe({
                    showDisallowButton: this.noticeType === 2
                });

            return this;
        },

        analyticsCookie: function () {
            var self = this,
                disallowedCookie = $.mage.cookies.get('amcookie_disallowed');

            if (!disallowedCookie) return;

            disallowedCookie.split(',').forEach(function (name) {
                self.deleteCookie(name);
            });
        },

        deleteCookie: function (name) {
              $.mage.cookies.set(name, '', {
                domain: location.host,
                expires: new Date('0')
            });
        },

        setupCookies: function () {
            location.href = urlBuilder.build(this.settingsLink);
        },

        allowCookies: function () {
            let self = this;
            $.ajax({
                showLoader: true,
                url: this.allowLink,
            }) .done(function () {
                $("#gdpr-cookie-block").remove();

                if (self.websiteInteraction == 1) {
                    self.restoreInteraction();
                }
            });
        },

        isShowNotificationBar: function () {
            if (this.noticeType === 0
                || $.mage.cookies.get('amcookie_allowed') !== null
                || !this.isNeedFirstShow()
            ) {
                return false;
            }
            this.blockInteraction();

            return true;
        },

        blockInteraction: function () {
            var cookie = $.mage.cookies.get('amcookie_allowed');

            if (cookie === null
                && this.websiteInteraction == 1
                && !$('.cms-cookie-policy').length
                && window.location.href + '/' !== this.settingsLink
            ) {
                $('.page-wrapper').css({
                    "pointer-events": "none",
                    "-webkit-user-select": "none",
                    "-moz-user-select": "none",
                    "-ms-user-select": "none",
                    "user-select": "none",
                    "height": "100%",
                    "overflow": "hidden",
                    "opacity": "0.1"
                });
            }
        },

        restoreInteraction: function () {
            if ($('.cms-cookie-policy').length === 0) {
                $('.page-wrapper').removeAttr('style');
            }
        },

        isNeedFirstShow: function () {
            if (this.firstShowProcess === "0") {
                return true
            }

            if (!localStorage.amCookieBarFirstShow) {
                localStorage.amCookieBarFirstShow = 1;
                return true;
            }

            return false;
        }
    });
});
