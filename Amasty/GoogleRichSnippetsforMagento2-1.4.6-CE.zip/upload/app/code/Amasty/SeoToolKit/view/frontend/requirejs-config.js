var config = {
    map: {
        '*': {
            'amSeoToolbar': 'Amasty_SeoToolKit/js/toolbar'
        }
    }
};
