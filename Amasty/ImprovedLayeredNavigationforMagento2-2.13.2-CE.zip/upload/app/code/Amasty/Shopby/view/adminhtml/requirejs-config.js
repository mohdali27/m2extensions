var config = {
    map: {
        '*': {
            amSearchOptions: 'Amasty_Shopby/js/search-options'
        }
    }
};