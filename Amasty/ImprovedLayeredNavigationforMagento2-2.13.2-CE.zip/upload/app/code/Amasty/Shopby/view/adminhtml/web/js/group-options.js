define(
    [
        'jquery',
        'underscore',
        'mage/translate',
        'mage/template',
        'jquery/ui'
    ], function (jQuery, _, $t, mageTemplate) {

    });