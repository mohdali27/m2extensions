[![Build Status](https://travis-ci.org/ebizmarts/magento2-mandrill.svg?branch=develop)](https://travis-ci.org/ebizmarts/magento2-mandrill)
# Mandrill service integration for Magento 2.

If you are running Magento 2.1.x use the 3.0 branch.
If you are running Magento 2.2.x use the 3.1 branch.
