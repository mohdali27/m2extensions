<?php
/**
 * Loadquote
 *
 * @copyright Copyright © 2017 Ebizmarts Corp.. All rights reserved.
 * @author    info@ebizmarts.com
 */

namespace Ebizmarts\MailChimp\Block;

use Magento\Framework\View\Element\Template;

class Loadquote extends Template
{
    /**
     * @var string $_template
     */
    protected $_template = "loadquote.phtml";

    // write your methods here...
}
