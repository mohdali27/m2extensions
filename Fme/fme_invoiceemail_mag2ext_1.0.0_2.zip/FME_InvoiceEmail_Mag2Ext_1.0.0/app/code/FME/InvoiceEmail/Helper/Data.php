<?php
/**
 *
 * @category : FME
 * @Package  : FME_InvoiceEmail
 * @Author   : FME Extensions <support@fmeextensions.com>
 * @copyright Copyright 2018 � fmeextensions.com All right reserved
 * @license https://fmeextensions.com/LICENSE.txt
 */
namespace FME\InvoiceEmail\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * ScopeConfig
     *
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;
    /**
     * @var \Magento\Customer\Model\Session
     */
    private $customerSession;
    /**
     * @var \Magento\Customer\Model\Customer
     */
    private $customerRepository;
        
    /**
     * Data constructor.
     *
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeInterface,
        \Magento\Customer\Model\Session\Proxy $customerSession,
        \Magento\Checkout\Model\Session\Proxy $checkoutSession,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Magento\Framework\Stdlib\DateTime\Timezone $timezone
    ) {
        $this->scopeConfig     = $scopeInterface;
        $this->customerSession = $customerSession;
        $this->checkoutSession = $checkoutSession;
        $this->timezone = $timezone;
        $this->date     = $date;
        $this->customerRepository = $customerRepository;
        parent::__construct($context);
    }
    
    /**
     * @param $config
     * @return mixed
     */
    public function getConfig($config)
    {
        return $this->scopeConfig->getValue(
            $config,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }//end getConfig()
    
    /**
     * @return void
     */
    public function showBreadcrumbs()
    {
        return $this->getConfig('invoiceemail/general/breadcrumbs');
    }//end setCoafFields()
    
    /**
     * @return boolean
     */
    public function getStatus()
    {
        return $this->getConfig('invoiceemail/general/active');
    }//end getConfig()

    /**
     * @return boolean
     */
    public function getOrder()
    {
        return $this->getConfig('invoiceemail/general/order');
    }//end getConfig()
    
    /**
     * @return boolean
     */
    public function getRegistrationStatus()
    {
        return $this->getConfig('invoiceemail/general/register');
    }//end getConfig()
    
    /**
     * @return boolean
     */
    public function getHeading()
    {
        return $this->getConfig('invoiceemail/general/heading');
    }//end getConfig()

    public function getSavedValue($customerId = null)
    {
        if ($customerId == null) {
            $customerId = $this->customerSession->getCustomer()->getId();
        }
        if ($customerId > 0) {
            $customer = $this->customerRepository->getById($customerId);
            if ($customer->getCustomAttribute('invoice_email')) {
                return $customer->getCustomAttribute('invoice_email')->getValue();
            }
        }
        return '';
    }
}
