<?php
/**
 * 
 */
namespace FME\InvoiceEmail\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Save checkout fields with quote shipping address.
 *
 */
class SaveInvoiceEmailToOrderObserver implements ObserverInterface
{
    private $quoteRepository;
    /**
     * @var \FME\InvoiceEmail\Helper\Data
     */
    private $helper;
    /**
     * @var \Magento\Checkout\Model\Session
     */
    private $checkoutSession;

    /**
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfiguration
     */
    public function __construct(
        \Magento\Quote\Model\QuoteRepository $quoteRepository,
        \Magento\Checkout\Model\Session\Proxy $checkoutSession,
        \FME\InvoiceEmail\Helper\Data $helper
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->checkoutSession = $checkoutSession;
        $this->helper          = $helper;
    }
    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $order = $observer->getOrder();
        $quote = $observer->getQuote();
        /** @var \Magento\Quote\Model\Quote $quote */
        if ($quote->getCustomerInvoiceEmail() != "") {
            $quote->setInvoiceEmail($quote->getCustomerInvoiceEmail());
        }
        if ($quote->getInvoiceEmail() != "") {
            $order->setInvoiceEmail($quote->getInvoiceEmail());
        }
        return $this;
    }
}
