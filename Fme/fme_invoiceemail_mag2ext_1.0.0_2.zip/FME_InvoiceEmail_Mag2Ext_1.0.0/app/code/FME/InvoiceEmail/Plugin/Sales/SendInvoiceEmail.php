<?php
/**
 *
 * @category : FME
 * @Package  : FME_InvoiceEmail
 * @Author   : FME Extensions <support@fmeextensions.com>
 * @copyright Copyright 2018 � fmeextensions.com All right reserved
 * @license https://fmeextensions.com/LICENSE.txt
 */

namespace FME\InvoiceEmail\Plugin\Sales;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Mail\Template\TransportBuilderByStore;
use Magento\Sales\Model\Order\Email\Container\IdentityInterface;
use Magento\Sales\Model\Order\Email\Container\Template;

class SendInvoiceEmail extends \Magento\Sales\Model\Order\Email\SenderBuilder
{
    
    /**
     * @var \FME\InvoiceEmail\Helper\Data
     */
    private $helper;

    /**
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfiguration
     */
    public function __construct(
        \FME\InvoiceEmail\Helper\Data $helper
    ) {
        $this->helper          = $helper;
    }
    
    public function aroundSend(
        \Magento\Sales\Model\Order\Email\SenderBuilder $subject,
        \Closure $proceed
    ) {
        $subject->configureEmailTemplate();

        $subject->transportBuilder->addTo(
            $subject->identityContainer->getCustomerEmail(),
            $subject->identityContainer->getCustomerName()
        );

        $copyTo = $subject->identityContainer->getEmailCopyTo();

        if (!empty($copyTo) && $subject->identityContainer->getCopyMethod() == 'bcc') {
            foreach ($copyTo as $email) {
                $subject->transportBuilder->addBcc($email);
            }
        }

        $vars = $subject->templateContainer->getTemplateVars();
        if ($this->helper->getOrder() && isset($vars['order'])) {
            $order = $vars['order'];
            if ($order->getInvoiceEmail() != "" && filter_var($order->getInvoiceEmail(), FILTER_VALIDATE_EMAIL)) {
                $subject->transportBuilder->addBcc($order->getInvoiceEmail());
            }
        } else if (isset($vars['invoice']) && $this->helper->getStatus()) {
            $order = $vars['order'];
            if ($order->getInvoiceEmail() != "" && filter_var($order->getInvoiceEmail(), FILTER_VALIDATE_EMAIL)) {
                $subject->transportBuilder->addBcc($order->getInvoiceEmail());
            }
        }
        $transport = $subject->transportBuilder->getTransport();
        $transport->sendMessage();
    }
}
