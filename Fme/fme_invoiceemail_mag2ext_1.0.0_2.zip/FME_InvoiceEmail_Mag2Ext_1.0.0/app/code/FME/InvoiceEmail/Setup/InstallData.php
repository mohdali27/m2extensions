<?php
/**
 *
 * @category : FME
 * @Package  : FME_InvoiceEmail
 * @Author   : FME Extensions <support@fmeextensions.com>
 * @copyright Copyright 2018 © fmeextensions.com All right reserved
 * @license https://fmeextensions.com/LICENSE.txt
 */

namespace FME\InvoiceEmail\Setup;

use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Customer\Model\Customer;
use Magento\Eav\Model\Entity\Attribute\Set as AttributeSet;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface
{
    protected $customerSetupFactory;
    private $attributeSetFactory;

    public function __construct(CustomerSetupFactory $customerSetupFactory, AttributeSetFactory $attributeSetFactory) {
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeSetFactory = $attributeSetFactory;
    }

    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context) {

        $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);

        $customerEntity = $customerSetup->getEavConfig()->getEntityType('customer');
        $attributeSetId = $customerEntity->getDefaultAttributeSetId();

        $attributeSet = $this->attributeSetFactory->create();
        $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);

        $customerSetup->addAttribute(
            \Magento\Customer\Model\Customer::ENTITY,
            'invoice_email',
            [
                'type'         => 'varchar',
                'label'        => 'Invoice Email',
                'input'        => 'text',
                'frontend_class' => 'validate-email',
                'validate_rules' => '{"input_validation":"email"}',
                'required'     => false,
                'visible'      => true,
                'user_defined' => true,
                'sort_order' => 101,
                'position' => 101,
                'system' => false,
                'adminhtml_only' => true,
            ]
        );
        $invoiceAttribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY, 'invoice_email')
            ->addData([
                'attribute_set_id' => $attributeSetId,
                'attribute_group_id' => $attributeGroupId,
                'used_in_forms' => [
                    'adminhtml_checkout',
                    'adminhtml_customer',
                    'customer_account_edit',
                    'customer_account_create'
                ]
            ]);
        $invoiceAttribute->save();
    }
}
