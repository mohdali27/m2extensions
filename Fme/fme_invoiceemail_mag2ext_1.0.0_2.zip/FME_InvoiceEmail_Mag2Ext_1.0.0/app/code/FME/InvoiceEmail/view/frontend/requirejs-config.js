/**
 *
 * @category : FME
 * @Package  : FME_InvoiceEmail
 * @Author   : FME Extensions <support@fmeextensions.com>
 * @copyright Copyright 2018 � fmeextensions.com All right reserved
 * @license https://fmeextensions.com/LICENSE.txt
 */
var config = {
  config: {
    mixins: {
      'Magento_Checkout/js/action/place-order': {
        'FME_InvoiceEmail/js/action/place-order-mixin': true
      },
      'Magento_Checkout/js/view/payment': {
        'FME_InvoiceEmail/js/view/payment-mixin': true
      }
    }
  }
};
