/**
 *
 * @category : FME
 * @Package  : FME_InvoiceEmail
 * @Author   : FME Extensions <support@fmeextensions.com>
 * @copyright Copyright 2018 � fmeextensions.com All right reserved
 * @license https://fmeextensions.com/LICENSE.txt
 */
/*global define*/
define([
    'ko',
    'Magento_Ui/js/form/form',
    'underscore',
    'Magento_Checkout/js/model/quote',
    'Magento_Customer/js/model/customer'
], function (
    ko,
    Component,
    _,
    quote,
    customer
) {
    'use strict';
    return Component.extend({
        defaults: {
            template: 'FME_InvoiceEmail/invoice-checkout-form'
        },
        isVisible: ko.observable(true),
        isCustomerLoggedIn: customer.isLoggedIn,
        initialize: function () {
            this._super();
            // component initialization logic
            return this;
        },
        /**
         * Form submit handler
         *
         * This method can have any name.
         */
        onSubmit: function () {
            // trigger form validation
            this.source.set('params.invalid', false);
            this.source.trigger('invoice.data.validate');
            
            // verify that form data is valid
            if (!this.source.get('params.invalid')) {
                // data is retrieved from data provider by value of the customScope property
                var formData = this.source.get('invoice_email');
                // do something with form data
                var billingAddress = quote.billingAddress();
                
                if (billingAddress.customAttributes === undefined) {
                    billingAddress.customAttributes = {};
                }
                if (billingAddress.extensionAttributes === undefined) {
                    billingAddress.extensionAttributes = {};
                }
                if (billingAddress.extensionAttributes.invoice_email === undefined) {
                    billingAddress.extensionAttributes.invoice_email = '';
                }
                if (billingAddress.customAttributes.invoice_email === undefined) {
                    billingAddress.customAttributes.invoice_email = '';
                }

                billingAddress.extensionAttributes.invoice_email =  formData;
                billingAddress.customAttributes.invoice_email = formData;
            }
        }
    });
});
