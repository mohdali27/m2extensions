<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\Downloads\Block\Order;

use Magento\Store\Model\Store;

class EmailAttachments extends \MageWorx\Downloads\Block\AttachmentContainer
{
    /**
     * Get current product id
     *
     * @return null|int
     */
    public function getProductId()
    {
        $productId = null;

        if ($this->getParentBlock()) {
            $item = $this->getParentBlock()->getItem();
            if ($item) {
                $productId = $item->getProduct()->getId();
            }
        }

        return $productId;
    }

    /**
     * Retrieve array of attachment object that allow for view
     *
     * @return array
     */
    public function getAttachments()
    {
        $attachments = [];

        if (!$this->helperData->isAddToNewOrderEmail()) {
            return $attachments;
        }
        $collection = $this->getAttachmentCollection();

        if (!$collection) {
            return $attachments;
        }

        foreach ($collection->getItems() as $item) {
            if (!$this->isAllowByCount($item)) {
                continue;
            }

            $item->setIsInGroup(1);

            $attachments[] = $item;
        }

        return $attachments;
    }

    /**
     * @return \MageWorx\Downloads\Model\ResourceModel\Attachment\Collection|bool
     */
    public function getAttachmentCollection()
    {
        $productId       = $this->getProductId();
        $customerGroupId = $this->getCustomerGroupId();
        $storeId         = $this->getOrderStoreId();

        if ($productId === null || $customerGroupId === null || $storeId === null) {
            return false;
        }

        $collection = $this->attachmentCollectionFactory->create();
        $collection->getAttachmentsForEmail(
            $this->getProductId(),
            $this->getCustomerGroupId(),
            $this->getOrderStoreId()
        );

        return $collection;
    }

    /**
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->helperData->getProductDownloadsTitle();
    }

    /**
     * Get customer group id
     *
     * @return int|null
     */
    protected function getCustomerGroupId()
    {
        if ($itemsBlock = $this->getLayout()->getBlock('items')) {
            if ($order = $itemsBlock->getOrder()) {
                return $order->getCustomerGroupId();
            }
        }

        return null;
    }

    /**
     * @return int|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function getOrderStoreId()
    {
        if ($itemsBlock = $this->getLayout()->getBlock('items')) {
            if ($order = $itemsBlock->getOrder()) {
                return $order->getStoreId();
            }
        }

        return null;
    }
}