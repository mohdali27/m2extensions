<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\Downloads\Controller\Adminhtml\Attachment;

use MageWorx\Downloads\Controller\Adminhtml\Attachment\Products as AttachmentProductsController;

class Productsgrid extends AttachmentProductsController
{

}
