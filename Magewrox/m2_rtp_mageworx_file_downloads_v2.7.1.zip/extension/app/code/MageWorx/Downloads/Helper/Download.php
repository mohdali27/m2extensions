<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\Downloads\Helper;

class Download extends \Magento\Downloadable\Helper\Download
{
    
}
