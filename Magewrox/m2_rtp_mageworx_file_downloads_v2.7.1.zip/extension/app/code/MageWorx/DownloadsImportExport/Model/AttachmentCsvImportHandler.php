<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\DownloadsImportExport\Model;

use MageWorx\Downloads\Model\ResourceModel\Section;
use MageWorx\Downloads\Model\ResourceModel\Section\CollectionFactory;
use MageWorx\Downloads\Model\Attachment\Source\IsActive;
use MageWorx\DownloadsImportExport\Model\Attachment\Link as FileLinkModel;

class AttachmentCsvImportHandler
{
    /**
     * CSV Processor
     *
     * @var \Magento\Framework\File\Csv
     */
    protected $csvProcessor;

    /**
     * @var \Magento\Framework\Escaper
     */
    protected $escaper;

    /**
     * @var IsActive
     */
    protected $attachmentStatusOptions;

    /**
     * @var CollectionFactory
     */
    protected $sectionCollectionFactory;

    /**
     * @var \MageWorx\Downloads\Model\ResourceModel\Section\Collection
     */
    protected $sectionCollection;

    /**
     * @var \MageWorx\Downloads\Model\AttachmentFactory
     */
    protected $attachmentFactory;

    /**
     * @var \MageWorx\Downloads\Model\ResourceModel\Attachment
     */
    protected $attachmentResource;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product
     */
    protected $productResource;

    /**
     * @var FileLinkModel
     */
    protected $fileLinkModel;

    /**
     * @var \Magento\Customer\Model\ResourceModel\Group\CollectionFactory
     */
    protected $customerGroupCollectionFactory;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $eventManager;

    /**
     * @var array
     */
    protected $missedFileNames = [];

    /**
     * @var bool
     */
    protected $isSkipMissedProducts;

    /**
     * @var bool
     */
    protected $isSkipMissedFiles;

    /**
     * AttachmentCsvImportHandler constructor.
     *
     * @param IsActive $sectionStatusOptions
     * @param CollectionFactory $sectionCollectionFactory
     * @param \MageWorx\Downloads\Model\AttachmentFactory $attachmentFactory
     * @param FileLinkModel $fileLinkModel
     * @param \MageWorx\Downloads\Model\ResourceModel\Attachment $attachmentResource
     * @param \Magento\Catalog\Model\ResourceModel\Product $productResource
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Customer\Model\ResourceModel\Group\CollectionFactory $customerGroupCollectionFactory
     * @param Copy $copyModel
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Framework\Escaper $escaper
     * @param \Magento\Framework\File\Csv $csvProcessor
     */
    public function __construct(
        \MageWorx\Downloads\Model\Attachment\Source\IsActive $sectionStatusOptions,
        \MageWorx\Downloads\Model\ResourceModel\Section\CollectionFactory $sectionCollectionFactory,
        \MageWorx\Downloads\Model\AttachmentFactory $attachmentFactory,
        \MageWorx\DownloadsImportExport\Model\Attachment\Link $fileLinkModel,
        \MageWorx\Downloads\Model\ResourceModel\Attachment $attachmentResource,
        \Magento\Catalog\Model\ResourceModel\Product $productResource,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\ResourceModel\Group\CollectionFactory $customerGroupCollectionFactory,
        \MageWorx\DownloadsImportExport\Model\Copy $copyModel,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\Escaper $escaper,
        \Magento\Framework\File\Csv $csvProcessor
    ) {
        $this->attachmentStatusOptions = $sectionStatusOptions;
        $this->sectionCollectionFactory = $sectionCollectionFactory;
        $this->attachmentFactory = $attachmentFactory;
        $this->fileLinkModel = $fileLinkModel;
        $this->attachmentResource = $attachmentResource;
        $this->productResource = $productResource;
        $this->storeManager = $storeManager;
        $this->customerGroupCollectionFactory = $customerGroupCollectionFactory;
        $this->copyModel = $copyModel;
        $this->eventManager = $eventManager;
        $this->escaper = $escaper;
        $this->csvProcessor = $csvProcessor;
    }

    /**
     * @param array $file file info retrieved from $_FILES array
     * @param bool $isSkipMissedProducts
     * @param bool $isSkipMissedFiles
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function importFromCsvFile($file, $isSkipMissedProducts = false, $isSkipMissedFiles = false)
    {
        if (!isset($file['tmp_name'])) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Invalid file upload attempt.'));
        }
        $data = $this->csvProcessor->getData($file['tmp_name']);

        if (count($data) < 2) {
            throw new \Magento\Framework\Exception\LocalizedException(
                __('Data for import not found.')
            );
        }

        $this->isSkipMissedProducts = $isSkipMissedProducts;
        $this->isSkipMissedFiles = $isSkipMissedFiles;

        array_shift($data);
        array_walk_recursive($data, [$this, 'trim']);

        $validatedData = $this->getValidatedData($data);
        $this->import($validatedData);
    }

    /**
     * @param string $item
     * @param string $key
     */
    protected function trim(
        &$item,
        $key
    ) {
        $item = trim($item);
    }

    /**
     * @param array $data
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function getValidatedData(array $data)
    {
        $formattedData = $this->validateByDataFormat($data);
        $validatedData = $this->validateByDataValues($formattedData);

        return $validatedData;
    }

    /**
     * Validate and format data
     *
     * @param array $data
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function validateByDataFormat(array $data)
    {
        $formattedData = [];

        foreach ($data as $rowIndex => $dataRow) {

            if (!array_key_exists(0, $dataRow) || $dataRow[0] === '') {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __('Missed section name (title) in line %1', $rowIndex + 2)
                );
            }

            if ((!array_key_exists(2, $dataRow) || $dataRow[2] === '')
                && (!array_key_exists(3, $dataRow) || $dataRow[3] === '')
            ) {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __("File path and URL can't be empty at same time - see line %1", $rowIndex + 2)
                );
            }

            if (array_key_exists(2, $dataRow) && $dataRow[2] && array_key_exists(3, $dataRow) && $dataRow[3]) {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __("File path and URL can't be set at same time - see line %1", $rowIndex + 2)
                );
            }

            if (!array_key_exists(6, $dataRow) || $dataRow[6] === '') {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __('Missed customer group(s) in line %1', $rowIndex + 2)
                );
            }

            if (!array_key_exists(7, $dataRow) || $dataRow[7] === '') {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __('Missed store code(s) in line %1', $rowIndex + 2)
                );
            }

            if (array_key_exists(8, $dataRow) && $dataRow[8] !== '' && !is_numeric($dataRow[8])) {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __('Incorrect downloads limit in line %1', $rowIndex + 2)
                );
            }

            $statusOptions = array_map(
                'strval',
                array_column($this->attachmentStatusOptions->toOptionArray(), 'value')
            );

            if (!array_key_exists(9, $dataRow) || !in_array($dataRow[9], $statusOptions)) {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __('Missed or incorrect status in line %1', $rowIndex + 2)
                );
            }

            $formattedData[$rowIndex] = [
                'section_name'    => $dataRow[0],
                'name'            => $dataRow[1],
                'filepath'        => $dataRow[2],
                'url'             => $dataRow[3],
                'description'     => $dataRow[4],
                'product_skus'    => $dataRow[5],
                'customer_groups' => $dataRow[6],
                'store_codes'     => $dataRow[7],
                'downloads_limit' => $dataRow[8],
                'status'          => $dataRow[9],
            ];
        }

        return $formattedData;
    }

    /**
     * Validate and prepare data
     *
     * @param array $data
     * @return mixed
     */
    protected function validateByDataValues($data)
    {
        $this->validateByProducts($data);
        $this->validateBySection($data);
        $this->validateByStores($data);
        $this->validateByCustomerGroups($data);
        $this->validateByFilePath($data);

        return $data;
    }

    /**
     * @param array $data
     */
    protected function validateByProducts(array &$data)
    {
        $requestedSkus = [];
        foreach ($data as $key => $datum) {
            $requestedSkus = array_merge($requestedSkus, explode('|||', $datum['product_skus']));
        }

        $requestedSkus = array_filter($requestedSkus);

        $idSkuPairs = $this->productResource->getProductsIdsBySkus($requestedSkus);

        $missedSkus = array_diff($requestedSkus, array_flip($idSkuPairs));

        if (!$this->isSkipMissedProducts && $missedSkus) {
            throw new \Magento\Framework\Exception\LocalizedException(
                __(
                    'The requested product SKUs are not found: %1.',
                    $this->escaper->escapeHtml(implode(', ', $missedSkus))
                )
            );
        }

        foreach ($data as $key => $datum) {
            $datumProductSkus = explode('|||', $datum['product_skus']);
            $data[$key]['valid_product_ids'] = array_intersect_key($idSkuPairs, array_flip($datumProductSkus));
        }
    }

    /**
     * @param array $data
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function validateBySection(array &$data)
    {
        $missedSection = [];

        foreach ($data as $key => $datum) {
            $section = $this->getSectionIdByName($datum['section_name']);

            if (!$section) {
                $missedSection[] = $datum['section_name'];
                continue;
            }
            $data[$key]['section_id'] = $section->getId();
        }

        $missedSection = array_unique($missedSection);

        if ($missedSection) {
            throw new \Magento\Framework\Exception\LocalizedException(
                __(
                    'The requested sections are not found: %1.',
                    $this->escaper->escapeHtml(implode(', ', $missedSection))
                )
            );
        }
    }

    /**
     * @param array $data
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function validateByStores(array &$data)
    {
        $storeCodeIdPairs = [];

        foreach ($this->storeManager->getStores(true, true) as $storeCode => $store) {
            $storeCodeIdPairs[$storeCode] = (string)$store->getId();
        }
        $missedStoreCodes = [];

        foreach ($data as $key => $datum) {

            $datumStoreCodes = explode('|||', $datum['store_codes']);

            foreach ($datumStoreCodes as $datumKey => $storeCode) {

                if ($storeCode === 'all') {
                    $data[$key]['valid_store_ids'] = ['admin' => $storeCodeIdPairs['admin']];
                }
                elseif (array_key_exists($storeCode, $storeCodeIdPairs)) {
                    $data[$key]['valid_store_ids'][$storeCode] = $storeCodeIdPairs[$storeCode];
                }
                else {
                    $missedStoreCodes[$storeCode] = $storeCode;
                }
            }
        }

        if ($missedStoreCodes) {
            throw new \Magento\Framework\Exception\LocalizedException(
                __(
                    'The requested store codes are not found: %1.',
                    $this->escaper->escapeHtml(implode(', ', $missedStoreCodes))
                )
            );
        }
    }

    /**
     * @param array $data
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function validateByFilePath(array &$data)
    {
        $missedFiles = [];

        foreach ($data as $datum) {
            $shortFilePathWithName = $datum['filepath'];

            if (!$shortFilePathWithName) {
                continue;
            }
            $oldFullPath = $this->fileLinkModel->getImportDir() . DIRECTORY_SEPARATOR . $shortFilePathWithName;

            if (!file_exists($oldFullPath)) {
                $missedFiles[] = $oldFullPath;
            }
        }

        if ($missedFiles && !$this->isSkipMissedFiles) {
            throw new \Magento\Framework\Exception\LocalizedException(
                __(
                    'The requested file names are not found: %1.',
                    $this->escaper->escapeHtml(implode(', ', $missedFiles))
                )
            );
        }

        $this->missedFileNames = $missedFiles;
    }

    /**
     * @param array $data
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function validateByCustomerGroups(array &$data)
    {
        $groupNameIdPairs = [];

        /** @var \Magento\Customer\Model\ResourceModel\Group\Collection $group */
        $customerGroupCollection = $this->customerGroupCollectionFactory->create();

        /** @var \Magento\Customer\Model\Group $group */
        foreach ($customerGroupCollection as $group) {
            $groupNameIdPairs[$group->getCode()] = $group->getId();
        }

        $missedGroupCodes = [];

        foreach ($data as $key => $datum) {

            $datumGroupCodes = explode('|||', $datum['customer_groups']);

            foreach ($datumGroupCodes as $datumKey => $groupCode) {

                if ($groupCode === 'all') {
                    $data[$key]['valid_customer_group_ids'] = $groupNameIdPairs;
                }
                elseif (array_key_exists($groupCode, $groupNameIdPairs)) {
                    $data[$key]['valid_customer_group_ids'][$groupCode] = $groupNameIdPairs[$groupCode];
                }
                else {
                    $missedGroupCodes[$groupCode] = $groupCode;
                }
            }
        }

        if ($missedGroupCodes) {
            throw new \Magento\Framework\Exception\LocalizedException(
                __(
                    'The requested customer groups are not found: %1.',
                    $this->escaper->escapeHtml(implode(', ', $missedGroupCodes))
                )
            );
        }
    }

    /**
     * @param array $data
     * @throws \Exception
     */
    protected function import(array $data)
    {
        foreach ($data as $datum) {

            /** @var \MageWorx\Downloads\Model\Attachment $attachment */
            $attachment = $this->attachmentFactory->create();
            $attachment
                ->setSectionId($datum['section_id'])
                ->setName($datum['name'])
                ->setDescription($datum['description'])
                ->setAssignType(\MageWorx\Downloads\Model\Attachment\Source\AssignType::ASSIGN_BY_IDS)
                ->setProductsData($datum['valid_product_ids'])
                ->setCustomerGroupIds($datum['valid_customer_group_ids'])
                ->setStores($datum['valid_store_ids'])
                ->setDownloadsLimit($datum['downloads_limit'])
                ->setIsActive($datum['status']);

            if ($datum['url']) {
                $name = $datum['name'] ? $datum['name'] : $datum['url'];
                $attachment->setName($name);
                $attachment->setContentType(\MageWorx\Downloads\Model\Attachment\Source\ContentType::CONTENT_URL);
                $attachment->setUrl($datum['url']);
            }
            else {
                $shortFilePathWithName = $datum['filepath'];
                $oldFullPath = $this->fileLinkModel->getImportDir() . DIRECTORY_SEPARATOR . $shortFilePathWithName;

                if (in_array($oldFullPath, $this->missedFileNames)) {
                    continue;
                }

                $attachment->setContentType(\MageWorx\Downloads\Model\Attachment\Source\ContentType::CONTENT_FILE);
                $this->uploadFile($attachment, $datum);
            }

            $this->eventManager->dispatch(
                'mageworx_downloads_attachment_prepare_save',
                ['attachment' => $attachment]
            );

            $this->attachmentResource->save($attachment);
        }
    }

    /**
     * @param \MageWorx\Downloads\Model\Attachment $attachment
     * @param array $datum
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function uploadFile($attachment, $datum)
    {
        $shortFilePathWithName = $datum['filepath'];
        $fileName = pathinfo($shortFilePathWithName, PATHINFO_BASENAME);
        $oldFullPath = $this->fileLinkModel->getImportDir() . DIRECTORY_SEPARATOR . $shortFilePathWithName;

        $data = [
            'multifile' => [
                'name'     => $fileName,
                'tmp_name' => $oldFullPath,
            ],
        ];

        $copiedFileData = $this->copyModel->copyFileAndGetName($this->fileLinkModel->getBaseDir(), $data);

        if (!$attachment->getName()) {
            $attachment->setName($copiedFileData['name']);
        }

        $attachment->setRealname([$copiedFileData['name']]);
        $attachment->setMultifile([$copiedFileData['file']]);
        $attachment->setFilename($copiedFileData['file']);
        $attachment->setType(substr($copiedFileData['file'], strrpos($copiedFileData['file'], '.') + 1));
        $attachment->setSize(filesize($copiedFileData['path'] . $copiedFileData['file']));
        $attachment->setUrl('');
    }

    /**
     * @param string $name
     * @return \Magento\Framework\DataObject|null
     */
    protected function getSectionIdByName($name)
    {
        if ($this->sectionCollection === null) {
            $this->sectionCollection = $this->sectionCollectionFactory->create()->load();
        }

        return $this->sectionCollection->getItemByСaseInsensitiveColumnValue('name', $name);
    }
}