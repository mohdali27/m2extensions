<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\DownloadsImportExport\Model;

use MageWorx\Downloads\Model\ResourceModel\Section;
use MageWorx\Downloads\Model\ResourceModel\Section\CollectionFactory;
use MageWorx\Downloads\Model\Section\Source\IsActive;

class SectionCsvImportHandler
{
    /**
     * CSV Processor
     *
     * @var \Magento\Framework\File\Csv
     */
    protected $csvProcessor;

    /**
     * @var \Magento\Framework\Escaper
     */
    protected $escaper;

    /**
     * @var \Magento\Framework\DataObjectFactory
     */
    protected $dataObjectFactory;

    /**
     * @var IsActive
     */
    protected $sectionStatusOptions;

    /**
     * @var CollectionFactory
     */
    protected $sectionCollectionFactory;

    /**
     * @var \MageWorx\Downloads\Model\ResourceModel\Section\Collection
     */
    protected $sectionCollection;

    /**
     * SectionCsvImportHandler constructor.
     *
     * @param IsActive $sectionStatusOptions
     * @param CollectionFactory $sectionCollectionFactory
     * @param Section $sectionResource
     * @param \Magento\Framework\Escaper $escaper
     * @param \Magento\Framework\File\Csv $csvProcessor
     * @param \Magento\Framework\DataObjectFactory $dataObjectFactory
     */
    public function __construct(
        \MageWorx\Downloads\Model\Section\Source\IsActive $sectionStatusOptions,
        \MageWorx\Downloads\Model\ResourceModel\Section\CollectionFactory $sectionCollectionFactory,
        \MageWorx\Downloads\Model\ResourceModel\Section $sectionResource,
        \Magento\Framework\Escaper $escaper,
        \Magento\Framework\File\Csv $csvProcessor,
        \Magento\Framework\DataObjectFactory $dataObjectFactory
    ) {
        $this->sectionStatusOptions = $sectionStatusOptions;
        $this->sectionCollectionFactory = $sectionCollectionFactory;
        $this->sectionResource = $sectionResource;
        $this->escaper = $escaper;
        $this->csvProcessor = $csvProcessor;
        $this->dataObjectFactory = $dataObjectFactory;
    }

    /**
     * @param array $file file info retrieved from $_FILES array
     * @throws \Exception
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function importFromCsvFile($file)
    {
        if (!isset($file['tmp_name'])) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Invalid file upload attempt.'));
        }
        $data = $this->csvProcessor->getData($file['tmp_name']);

        if (count($data) < 3) {
            throw new \Magento\Framework\Exception\LocalizedException(
                __('Data for import not found.')
            );
        }

        array_shift($data);
        array_walk_recursive($data, [$this, 'trim']);

        $validatedData = $this->getValidatedData($data);
        $this->import($validatedData);
    }

    /**
     * @param string $item
     * @param string $key
     */
    protected function trim(
        &$item,
        $key
    ) {
        $item = trim($item);
    }

    /**
     * @param array $data
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function getValidatedData(array $data)
    {
        $uniqueArray = [];

        foreach ($data as $rowIndex => $dataRow) {

            if (!array_key_exists(0, $dataRow) || $dataRow[0] === '') {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __('Missed section name (title) in line %1', $rowIndex + 2)
                );
            }

            $statusOptions = array_map(
                'strval',
                array_column($this->sectionStatusOptions->toOptionArray(), 'value')
            );

            if (!array_key_exists(2, $dataRow) || !in_array($dataRow[2], $statusOptions)) {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __('Invalid status value in line %1', $rowIndex + 2)
                );
            }

            $uniqueKey = strtolower($dataRow[0]);

            if (\array_key_exists($uniqueKey, $uniqueArray)) {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __("Duplicate row (same section's name) was found in line %1", $rowIndex + 2)
                );
            }

            $uniqueArray[$uniqueKey] = [
                'name'        => $dataRow[0],
                'description' => $dataRow[1],
                'status'      => $dataRow[2],
            ];
        }

//        echo "<pre>"; var_dump($uniqueArray); exit;

        return $uniqueArray;
    }

    /**
     * @param array $data
     * @throws \Exception
     */
    protected function import(array $data)
    {
        if ($data) {

            $this->sectionCollection = $this->sectionCollectionFactory->create()->load();

            foreach ($data as $uniqKey => $datum) {

                $presentSection = $this->sectionCollection->getItemByСaseInsensitiveColumnValue('name', $datum['name']);

                if ($presentSection) {
                    $presentSection->setDescription($datum['description']);
                    $presentSection->setIsActive($datum['status']);
                    $this->sectionResource->save($presentSection);
                    continue;
                }

                $section = $this->sectionCollection->getNewEmptyItem();
                $section->setName($datum['name']);
                $section->setDescription($datum['description']);
                $section->setIsActive($datum['status']);

                $this->sectionResource->save($section);
            }
        }
    }
}