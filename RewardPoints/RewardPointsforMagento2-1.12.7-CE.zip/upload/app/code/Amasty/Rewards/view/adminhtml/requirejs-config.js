var config = {
    map: {
        '*': {
            newPointsDialog:  'Amasty_Rewards/js/add-points-dialog'
        }
    }
};