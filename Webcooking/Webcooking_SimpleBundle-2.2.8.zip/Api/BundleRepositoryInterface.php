<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * CMS bundle CRUD interface.
 * @api
 */
interface BundleRepositoryInterface
{
    /**
     * Save bundle.
     *
     * @param \Webcooking\SimpleBundle\Api\Data\BundleInterface $bundle
     * @return \Webcooking\SimpleBundle\Api\Data\BundleInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(Data\BundleInterface $bundle);

    /**
     * Retrieve bundle.
     *
     * @param int $bundleId
     * @return \Webcooking\SimpleBundle\Api\Data\BundleInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($bundleId);

    /**
     * Retrieve bundles matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Webcooking\SimpleBundle\Api\Data\BundleSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    /**
     * Delete bundle.
     *
     * @param \Webcooking\SimpleBundle\Api\Data\BundleInterface $bundle
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(Data\BundleInterface $bundle);

    /**
     * Delete bundle by ID.
     *
     * @param int $bundleId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($bundleId);
}
