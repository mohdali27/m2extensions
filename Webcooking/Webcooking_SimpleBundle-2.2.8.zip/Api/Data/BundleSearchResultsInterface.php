<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface for tag search results.
 * @api
 */
interface BundleSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get blocks list.
     *
     * @return \Webcooking\SimpleBundle\Api\Data\BundleInterface[]
     */
    public function getItems();

    /**
     * Set blocks list.
     *
     * @param \Webcooking\SimpleBundle\Api\Data\BundleInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
