<?php

/**
 * Vincent Enjalbert
 *
 * Version Française :
 * *****************************************************************************
 *
 * Notification de la Licence
 *
 * Ce fichier source est sujet au CLUF
 * qui est fourni avec ce module dans le fichier LICENSE-FR.txt.
 * Il est également disponible sur le web à l'adresse suivante:
 * http://www.web-cooking.net/licences/magento/LICENSE-FR.txt
 *
 * =============================================================================
 *        NOTIFICATION SUR L'UTILISATION DE L'EDITION MAGENTO
 * =============================================================================
 * Ce module est conçu pour l'édition COMMUNITY de Magento
 * WebCooking ne garantit pas le fonctionnement correct de cette extension
 * sur une autre édition de Magento excepté l'édition COMMUNITY de Magento.
 * WebCooking ne fournit pas de support d'extension en cas
 * d'utilisation incorrecte de l'édition.
 * =============================================================================
 *
 * English Version :
 * *****************************************************************************
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE-EN.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.web-cooking.net/licences/magento/LICENSE-EN.txt
 *
 * =============================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =============================================================================
 * This package designed for Magento COMMUNITY edition
 * WebCooking does not guarantee correct work of this extension
 * on any other Magento edition except Magento COMMUNITY edition.
 * WebCooking does not provide extension support in case of
 * incorrect edition usage.
 * =============================================================================
 *
 * @category   Webcooking
 * @package    Webcooking_SimpleBundle
 * @copyright  Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert
 * @license    http://www.web-cooking.net/licences/magento/LICENSE-EN.txt
 */

namespace Webcooking\SimpleBundle\Api\Data;

interface TemplateInterface
{

    
    
    //FIELDS
    const TEMPLATE_ID = 'template_id';
    const IS_ACTIVE = 'is_active';
    const POSITION = 'position';
    const BASE_QTY = 'base_qty';
    const TEMPLATE_NAME = 'template_name';
    const BUNDLE_NAME = 'bundle_name';
    const DISCOUNT_TYPE = 'discount_type';
    const DISCOUNT_AMOUNT = 'discount_amount';
    const STORE_IDS = 'store_ids';
    const EXCLUDE_BASE_PRODUCT_FROM_DISCOUNT = 'exclude_base_product_from_discount';
    const SPECIAL_PRICE_BEHAVIOR = 'special_price_behavior';
    const CONDITIONS_SERIALIZED = 'conditions_serialized';
    const RULE_STATUS = 'rule_status';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
   
    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Get Active
     *
     * @return bool
     */
    public function getIsActive();

    /**
     * Get Bundle Name
     *
     * @return string
     */
    public function getBundleName();

    /**
     * Get Template Name
     *
     * @return string
     */
    public function getTemplateName();

    /**
     * Get Position
     *
     * @return int
     */
    public function getPosition();

    /**
     * Get Base Qty
     *
     * @return int
     */
    public function getBaseQty();

    /**
     * Get Store Ids
     *
     * @return string
     */
    public function getStoreIds();

    /**
     * Get Discount Type
     *
     * @return string
     */
    public function getDiscountType();

    /**
     * Get Discount Amount
     *
     * @return double
     */
    public function getDiscountAmount();

    /**
     * Is base product excluded from discount calculation ?
     *
     * @return bool
     */
    public function getExcludeBaseProductFromDiscount();

    /**
     * Get Speical Price Behavior
     *
     * @return double
     */
    public function getSpecialPriceBehavior();

    /**
     * Get Conditions Serialized
     *
     * @return string
     */
    public function getConditionsSerialized();

    /**
     * Get Rule Status
     *
     * @return int
     */
    public function getRuleStatus();

    /**
     * Get Created At
     *
     * @return string
     */
    public function getCreatedAt();

    /**
     * Get Updated At
     *
     * @return string
     */
    public function getUpdatedAt();

    /**
     * Set ID
     *
     * @param int $id
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setId($id);

    /**
     * Set Is Active
     *
     * @param bool $flag
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setIsActive($flag);

    /**
     * Set Bundle Name
     *
     * @param string $name
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setBundleName($name);

    /**
     * Set Template Name
     *
     * @param string $name
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setTemplateName($name);

   

    /**
     * Set Position
     *
     * @param int $position
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setPosition($position);

    /**
     * Set Base Qty
     *
     * @param int $qty
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setBaseQty($qty);

    /**
     * Set Discount Type
     *
     * @param string $discountType
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setDiscountType($discountType);

    /**
     * Set Discount Amount
     *
     * @param double $discountAmount
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setDiscountAmount($discountAmount);

    /**
     * Set Exclude base product from discount
     *
     * @param bool $flag
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setExcludeBaseProductFromDiscount($flag);

    /**
     * Set Special Price Behavior
     *
     * @param int $specialPriceBehavior
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setSpecialPriceBehavior($specialPriceBehavior);

    /**
     * Set Store Ids
     *
     * @param int $storeIds
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setStoreIds($storeIds);

    /**
     * Set Conditions Serialized
     *
     * @param int $conditionsSerialized
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setConditionsSerialized($conditionsSerialized);

    /**
     * Set Rule Status
     *
     * @param int $ruleStatus
     * @return Webcooking\SimpleBundle\Api\Data\BundleInterface
     */
    public function setRuleStatus($ruleStatus);
}
