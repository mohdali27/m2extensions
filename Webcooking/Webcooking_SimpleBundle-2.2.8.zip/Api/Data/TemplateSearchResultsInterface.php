<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface for tag search results.
 * @api
 */
interface TemplateSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get blocks list.
     *
     * @return \Webcooking\SimpleBundle\Api\Data\TemplateInterface[]
     */
    public function getItems();

    /**
     * Set blocks list.
     *
     * @param \Webcooking\SimpleBundle\Api\Data\TemplateInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
