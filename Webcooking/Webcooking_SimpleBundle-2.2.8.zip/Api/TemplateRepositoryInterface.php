<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Template CRUD interface.
 * @api
 */
interface TemplateRepositoryInterface
{
    /**
     * Save template.
     *
     * @param \Webcooking\SimpleBundle\Api\Data\TemplateInterface $template
     * @return \Webcooking\SimpleBundle\Api\Data\TemplateInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(Data\TemplateInterface $template);

    /**
     * Retrieve template.
     *
     * @param int $templateId
     * @return \Webcooking\SimpleBundle\Api\Data\TemplateInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($templateId);

    /**
     * Retrieve templates matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Webcooking\SimpleBundle\Api\Data\TemplateSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    /**
     * Delete template.
     *
     * @param \Webcooking\SimpleBundle\Api\Data\TemplateInterface $template
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(Data\TemplateInterface $template);

    /**
     * Delete template by ID.
     *
     * @param int $templateId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($templateId);
}
