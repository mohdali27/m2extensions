<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */
namespace Webcooking\SimpleBundle\Block\Adminhtml\Template;

use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;
use Webcooking\All\Block\Adminhtml\Edit\GenericButton;

/**
 * Class SaveAndContinueButton
 */
class ApplyRuleButton extends GenericButton implements ButtonProviderInterface
{

  public function getButtonData()
    {
        $data = [
            'label' => __('Apply Rule'),
            'on_click' => sprintf("location.href = '%s';", $this->getApplyRuleUrl()),
            'class' => 'add',
            'sort_order' => 40,
        ];
        return $data;
    }

    /**
     * Retrieve the Url for creating an order.
     *
     * @return string
     */
    public function getApplyRuleUrl()
    {
        return $this->getUrl('simplebundle/template/apply', ['template_id' => $this->registry->registry('simplebundle_template')->getId()]);
    }
}
