<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Block\Adminhtml\Template\Rule;

class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    
    
    
    protected $_status;
    
    protected $_productFactory;
    
    protected $_coreRegistry;

    /**
     * @var \Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory]
     */
    protected $_setsFactory;
    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Magento\Catalog\Model\Product\Attribute\Source\Status $status,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Eav\Model\ResourceModel\Entity\Attribute\Set\CollectionFactory $setsFactory,
        array $data = []
    ) {
        $this->_setsFactory = $setsFactory;
        $this->_productFactory = $productFactory;
        $this->_coreRegistry = $coreRegistry;
        $this->_status = $status;
        parent::__construct($context, $backendHelper, $data);
    }
    
     /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('template_rule_result_product_grid');
        $this->setDefaultSort('id');
        $this->setUseAjax(true);
    }
    
    
       

    /**
     * @return array|null
     */
    public function getTemplateObject()
    {
        return $this->_coreRegistry->registry('simplebundle_template');
    }
 
      protected function _prepareCollection()
    {
        $collection = $this->getTemplateObject()->getProductCollectionMatchingRule(true);
        $collection
            ->addAttributeToSelect('name')
            ->addAttributeToSelect('sku')
            ->addAttributeToSelect('url_key')
            ->addAttributeToSelect('price')
            ->addAttributeToSelect('attribute_set_id');
        
       
//echo $collection->getSelect();
        
        $this->setCollection($collection);

        return parent::_prepareCollection();
    }
    
    
    protected function _prepareColumns()
    {
        
        $this->addColumn('id', array(
            'header'    => __('ID'),
            'sortable'  => true,
            'width'     => '60px',
            'index'     => 'entity_id'
        ));
        $this->addColumn('product_name', array(
            'header'    => __('Product Name'),
            'index'     => 'name',
        ));

        $sets = $this->_setsFactory->create()->setEntityTypeFilter(
            $this->_productFactory->create()->getResource()->getTypeId()
        )->load()->toOptionHash();

        $this->addColumn('set_name',
            array(
                'header'=> __('Attrib. Set Name'),
                'width' => '100px',
                'index' => 'attribute_set_id',
                'type'  => 'options',
                'options' => $sets,
        ));

        $this->addColumn('product_sku', array(
            'header'    => __('SKU'),
            'width'     => '80px',
            'index'     => 'sku',
            'column_css_class'=> 'sku'
        ));
        $this->addColumn('product_price', array(
            'header'    => __('Price'),
            'align'     => 'center',
            'type'      => 'currency',
            'currency_code' => $this->getStore()->getCurrentCurrencyCode(),
            'rate'      => $this->getStore()->getBaseCurrency()->getRate($this->getStore()->getCurrentCurrencyCode()),
            'index'     => 'price'
        ));
        
         $this->addColumn('status', array(
            'header'    => __('Status'),
            'width'     => 90,
            'index'     => 'status',
            'type'      => 'options',
            'options'   => $this->_status->getOptionArray(),
        ));
        
         $this->addColumn('has_template', array(
            'header'    => __('Template associated'),
            'width'     => 90,
            'index'     => 'has_template',
            'type'      => 'options',
            'options'   => array(
                '0' => __('Not yet'),
                '1' => __('Yes'),
            ),
             'filter' => false,
            'frame_callback' => array($this, 'decorateHasTemplate')
        ));
        
        return parent::_prepareColumns();
    }
    
    
      public function decorateHasTemplate($value, $row, $column, $isExport)
    {
        if($row->getHasTemplate() == 1) {
            $value = '<span class="grid-severity-notice"><span>' . $value . '</span></span>';
        } else {
            $value = '<span class="grid-severity-critical"><span>' . $value . '</span></span>';
        }
        return $value;
    } 

    public function getGridUrl()
    {
        return $this->getUrl('adminhtml/simplebundle_template_rule/resultgrid', array('template_id'=>$this->getTemplateId()));
    }


    public function getStore()
    {
        return $this->_storeManager->getStore();
    }
    
    public function getTemplateId() {
        return $this->getTemplateObject()->getId();
    }
}
