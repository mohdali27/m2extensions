<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Block\Catalog\Product\View;

class Bundle extends \Webcooking\All\Block\Template
{
    protected $_coreRegistry;
    protected $_bundleCollectionFactory;
    protected $_imageBuilder;
    protected $_helper;
    
    public function __construct(
            \Magento\Framework\View\Element\Template\Context $context,
            \Magento\Framework\Registry $registry,
            \Magento\Catalog\Block\Product\ImageBuilder $imageBuilder,
            \Webcooking\SimpleBundle\Model\ResourceModel\Bundle\CollectionFactory $bundleCollectionFactory,
            \Webcooking\SimpleBundle\Helper\Data $helper,
            \Magento\Checkout\Helper\Cart $cartHelper,
            array $data = []
    ) {
        $this->_coreRegistry = $registry;
        $this->_imageBuilder = $imageBuilder;
        $this->_bundleCollectionFactory = $bundleCollectionFactory;
        $this->_helper = $helper;
        $this->_cartHelper = $cartHelper;
        parent::__construct(
                $context, $data
        );
    }
    
    public function getCartHelper() {
        return $this->_cartHelper;
    }
    
    
   public function getProduct() {
       if(!$this->getData('product'))
           $this->setData('product', $this->_coreRegistry->registry('product') ? $this->_coreRegistry->registry('product') : $this->_coreRegistry->registry('current_product'));
       return $this->getData('product');
   }
    
   public function getBundles() {
       if(!$this->getProduct()) {
           return [];
       }
       $bundleCollection = $this->_bundleCollectionFactory->create();
       $bundleCollection->addFieldToFilter('is_active', 1)
                        ->addFieldToFilter('product_id', $this->getProduct()->getId())
                        ->addStoreFilter($this->getWebcookingHelper()->getCurrentStoreId());
        if($this->getLimit() && is_int($this->getLimit())) {
            $bundleCollection->setPageSize($this->getLimit());
        }
        $bundleCollection->appendSelections();
       
        return $bundleCollection;
   }
   
   public function getAddToCartUrl($bundle) {
       return $this->getUrl('simplebundle/cart/add', ['_secure' => $this->getRequest()->isSecure(), '_query'=>['selection'=>intval($bundle->getId())]]);
   }
   
   public function getUpdatePricesUrl() {
       return $this->getUrl('simplebundle/cart/priceupdate');
   }
   
   public function getPopupAjaxUrl($bundle) {
       return $this->getUrl('simplebundle/cart/addtocartpopup', ['_secure' => $this->getRequest()->isSecure(), 'bundle_id'=>intval($bundle->getId())]);
   }
   
   public function getAddToCartViaPopupUrl($bundle) {
       return $this->getUrl('simplebundle/cart/addfrompopup', ['_secure' => $this->getRequest()->isSecure(), 'bundle_id'=>intval($bundle->getId())]);
   }
   
    public function getImage($product, $imageId, $attributes = [])
    {
        return $this->_imageBuilder->setProduct($product)
            ->setImageId($imageId)
            ->setAttributes($attributes)
            ->create();
    }
  
   
   protected function _toHtml() {
       if(!$this->getProduct()) {
           return '';
       }
       return parent::_toHtml();
   }
    
}
