<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Block\Catalog\Product\View\Bundle;


use Webcooking\SimpleBundle\Block\Catalog\Product\View\Bundle;

class Popup extends Bundle
{
    
    protected function _createProductInfoBlock($product) {
        $productInfoBlock = $this->getLayout()->createBlock('Webcooking\SimpleBundle\Block\Catalog\Product\View\Bundle\Popup\Product');
        $productInfoBlock->setTemplate('Webcooking_SimpleBundle::product/view/bundle/popup/product.phtml');
        
        $optionsBlock = $this->getLayout()->createBlock('Magento\Framework\View\Element\Template');
        
        $productViewBlock = $this->getLayout()->createBlock('Magento\Catalog\Block\Product\View');
        $productViewBlock->setTemplate('product/view/options/wrapper.phtml');
        
        $productViewOptionsBlock = $this->getLayout()->createBlock('Magento\Catalog\Block\Product\View\Options');
        $productViewOptionsBlock->setTemplate('product/view/options.phtml');
        
        $productViewOptionsTypeDefaultBlock = $this->getLayout()->createBlock('Magento\Catalog\Block\Product\View\Options\Type\DefaultType');
        $productViewOptionsTypeDefaultBlock->setTemplate('product/view/options/type/default.phtml');
        $productViewOptionsTypeTextBlock = $this->getLayout()->createBlock('Magento\Catalog\Block\Product\View\Options\Type\Text');
        $productViewOptionsTypeTextBlock->setTemplate('product/view/options/type/text.phtml');
        $productViewOptionsTypeFileBlock = $this->getLayout()->createBlock('Magento\Catalog\Block\Product\View\Options\Type\File');
        $productViewOptionsTypeFileBlock->setTemplate('product/view/options/type/file.phtml');
        $productViewOptionsTypeSelectBlock = $this->getLayout()->createBlock('Magento\Catalog\Block\Product\View\Options\Type\Select');
        $productViewOptionsTypeSelectBlock->setTemplate('product/view/options/type/select.phtml');
        $productViewOptionsTypeDateBlock = $this->getLayout()->createBlock('Magento\Catalog\Block\Product\View\Options\Type\Date');
        $productViewOptionsTypeDateBlock->setTemplate('product/view/options/type/date.phtml');
        
        
        
        $productViewCalendarBlock = $this->getLayout()->createBlock('Magento\Framework\View\Element\Html\Calendar');
        $productViewCalendarBlock->setTemplate('Magento_Theme::js/calendar.phtml');
        
        $productViewOptionsBlock->setChild('default', $productViewOptionsTypeDefaultBlock);
        $productViewOptionsBlock->setChild('text', $productViewOptionsTypeTextBlock);
        $productViewOptionsBlock->setChild('file', $productViewOptionsTypeFileBlock);
        $productViewOptionsBlock->setChild('select', $productViewOptionsTypeSelectBlock);
        $productViewOptionsBlock->setChild('date', $productViewOptionsTypeDateBlock);
        $productViewBlock->setChild('product_options', $productViewOptionsBlock);
        $productViewBlock->setChild('html_calendar', $productViewCalendarBlock);
        $optionsBlock->setChild('product_options_wrapper', $productViewBlock);
        $productInfoBlock->setChild('options_container', $optionsBlock);
        
        $this->getLayout()->addContainer($productInfoBlock->getNameInLayout().'.product.info.type', 'Product Type', [], $productInfoBlock->getNameInLayout());
        
        
        if($product->getTypeId() == 'configurable') {
            $configurableOptionsBlock = $this->getLayout()->createBlock('Magento\ConfigurableProduct\Block\Product\View\Type\Configurable');
            $configurableOptionsBlock->setTemplate('Webcooking_SimpleBundle::product/view/bundle/popup/product/type/options/configurable.phtml');
            $productViewBlock->setChild('options_configurable', $configurableOptionsBlock);
            
            $configurableInfoBlock = $this->getLayout()->createBlock('Magento\ConfigurableProduct\Block\Product\View\Type\Configurable');
            $configurableInfoBlock->setTemplate('Magento_Catalog::product/view/type/default.phtml');
            $configurableInfoBlock->insert($productInfoBlock->getNameInLayout().'.product.info.type', 0, true, 'product.info.configurable.extra');
            
            $this->getLayout()->addContainer($productInfoBlock->getNameInLayout().'.product.info.configurable.extra', 'Product Extra Info', [], $productInfoBlock->getNameInLayout().'.product.info.type');
                    
            $configurableExtraContainerBlock = $this->getLayout()->createBlock('Magento\ConfigurableProduct\Block\Stockqty\Type\Configurable');
            $configurableExtraContainerBlock->setTemplate('Magento_CatalogInventory::stockqty/composite.phtml');
            $configurableExtraContainerBlock->insert($productInfoBlock->getNameInLayout().'.product.info.configurable.extra', 0, true, 'product_type_data_extra');
        }
        
        if($product->getTypeId() == 'bundle') {
            $bundleOptionsBlock = $this->getLayout()->createBlock('Magento\Bundle\Block\Catalog\Product\View\Type\Bundle');
            $bundleOptionsBlock->setTemplate('catalog/product/view/type/bundle/options.phtml');
            
            $bundleOptionSelectBlock = $this->getLayout()->createBlock('Magento\Bundle\Block\Catalog\Product\View\Type\Bundle\Option\Select');
            $bundleOptionMultiBlock = $this->getLayout()->createBlock('Magento\Bundle\Block\Catalog\Product\View\Type\Bundle\Option\Multi');
            $bundleOptionRadioBlock = $this->getLayout()->createBlock('Magento\Bundle\Block\Catalog\Product\View\Type\Bundle\Option\Radio');
            $bundleOptionCheckboxBlock = $this->getLayout()->createBlock('Magento\Bundle\Block\Catalog\Product\View\Type\Bundle\Option\Checkbox');
            
            
            $bundleOptionsBlock->setChild('select', $bundleOptionSelectBlock);
            $bundleOptionsBlock->setChild('multi', $bundleOptionMultiBlock);
            $bundleOptionsBlock->setChild('radio', $bundleOptionRadioBlock);
            $bundleOptionsBlock->setChild('checkbox', $bundleOptionCheckboxBlock);
            $productViewBlock->setChild('type_bundle_options', $bundleOptionsBlock);
           
            /*
             * 
           
        <referenceBlock name="product.info.form.options">
            <container name="bundle.product.options.wrapper" htmlTag="div" htmlClass="bundle-options-wrapper" after="product.info.form.options" />
        </referenceBlock> 
        <move element="product.info.options.wrapper" destination="bundle.product.options.wrapper" before="-" />
        <move element="product.info.options.wrapper.bottom" destination="bundle.product.options.wrapper" after="product.info.options.wrapper" />
        <move element="product.price.tier" destination="product.info.options.wrapper.bottom" before="-" />
        <referenceBlock name="product.info.options.wrapper.bottom">
            <block class="Magento\CatalogInventory\Block\Qtyincrements" name="product.info.qtyincrements" before="-" template="qtyincrements.phtml"/>
            <action method="unsetChild">
                <argument name="block" xsi:type="string">product.info.addtocart</argument>
            </action>
            <action method="setHideRequiredNotice">
                <argument name="flag" xsi:type="string">1</argument>
            </action>
            <action method="unsetChild">
                <argument name="block" xsi:type="string">product.info.addto</argument>
            </action>
        </referenceBlock>
        <referenceContainer name="content">
            <container name="bundle.options.container" htmlTag="div" htmlClass="bundle-options-container" after="product.info.media"/>
        </referenceContainer>
        <referenceContainer name="product.info.type">
            <block class="Magento\Bundle\Block\Catalog\Product\View\Type\Bundle" name="product.info.bundle" as="product_type_data" template="catalog/product/view/type/bundle.phtml"/>
            <container name="product.info.bundle.extra" after="product.info.bundle" as="product_type_data_extra" label="Product Extra Info"/>
        </referenceContainer>
        <referenceContainer name="product.info.main">
            <block class="Magento\Catalog\Block\Product\View" name="customize.button" as="customize_button" template="Magento_Bundle::catalog/product/view/customize.phtml" after="product.info.price" />
        </referenceContainer>
        */
        }
        
          
        
        
        return $productInfoBlock;
    }
    
    public function getProductInfosHtml() {
        $_selections = $this->getBundle()->getAssociatedProducts(); 
        $html = '';
        $productInfoBlock = $this->_createProductInfoBlock($this->getBundle()->getMainProduct());
        $productInfoBlock->setProductId($this->getBundle()->getMainProduct()->getId())->setSelectionQty($this->getBundle()->getBaseQty())->setIsEven(0);
        $html .= $productInfoBlock->toHtml();
        $i=0;
        foreach ($_selections as $_selection) {
            $productInfoBlock = $this->_createProductInfoBlock($_selection['product']);
            $productInfoBlock->setProductId($_selection['product']->getId())->setSelectionQty($_selection['qty'])->setIsEven($i%2==0);
            $html .= $productInfoBlock->toHtml();
            if($this->_helper->productNeedsConfiguration($_selection['product']) || $this->_helper->displayAllProductsInPopup()) {
                $i++;
            }
         }
         return $html;
    }
    
        
   protected function _toHtml() {
       return \Webcooking\All\Block\Template::_toHtml();
   }
    
}
