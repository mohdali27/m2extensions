<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Block\Catalog\Product\View\Bundle\Popup;



class Product extends \Magento\Catalog\Block\Product\View
{
 
    protected $_helper;
    
    public function __construct(
        \Magento\Catalog\Block\Product\Context $context,
        \Magento\Framework\Url\EncoderInterface $urlEncoder,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder,
        \Magento\Framework\Stdlib\StringUtils $string,
        \Magento\Catalog\Helper\Product $productHelper,
        \Magento\Catalog\Model\ProductTypes\ConfigInterface $productTypeConfig,
        \Magento\Framework\Locale\FormatInterface $localeFormat,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency,
        \Webcooking\SimpleBundle\Helper\Data $helper,
        array $data = []
    ) {
        $this->_helper = $helper;
        parent::__construct(
                $context, $urlEncoder, $jsonEncoder, $string, $productHelper, $productTypeConfig, $localeFormat, $customerSession, $productRepository, $priceCurrency, $data
        );
    }
    
    public function getHelper() {
        return $this->_helper;
    }
    
    public function setProductId($productId) {
        $this->setData('product_id', $productId);
        if($this->_coreRegistry->registry('product')) $this->_coreRegistry->unregister('product');
        $this->_coreRegistry->register('product', $this->productRepository->getById(intval($this->getProductId())));
        if($this->_coreRegistry->registry('current_product')) $this->_coreRegistry->unregister('current_product');
        $this->_coreRegistry->register('current_product', $this->_coreRegistry->registry('product'));
        return $this;
    }
    
    protected function _toHtml() {
        $html = parent::_toHtml();
        $html = $this->_helper->distinguishVariables($html, $this->getProduct()->getId());
        return $html;
    }
    
}
