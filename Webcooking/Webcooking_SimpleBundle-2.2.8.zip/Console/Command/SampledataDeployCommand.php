<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Framework\ObjectManagerInterface;

/**
 * Command for deployment of Sample Data
 */
class SampledataDeployCommand extends Command
{
     private $objectManager;

            
    public function __construct(
         ObjectManagerInterface $objectManager,
         $name=null
    ) {
        $this->objectManager = $objectManager;
        parent::__construct($name);
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this->setName('simplebundle:sampledata:deploy')
            ->setDescription('Deploy sample data for simple bundle');
        parent::configure();
    }

    /**
     * {@inheritdoc}
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->objectManager->get('\Magento\Framework\App\State')->setAreaCode('adminhtml');
         
        $connection->query("INSERT INTO `simple_bundle` (`simple_bundle_id`, `is_active`, `generated_by_rule`, `template_id`, `product_id`, `position`, `base_qty`, `bundle_name`, `discount_type`, `discount_amount`, `store_ids`, `exclude_base_product_from_discount`, `special_price_behavior`, `slave_products_info`, `created_at`, `updated_at`)
VALUES
	(1,1,0,1,1,1,1,'With Water Bottle','fixed',5.0000,'0',0,3,'24-UG06 / Affirm Water Bottle  / Qty : 1','2017-03-25 09:26:55','2017-03-25 10:40:14'),
	(2,1,0,1,4,1,1,'With Water Bottle','fixed',5.0000,'0',0,3,'24-UG06 / Affirm Water Bottle  / Qty : 1','2017-03-25 09:26:55','2017-03-25 10:40:14'),
	(3,1,0,1,8,1,1,'With Water Bottle','fixed',5.0000,NULL,0,3,'24-UG06 / Affirm Water Bottle  / Qty : 1','2017-03-25 09:26:55','2017-03-25 10:40:14'),
	(4,1,0,1,14,1,1,'With Water Bottle','fixed',5.0000,NULL,0,3,'24-UG06 / Affirm Water Bottle  / Qty : 1','2017-03-25 09:26:55','2017-03-25 10:40:14'),
	(5,1,0,0,4,2,1,NULL,'percent',10.0000,'0',1,1,'24-UG07 / Dual Handle Cardio Ball / Qty : 2 | 24-UG04 / Zing Jump Rope / Qty : 1','2017-03-25 10:25:40','2017-03-25 10:38:24'),
	(6,1,0,0,4,3,1,'Example with configurable and bundle products','percent',10.0000,'0',0,2,NULL,'2017-03-25 10:38:24','2017-03-25 10:38:24');");
        $connection->query("INSERT INTO `simple_bundle_item` (`simple_bundle_item_id`, `simple_bundle_id`, `product_id`, `selection_qty`, `position`)
VALUES
	(1,1,15,1,1),
	(2,2,15,1,1),
	(3,3,15,1,1),
	(4,4,15,1,1),
	(6,5,16,2,1),
	(7,5,17,1,2),
	(8,6,51,1,1),
	(9,6,67,1,2);");

        $connection->query("INSERT INTO `simple_bundle_template` (`template_id`, `is_active`, `position`, `base_qty`, `template_name`, `bundle_name`, `discount_type`, `discount_amount`, `store_ids`, `exclude_base_product_from_discount`, `special_price_behavior`, `conditions_serialized`, `rule_status`, `slave_products_info`, `created_at`, `updated_at`)
VALUES
	(1,1,1,1,'Water Bottle','With Water Bottle','fixed',5.0000,'1',0,3,NULL,NULL,'24-UG06 / Affirm Water Bottle  / Qty : 1','2017-03-25 09:26:54','2017-03-25 10:40:14');");
        $connection->query("INSERT INTO `simple_bundle_template_item` (`template_item_id`, `template_id`, `product_id`, `selection_qty`, `position`)
VALUES
	(1,1,15,2,1);");
    }
}
