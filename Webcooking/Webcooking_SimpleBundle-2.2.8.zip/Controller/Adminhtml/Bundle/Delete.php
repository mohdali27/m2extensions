<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Bundle;

use Magento\Backend\App\Action\Context;

class Delete extends \Magento\Backend\App\Action
{
    
    protected $bundleFactory;

    /**
     * @param Context $context
     * @param BundleFactory $bundleFactory
     */
    public function __construct(
        Context $context,
        \Webcooking\SimpleBundle\Model\BundleFactory $bundleFactory
    ) {
        $this->bundleFactory = $bundleFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        
        $bundle = $this->bundleFactory->create()->load($this->getRequest()->getParam('simple_bundle_id'));
        $bundle->delete();
        
        $this->messageManager->addSuccess(
            __('Bundle has been deleted.')
        );
        
        return $resultRedirect->setPath('*/*/');
    }

}
