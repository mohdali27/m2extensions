<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Bundle;


use Magento\Framework\App\Filesystem\DirectoryList;

class Export extends \Magento\Backend\App\Action
{

    protected $_bundleCollectionFactory;
    protected $_fileFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Webcooking\SimpleBundle\Model\ResourceModel\Bundle\CollectionFactory $bundleCollectionFactory
     * @param \Magento\Framework\App\Response\Http\FileFactory $fileFactory
     */
    public function __construct(
    \Magento\Backend\App\Action\Context $context,
    \Webcooking\SimpleBundle\Model\ResourceModel\Bundle\CollectionFactory $bundleCollectionFactory,
    \Magento\Framework\App\Response\Http\FileFactory $fileFactory
    ) {
        $this->_bundleCollectionFactory = $bundleCollectionFactory;
        $this->_fileFactory = $fileFactory;
        parent::__construct($context);
    }

    protected function _isAllowed() {

        return $this->_authorization->isAllowed('Webcooking_SimpleBundle::simplebundle');
    }

    /**
     * Index action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute() {
        $fileName = 'simple-bundles-' . date('Y-m-d--H-i-s') . '.csv';
        $content = '';
        $handle = fopen('php://temp', 'w+');
        $bundleCollection = $this->_bundleCollectionFactory->create();
        $bundleCollection
                ->skipAllChecks()
                ->joinMasterProduct()
                ->appendSelections();
        fputcsv($handle, $this->_getExportHeaders(), ';');
        foreach($bundleCollection as $bundle) {
            $row = [];
            $row[] = $bundle->getId();
            $row[] = $bundle->getTemplateId();
            $row[] = $bundle->getBundleName();
            $row[] = $bundle->getStoreIds();
            $row[] = $bundle->getIsActive();
            $row[] = $bundle->getSku();
            $row[] = $bundle->getBaseQty();
            $row[] = $bundle->getDiscountAmount();
            $row[] = $bundle->getDiscountType();
            $row[] = $bundle->getExcludeBaseProductFromDiscount();
            $row[] = $bundle->getSpecialPriceBehavior();
            $row[] = $bundle->getPosition();
            $cpt = 0;
            foreach($bundle->getBundleItems() as $bundleItem) {
                $row[] = $bundleItem->getSimpleBundleItemId();
                $row[] = $bundleItem->getSku();
                $row[] = $bundleItem->getSelectionQty();
                $row[] = $bundleItem->getPosition();
                $cpt++;
            }
            for($i=$cpt; $i<50; $i++) {
                $row[] = '';
                $row[] = '';
                $row[] = '';
                $row[] = '';
            }
            fputcsv($handle, $row, ';');
        }
        rewind($handle);
        $content = stream_get_contents($handle);
        fclose($handle);
        return $this->_fileFactory->create($fileName, $content, DirectoryList::VAR_DIR);
    }
    
    
    protected function _getExportHeaders() {
        $row = [];
        $row[] = 'simple_bundle_id';
        $row[] = 'template_id';
        $row[] = 'bundle_name';
        $row[] = 'stores';
        $row[] = 'is_active';
        $row[] = 'sku';
        $row[] = 'base_qty';
        $row[] = 'discount_amount';
        $row[] = 'discount_type';
        $row[] = 'exclude_base_product_from_discount';
        $row[] = 'special_price_behavior';
        $row[] = 'position';
        for($i=0; $i<50; $i++) {
            $row[] = 'simple_bundle_item_id_'.($i+1);
            $row[] = 'simple_bundle_item_sku_'.($i+1);
            $row[] = 'simple_bundle_item_qty_'.($i+1);
            $row[] = 'simple_bundle_item_position_'.($i+1);
        }
        return $row;
    }

}
