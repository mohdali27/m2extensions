<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Bundle;


use Magento\Framework\App\Filesystem\DirectoryList;

class Import extends \Magento\Backend\App\Action
{

    protected $_bundleFactory;
    protected $_bundleItemFactory;
    protected $_resultPageFactory;
    protected $_productResource;
    protected $_helper;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Webcooking\SimpleBundle\Model\ResourceModel\Bundle\CollectionFactory $bundleCollectionFactory
     * @param \Magento\Framework\App\Response\Http\FileFactory $fileFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Webcooking\SimpleBundle\Model\BundleFactory $bundleFactory,
        \Webcooking\SimpleBundle\Model\BundleItemFactory $bundleItemFactory,
        \Webcooking\SimpleBundle\Helper\Data $helper,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Catalog\Model\ResourceModel\Product $productResource
    ) {
        $this->_bundleFactory = $bundleFactory;
        $this->_bundleItemFactory = $bundleItemFactory;
        $this->_resultPageFactory = $resultPageFactory;
        $this->_productResource = $productResource;
        $this->_helper = $helper;
        parent::__construct($context);
    }

    protected function _isAllowed() {

        return $this->_authorization->isAllowed('Webcooking_SimpleBundle::simplebundle');
    }

    /**
     * Index action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute() {
        $data = $this->getRequest()->getPostValue();
        if (isset($data) && !empty($data)) {
            if (!$_FILES['simplebundle_import']['tmp_name']) {
                $this->messageManager->addError(
                        __('No file found.'));
                $this->_redirect('*/*/');
                return;
            }

            $handle = fopen($_FILES['simplebundle_import']['tmp_name'], 'r');

            $entetes = $fileData = fgetcsv($handle, null, ";");
            if (!$this->_checkEntetes($entetes)) {
                $this->messageManager->addError(
                        __('File columns are not correct.'));
                $this->_redirect('*/*/');
                return;
            }
            $cpt = 0;
            $cptSuccess = 0;
            while (($fileData = fgetcsv($handle, null, ";")) !== FALSE) {
                $cpt++;
                $fileData = array_combine($entetes, $fileData);

                $fileData = $this->_parseImportDataLine($fileData);
                if ($fileData) {

                    $bundle = $this->_bundleFactory->create();
                    if (isset($fileData['simple_bundle_id']) && $fileData['simple_bundle_id']) { //update
                        $bundle->load((int)$fileData['simple_bundle_id']);
                    } else {
                        $bundle->setCreatedAt(date('Y-m-d H:i:s'));
                    }
                    $bundle->setUpdatedAt(date('Y-m-d H:i:s'));
                    unset($fileData['simple_bundle_id']);
                    unset($fileData['id']); //just in case..

                    foreach ($fileData as $key => $val) {
                        $bundle->setData($key, $val);
                    }
                    $bundle->save();
                    for ($i = 1; $i <= 100; $i++) {
                        if (isset($fileData['simple_bundle_item_sku_' . $i]) && $fileData['simple_bundle_item_sku_' . $i]) {
                            $bundleItem = $this->_bundleItemFactory->create();
                            if (isset($fileData['simple_bundle_item_id_' . $i]) && $fileData['simple_bundle_item_id_' . $i]) {
                                $bundleItem->load((int)$fileData['simple_bundle_item_id_' . $i]);
                                if ($bundleItem->getSimpleBundleId() != $bundle->getSimpleBundleId()) {
                                    $this->messageManager->addError(__('Simple Bundle Item #%1 does not match Simple Bundle #%2', $fileData['simple_bundle_item_id_' . $i], $bundle->getSimpleBundleId()));
                                    continue;
                                }
                            } else {
                                $bundleItem->setSimpleBundleId($bundle->getId());
                            }
                            
                            $bundleItem->setData('product_id', $fileData['simple_bundle_item_product_id_' . $i]);
                            $bundleItem->setData('selection_qty', $fileData['simple_bundle_item_qty_' . $i]);
                            $bundleItem->setData('position', $fileData['simple_bundle_item_position_' . $i]);
                            $bundleItem->save();
                        }
                    }
                    $cptSuccess++;
                }
            }
            $this->messageManager->addSuccess(__('%1 simple bundles on %1 have been imported or updated', $cptSuccess, $cpt));
            $this->_redirect('*/*/');
            return;
        }
        
        $resultPage = $this->_resultPageFactory->create();
        $resultPage->setActiveMenu('Webcooking_SimpleBundle::simplebundle_bundle');
        $resultPage->addBreadcrumb(__('Import Simple Bundles'), __('Import Simple Bundles'));
        $resultPage->getConfig()->getTitle()->prepend(__('Import Simple Bundles'));

        return $resultPage;
        
    }
    
    
    protected function _checkEntetes($entetes) {
        if (!in_array('sku', $entetes)) {
            return false;
        }
        if (!in_array('discount_amount', $entetes)) {
            return false;
        }
        return true;
    }

    protected function _parseImportDataLine($dataLine) {
        if (!is_array($dataLine)) {
            return false;
        }
        if (!isset($dataLine['stores']) || !$dataLine['stores']) {
            $dataLine['stores'] = 0;
        }
        if (!isset($dataLine['is_active'])) {
            $dataLine['is_active'] = 1;
        }
        if (!isset($dataLine['base_qty'])) {
            $dataLine['base_qty'] = 1;
        }
        if (!isset($dataLine['discount_type'])) {
            $dataLine['discount_type'] = 'percent';
        }
        if (!isset($dataLine['position'])) {
            $dataLine['position'] = 0;
        }
        if (!isset($dataLine['exclude_base_product_from_discount'])) {
            $dataLine['exclude_base_product_from_discount'] =  $this->_helper->excludeBaseProductFromDiscount()?'1':'0';
        }
        if (!isset($dataLine['special_price_behavior'])) {
            $dataLine['special_price_behavior'] =  $this->_helper->getSpecialPriceBehavior();
        }
        $productId = $this->_productResource->getIdBySku($dataLine['sku']);
        if (!$productId) {
            $this->messageManager->addError(__('SKU %1 not found', $dataLine['sku']));
            return false;
        }
        $dataLine['product_id'] = $productId;

        for ($i = 1; $i <= 100; $i++) {
            if (isset($dataLine['simple_bundle_item_sku_' . $i]) && $dataLine['simple_bundle_item_sku_' . $i]) {
                $productId = $this->_productResource->getIdBySku($dataLine['simple_bundle_item_sku_' . $i]);
                if (!$productId) {
                    $this->messageManager->addError(__('SKU %1 not found', $dataLine['sku']));
                    return false;
                }
                if ($productId == $dataLine['product_id']) {
                    $this->messageManager->addError(__('Subproduct cannot be the same as master product'));
                    return false;
                }
                $dataLine['simple_bundle_item_product_id_' . $i] = $productId;
                if (!isset($dataLine['simple_bundle_item_qty_' . $i])) {
                    $dataLine['simple_bundle_item_qty_' . $i] = 1;
                }
                if (!isset($dataLine['simple_bundle_item_position_' . $i])) {
                    $dataLine['simple_bundle_item_position_' . $i] = 0;
                }
            }
        }


        return $dataLine;
    }
    
}
