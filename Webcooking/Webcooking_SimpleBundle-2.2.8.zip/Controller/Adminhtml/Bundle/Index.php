<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Bundle;

class Index extends \Magento\Backend\App\Action
{

    protected $_resultPageFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
    \Magento\Backend\App\Action\Context $context,
    \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    protected function _isAllowed() {

        return $this->_authorization->isAllowed('Webcooking_SimpleBundle::simplebundle');
    }

    /**
     * Index action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute() {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_resultPageFactory->create();
        $resultPage->setActiveMenu('Webcooking_SimpleBundle::simplebundle_bundle');
        $resultPage->addBreadcrumb(__('Simple Bundles'), __('Simple Bundles'));
        $resultPage->getConfig()->getTitle()->prepend(__('Simple Bundles'));

        return $resultPage;
    }

}
