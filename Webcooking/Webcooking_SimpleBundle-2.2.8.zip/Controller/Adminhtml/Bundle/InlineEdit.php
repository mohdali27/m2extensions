<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Bundle;

use \Webcooking\SimpleBundle\Api\BundleRepositoryInterface;
use \Webcooking\SimpleBundle\Api\Data\BundleInterface;

class InlineEdit extends \Magento\Backend\App\Action
{

    protected $_resultJsonFactory;
    protected $_bundleRepository;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
    \Magento\Backend\App\Action\Context $context,
    BundleRepositoryInterface $bundleRepository,
    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
    ) {
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->_bundleRepository = $bundleRepository;
        parent::__construct($context);
    }

    protected function _isAllowed() {

        return $this->_authorization->isAllowed('Webcooking_SimpleBundle::simplebundle');
    }

    /**
     * Index action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute() {
        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->_resultJsonFactory->create();

        $postItems = $this->getRequest()->getParam('items', []);
        if (!($this->getRequest()->getParam('isAjax') && count($postItems))) {
            return $resultJson->setData([
                'messages' => [__('Please correct the data sent.')],
                'error' => true,
            ]);
        }

        foreach (array_keys($postItems) as $bundleId) {
            $bundle = $this->_bundleRepository->getById($bundleId);
            $this->updateBundle($bundle, $postItems[$bundleId]);
            $this->saveBundle($bundle);
        }

        return $resultJson->setData([
            'messages' => $this->getErrorMessages(),
            'error' => $this->isErrorExists()
        ]);
    }
    
    

    /**
     * Update bundle data
     *
     * @param BundleRepositoryInterface $bundle Bundle
     * @param array $data
     * @return void
     */
    protected function updateBundle(BundleInterface $bundle, array $data)
    {
        foreach($data as $key=>$value) {
            if($key == 'simple_bundle_id') {
                continue;
            }
            $bundle->setData($key, $value);
        }
    }
    
    protected function saveBundle(BundleInterface $bundle)
    {
        try {
            $this->_bundleRepository->save($bundle);
        } catch (\Magento\Framework\Exception\InputException $e) {
            $this->getMessageManager()->addError($this->getErrorWithBundleId($bundle, $e->getMessage()));
            $this->logger->critical($e);
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->getMessageManager()->addError($this->getErrorWithBundleId($bundle, $e->getMessage()));
            $this->logger->critical($e);
        } catch (\Exception $e) {
            $this->getMessageManager()->addError($this->getErrorWithBundleId($bundle, 'We can\'t save the bundle.'));
            $this->logger->critical($e);
        }
    }
    
    protected function getErrorWithBundleId($bundle, $errorText)
    {
        return '[Bundle ID: ' . $bundle->getId() . '] ' . __($errorText);
    }
    
    /**
     * Get array with errors
     *
     * @return array
     */
    protected function getErrorMessages()
    {
        $messages = [];
        foreach ($this->getMessageManager()->getMessages()->getItems() as $error) {
            $messages[] = $error->getText();
        }
        return $messages;
    }

    /**
     * Check if errors exists
     *
     * @return bool
     */
    protected function isErrorExists()
    {
        return (bool)$this->getMessageManager()->getMessages(true)->getCount();
    }
    

}
