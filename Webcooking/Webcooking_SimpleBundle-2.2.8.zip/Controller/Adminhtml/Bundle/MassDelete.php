<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Bundle;

use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;

class MassDelete extends \Magento\Backend\App\Action
{
    
    protected $bundleCollectionFactory;
    protected $filter;

    /**
     * @param Context $context
     * @param Filter $filter
     */
    public function __construct(
        Context $context,
        Filter $filter,
        \Webcooking\SimpleBundle\Model\ResourceModel\Bundle\CollectionFactory $bundleCollectionFactory
    ) {
        $this->filter = $filter;
        $this->bundleCollectionFactory = $bundleCollectionFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        
        $collection = $this->filter->getCollection($this->bundleCollectionFactory->create());
        $deletedCount = 0;
        foreach ($collection->getItems() as $record) {
            $record->delete();
            $deletedCount++;
        }
        $this->messageManager->addSuccess(
            __('A total of %1 record(s) have been deleted.', $deletedCount)
        );
        
        return $resultRedirect->setPath('*/*/');
    }

}
