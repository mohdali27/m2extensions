<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Product\Initialization\Helper\Plugin;

use Webcooking\SimpleBundle\Model\BundleFactory as BundleFactory;
use Webcooking\SimpleBundle\Model\BundleItemFactory as BundleItemFactory;
use Magento\Catalog\Api\ProductRepositoryInterface as ProductRepository;
use Magento\Store\Model\StoreManagerInterface as StoreManager;
use Magento\Framework\App\RequestInterface;

class SimpleBundle 
{

    /**
     * @var RequestInterface
     */
    protected $request;

  
    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var StoreManager
     */
    protected $storeManager;
    protected $bundleFactory;
    protected $bundleItemFactory;

    /**
     * @param RequestInterface $request
     * @param ProductRepository $productRepository
     * @param StoreManager $storeManager
     */
    public function __construct(
        RequestInterface $request,
        ProductRepository $productRepository,
        BundleFactory $bundleFactory,
        BundleItemFactory $bundleItemFactory,
        StoreManager $storeManager
    ) {
        $this->request = $request;
        $this->bundleFactory = $bundleFactory;
        $this->bundleItemFactory = $bundleItemFactory;
        $this->productRepository = $productRepository;
        $this->storeManager = $storeManager;
    }

    /**
     * Setting Simple Bundle Data to product for further processing
     *
     * @param \Magento\Catalog\Controller\Adminhtml\Product\Initialization\Helper $subject
     * @param \Magento\Catalog\Model\Product $product
     *
     * @return \Magento\Catalog\Model\Product
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function afterInitialize(
        \Magento\Catalog\Controller\Adminhtml\Product\Initialization\Helper $subject,
        \Magento\Catalog\Model\Product $product
    ) {
        if ($this->request->getPost('affect_simple_bundles')) {
            $bundles = [];
            if (isset($this->request->getPost('simplebundles')['simplebundles'])) {
                foreach ($this->request->getPost('simplebundles')['simplebundles'] as $key => $bundleData) {
                    if(isset($bundleData['simplebundle_selections'])) {
                        $selections = [];
                        foreach($bundleData['simplebundle_selections'] as $selectionData) {
                            $selections[] = $this->bundleItemFactory->create(['data' => $selectionData]);
                        }
                        $bundleData['simplebundle_selections'] = $selections;
                    }
                    $bundle = $this->bundleFactory->create(['data' => $bundleData]);
                    $bundles[] = $bundle;
                }
            }
            $extension = $product->getExtensionAttributes();
            $extension->setSimplebundles($bundles);
            $product->setExtensionAttributes($extension);
        } 

        return $product;
    }



}
