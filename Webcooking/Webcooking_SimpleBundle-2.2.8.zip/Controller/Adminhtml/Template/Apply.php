<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Template;

use Magento\Backend\App\Action\Context;

class Apply extends \Magento\Backend\App\Action
{

    protected $_templateRepository;

    
    
     /**
     * @param \Magento\Backend\App\Action\Context $context
     */
    public function __construct(
            Context $context,
            \Webcooking\SimpleBundle\Model\TemplateRepository $templateRepository
            )
    {
        parent::__construct($context);
        $this->_templateRepository = $templateRepository;
    }
    
    /**
     * Apply action
     *
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $templateId = $this->getRequest()->getParam('template_id');
        $template = $this->_templateRepository->getById($templateId);
        if(!$template->getId()) {
            $this->messageManager->addError(__('This template does not exist'));
            $resultRedirect->setPath('simplebundle/template/edit', ['template_id'=>$templateId]);
            return;
        }
        $template->applyRule();
        $this->messageManager->addSuccess(__('Rule has been applied'));
        return $resultRedirect->setPath('simplebundle/template/edit', ['template_id'=>$templateId]);
    }

}
