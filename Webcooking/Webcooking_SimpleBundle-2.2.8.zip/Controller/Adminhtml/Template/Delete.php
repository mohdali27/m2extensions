<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Template;

use Magento\Backend\App\Action\Context;

class Delete extends \Magento\Backend\App\Action
{
    
    protected $templateFactory;

    /**
     * @param Context $context
     * @param TemplateFactory $templateFactory
     */
    public function __construct(
        Context $context,
        \Webcooking\SimpleBundle\Model\TemplateFactory $templateFactory
    ) {
        $this->templateFactory = $templateFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        
        $template = $this->templateFactory->create()->load($this->getRequest()->getParam('template_id'));
        $template->delete();
        
        $this->messageManager->addSuccess(
            __('Template has been deleted.')
        );
        
        return $resultRedirect->setPath('*/*/');
    }

}
