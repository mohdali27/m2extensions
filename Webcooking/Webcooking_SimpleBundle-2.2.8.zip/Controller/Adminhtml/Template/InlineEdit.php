<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Template;

use \Webcooking\SimpleBundle\Api\TemplateRepositoryInterface;
use \Webcooking\SimpleBundle\Api\Data\TemplateInterface;

class InlineEdit extends \Magento\Backend\App\Action
{

    protected $_resultJsonFactory;
    protected $_templateRepository;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
    \Magento\Backend\App\Action\Context $context,
    TemplateRepositoryInterface $templateRepository,
    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
    ) {
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->_templateRepository = $templateRepository;
        parent::__construct($context);
    }

    protected function _isAllowed() {

        return $this->_authorization->isAllowed('Webcooking_SimpleBundle::simplebundle');
    }

    /**
     * Index action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute() {
        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->_resultJsonFactory->create();

        $postItems = $this->getRequest()->getParam('items', []);
        if (!($this->getRequest()->getParam('isAjax') && count($postItems))) {
            return $resultJson->setData([
                'messages' => [__('Please correct the data sent.')],
                'error' => true,
            ]);
        }

        foreach (array_keys($postItems) as $templateId) {
            $template = $this->_templateRepository->getById($templateId);
            $this->updateTemplate($template, $postItems[$templateId]);
            $this->saveTemplate($template);
        }

        return $resultJson->setData([
            'messages' => $this->getErrorMessages(),
            'error' => $this->isErrorExists()
        ]);
    }
    
    

    /**
     * Update Template data
     *
     * @param TemplateRepositoryInterface $template TEmplate
     * @param array $data
     * @return void
     */
    protected function updateTemplate(TemplateInterface $template, array $data)
    {
        foreach($data as $key=>$value) {
            if($key == 'template_id') {
                continue;
            }
            $template->setData($key, $value);
        }
    }
    
    protected function saveTemplate(TemplateInterface $template)
    {
        try {
            $this->_templateRepository->save($template);
        } catch (\Magento\Framework\Exception\InputException $e) {
            $this->getMessageManager()->addError($this->getErrorWithTemplateId($template, $e->getMessage()));
            $this->logger->critical($e);
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->getMessageManager()->addError($this->getErrorWithTemplateId($template, $e->getMessage()));
            $this->logger->critical($e);
        } catch (\Exception $e) {
            $this->getMessageManager()->addError($this->getErrorWithTemplateId($template, 'We can\'t save the template.'));
            $this->logger->critical($e);
        }
    }
    
    protected function getErrorWithTemplateId($template, $errorText)
    {
        return '[Template ID: ' . $template->getId() . '] ' . __($errorText);
    }
    
    /**
     * Get array with errors
     *
     * @return array
     */
    protected function getErrorMessages()
    {
        $messages = [];
        foreach ($this->getMessageManager()->getMessages()->getItems() as $error) {
            $messages[] = $error->getText();
        }
        return $messages;
    }

    /**
     * Check if errors exists
     *
     * @return bool
     */
    protected function isErrorExists()
    {
        return (bool)$this->getMessageManager()->getMessages(true)->getCount();
    }
    

}
