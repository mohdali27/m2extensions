<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Template;

use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;

class MassDelete extends \Magento\Backend\App\Action
{
    
    protected $templateCollectionFactory;
    protected $filter;

    /**
     * @param Context $context
     * @param Filter $filter
     */
    public function __construct(
        Context $context,
        Filter $filter,
        \Webcooking\SimpleBundle\Model\ResourceModel\Template\CollectionFactory $templateCollectionFactory
    ) {
        $this->filter = $filter;
        $this->templateCollectionFactory = $templateCollectionFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        
        $collection = $this->filter->getCollection($this->templateCollectionFactory->create());
        $deletedCount = 0;
        foreach ($collection->getItems() as $record) {
            $record->delete();
            $deletedCount++;
        }
        $this->messageManager->addSuccess(
            __('A total of %1 record(s) have been deleted.', $deletedCount)
        );
        
        return $resultRedirect->setPath('*/*/');
    }

}
