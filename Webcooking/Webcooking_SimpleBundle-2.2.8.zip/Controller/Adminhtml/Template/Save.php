<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Adminhtml\Template;

use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\TestFramework\Inspection\Exception;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    
    protected $templateItemFactory;

    /**
     * @param Context $context
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
        Context $context,
        DataPersistorInterface $dataPersistor,
        \Webcooking\SimpleBundle\Model\TemplateItemFactory $templateItemFactory,
        JsonFactory $jsonFactory
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->templateItemFactory = $templateItemFactory;
        $this->jsonFactory = $jsonFactory;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultJson = $this->jsonFactory->create();
        $data = $this->getRequest()->getPostValue();
        $dataTemplate = isset($data['template']) ? $data['template'] : (isset($data['items']) ? current($data['items']) : false);
        $dataSelections = isset($data['template_selections']) ? $data['template_selections'] : false;
        $dataProducts = isset($data['template_products']) ? $data['template_products'] : false;
        if ($data && $dataTemplate) {
            $id = $dataTemplate['template_id'];
            
            if (empty($dataTemplate['template_id'])) {
                $dataTemplate['template_id'] = null;
            }

           
            $model = $this->_objectManager->create('Webcooking\SimpleBundle\Model\Template')->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addError(__('This template no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
            
            if($dataProducts) {
                $dataTemplate['template_products'] = $dataProducts;
            }
            
            if(!isset($dataTemplate['store_ids'])) {
                $dataTemplate['store_ids'] = 0;
            } elseif(is_array($dataTemplate['store_ids'])) {
                $dataTemplate['store_ids'] = implode(',', $dataTemplate['store_ids']);
            }
            if (isset($data['rule']['conditions'])) {
                $dataTemplate['conditions'] = $data['rule']['conditions'];
            }
            unset($data['rule']);
            unset($dataTemplate['conditions_serialized']);
            if($dataTemplate['conditions'] ?? false) {
                $model->loadPost($dataTemplate);
            }
            $model->setData($dataTemplate);
            try {
                
                $model->save();
                
                if(is_array($dataSelections)) {

                    $oldTemplateItems = $model->getTemplateItems();
                    $updatedTemplateItems = [];
                    foreach($dataSelections as $dataSelection) {
                        if ($dataSelection['product_id'] && $dataSelection['selection_qty'] > 0 && $model->getId()) {
                            $templateItem = $this->templateItemFactory->create();
                            if($dataSelection['template_item_id']) {}
                                $templateItem->load($dataSelection['template_item_id']);
                                
                                if ($templateItem->getId()) {
                                    $updatedTemplateItems[$templateItem->getId()] = true;
                                
                                if(isset($dataSelection['delete']) && $dataSelection['delete']) {
                                    $templateItem->delete();
                                    continue;
                                } else if($templateItem->getTemplateId() != $model->getId()) {
                                    throw new Exception('Item does not correspond to this customer.');
                                }
                            } else {
                                if(isset($dataSelection['delete']) && $dataSelection['delete']) {
                                    continue;
                                }
                                $templateItem->setData('template_id', $model->getId());
                                $templateItem->setData('product_id', $dataSelection['product_id']);
                            }
                            $templateItem->setData('selection_qty', $dataSelection['selection_qty']);
                            $templateItem->setData('position', $dataSelection['position']);
                            $templateItem->save();
                        }
                    }
                    
                    foreach ($oldTemplateItems as $oldTemplateItem) {
                        if (!isset($updatedTemplateItems[$oldTemplateItem->getId()])) {
                            $oldTemplateItem->delete();
                        }
                    }
                }
                
                
                
                $model->clearTemplateItems()->save();//generate slave products label
                
                
                
                
                
                $this->messageManager->addSuccess(__('Saved successfully.'));
                $this->dataPersistor->clear('simplebundle_template');

                if ($this->getRequest()->getParam('isAjax')) {
                    return $resultJson->setData([
                        'messages' => [],
                        'error' => false
                    ]);
                }
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['template_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving.'.$e->getMessage()));
            }
            return $resultRedirect->setPath('*/*/edit', ['template_id' => $dataTemplate['template_id']]);
        }
        return $resultRedirect->setPath('*/*/');
    }

}
