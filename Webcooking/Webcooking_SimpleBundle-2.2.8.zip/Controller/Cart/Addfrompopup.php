<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Cart;



use Magento\Checkout\Model\Cart as CustomerCart;

class Addfrompopup extends \Magento\Checkout\Controller\Cart
{
    
     protected $_helper;
     protected $_productRepository;
    
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator,
        CustomerCart $cart,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Webcooking\SimpleBundle\Helper\Data $helper
    ) {
        $this->_helper = $helper;
        $this->_productRepository = $productRepository;
        parent::__construct($context, $scopeConfig, $checkoutSession, $storeManager, $formKeyValidator, $cart);
    }

        

    public function execute() {
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            return $this->getResponse()->representJson(
                $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode(['success'=>false, 'error-message'=>__('Une erreur est survenue')])
            );
        }
        $result = ['success'=>true, 'error-message'=>''];
        $params = $this->getRequest()->getParams();
        try {
            $bundleId = $params['bundle_id'];
            foreach ($params['sbdata'] as $productToAdd) {
                parse_str(urldecode($productToAdd), $productRequest);
                $product = $this->_productRepository->getById($productRequest['product'], false, $this->_helper->getCurrentStoreId());
                $productRequest['product'] = $product->getId();
                $this->cart->addProduct($product, $productRequest);
            }

            $this->_checkoutSession->setCartWasUpdated(true);

            $simpleBundleIds = $this->_checkoutSession->getSimpleBundleIds();
            if (!$simpleBundleIds) {
                $simpleBundleIds = [];
            }
            $simpleBundleIds[] = $bundleId;
            $this->_checkoutSession->setSimpleBundleIds($simpleBundleIds);
            
            $this->cart->save();
        } catch (Mage_Core_Exception $e) {
            $result['success'] = false;
            $result['error-message'] = __('Cannot add the bundle to shopping cart ');
            if ($this->_checkoutSession->getUseNotice(true)) {
                $this->messageManager->addNotice(
                    $this->_objectManager->get('Magento\Framework\Escaper')->escapeHtml($e->getMessage())
                );
            } else {
                $messages = array_unique(explode("\n", $e->getMessage()));
                foreach ($messages as $message) {
                    $this->messageManager->addError(
                        $this->_objectManager->get('Magento\Framework\Escaper')->escapeHtml($message)
                    );
                }
            }
        } catch (Exception $e) {
            $result['success'] = false;
            $result['error-message'] = __('Cannot add the bundle to shopping cart.');
            $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
        }
        
        return $this->getResponse()->representJson(
            $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($result)
        );
        
    }
    
   
}
