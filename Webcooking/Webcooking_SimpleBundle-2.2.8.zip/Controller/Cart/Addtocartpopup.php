<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Controller\Cart;


use Webcooking\SimpleBundle\Model\BundleFactory as BundleFactory;
use Magento\Framework\View\Result\PageFactory;

class Addtocartpopup extends \Magento\Framework\App\Action\Action
{
    
    protected $_helper;
    protected $_bundleFactory;
    protected $_formKeyValidator;
    protected $_resultPageFactory;
    
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Webcooking\SimpleBundle\Helper\Data $helper,
        BundleFactory $bundleFactory,
        PageFactory $resultPageFactory,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator
    ) {
        $this->_helper = $helper;
        $this->_bundleFactory = $bundleFactory;
        $this->_formKeyValidator = $formKeyValidator;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

        

    public function execute() {
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            return $this->getResponse()->representJson(
                $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode(['success'=>false])
            );
        }
        
        $bundle = $this->_bundleFactory->create()->load($this->getRequest()->getParam('bundle_id'));
        
        
        
        $resultPage = $this->_resultPageFactory->create();
        $content = $resultPage->getLayout()->getBlock('simple.bundles.popup')->setBundle($bundle)->toHtml();
        
        
        return $this->getResponse()->representJson(
            $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode(['success'=>true, 'popup'=>$content])
        );
        
    }
    
   
}
