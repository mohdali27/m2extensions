<?php
/**
 * Copyright (c) 2011-2018 Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Cron;

class ApplyTemplateRules 
{
    
    protected $_templateCollectionFactory;

    public function __construct(
    \Webcooking\SimpleBundle\Model\ResourceModel\Template\CollectionFactory $templateCollectionFactory) {
        $this->_templateCollectionFactory = $templateCollectionFactory;
    }

    
    public function execute() {
        $templateCollection = $this->_templateCollectionFactory->create();
        $templateCollection->addFieldToFilter('rule_status', 1);
        foreach($templateCollection as $template) {
            $template->applyRule();
        }
    }
}
