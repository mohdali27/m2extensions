<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Helper;

use Webcooking\SimpleBundle\Api\Data\BundleInterface as BundleInterface;
use Webcooking\SimpleBundle\Model\BundleFactory as BundleFactory;
use Webcooking\SimpleBundle\Model\ResourceModel\Bundle\CollectionFactory as BundleCollectionFactory;
use Webcooking\SimpleBundle\Model\ResourceModel\Template\CollectionFactory as TemplateCollectionFactory;

class Data extends \Webcooking\All\Helper\Data
{

    protected $_helperProduct;
    protected $_productFactory;
    protected $_bundleFactory;
    protected $_bundleCollectionFactory;
    protected $_templateCollectionFactory;
    protected $_layoutFactory;
    protected $_escaper;

    public function __construct(
        \Webcooking\All\Helper\Context $context,
        \Webcooking\All\Helper\Product $helperProduct,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        BundleFactory $bundleFactory,
        BundleCollectionFactory $bundleCollectionFactory,
        TemplateCollectionFactory $templateCollectionFactory,
        \Magento\Framework\View\LayoutFactory $layoutFactory,
        \Magento\Framework\Escaper $escaper
    ) {
        parent::__construct($context);
        $this->_helperProduct = $helperProduct;
        $this->_productFactory = $productFactory;
        $this->_bundleFactory = $bundleFactory;
        $this->_bundleCollectionFactory = $bundleCollectionFactory;
        $this->_templateCollectionFactory = $templateCollectionFactory;
        $this->_layoutFactory = $layoutFactory;
        $this->_escaper = $escaper;
    }
    
     public function formatDescription($description) {
        if(!$description)
            return __('Bundle discounts');
        return __($description);
    }
    
    public function excludeBaseProductFromDiscount($store = null)
    {
        return $this->getStoreConfigFlag('simplebundle/general/exclude_base_product_from_discount', $store);
    }
    
    public function getSpecialPriceBehavior($store = null)
    {
        return $this->getStoreConfigFlag('simplebundle/general/special_price_behavior', $store);
    }
    
    public function productNeedsConfiguration($product) {
        if(!$product) return true;
        return $product->getTypeId() == 'configurable' || ($product->getTypeId() == 'bundle' && !$this->_helperProduct->isBundleProductWithoutConfiguration($product)) || count($product->getOptions())>0;
    }
    
    public function displayAllProductsInPopup($store = null) {
        return $this->getStoreConfigFlag('simplebundle/popup/display_all_products', $store);
    }
    
    
    public function distinguishVariables($text, $productId, $extra=[]) {
        $text = preg_replace("%product_addtocart_form([^-])%", "product_addtocart_form-".$productId.'$1', $text);
        
        foreach($extra as $placeholder) {
            $text = preg_replace('%'.$placeholder.'([^0-9])%', $placeholder.$productId.'$1', $text);
        }
        
        return $text;
    }
    
    
    public function getBundleCollectionForProduct($product, $limit = null) {
        if(!$product || !is_object($product)) {
            return new Varien_Data_Collection();
    	}
        $collection = $this->_bundleCollectionFactory->create()
               ->addFieldToFilter('active', 1)
               ->addFieldToFilter('product_id', $product->getId())
               ->addStoreFilter();
        if($limit && is_int($limit)) {
            $collection->setPageSize($limit);
        }
        $collection->appendSelections();
       return $collection;
    }
    
    public function getSpecialPriceBehaviorOptions($simpleArray = true) {
        $options = [
            BundleInterface::SPECIAL_PRICE_BEHAVIOR_USE_LOWEST_PRICE => __('Use lowest price'),
            BundleInterface::SPECIAL_PRICE_BEHAVIOR_DISABLE => __('Disable Bundle'),
            BundleInterface::SPECIAL_PRICE_BEHAVIOR_CUMULATE => __('Cumulate'),
        ];
        if(!$simpleArray) {
            $options2 = [];
            foreach($options as $k=>$v) {
                $options2[] = ['value' => $k, 'label' => $v];
            }
            return $options2;
        }
        return $options;
    }
    
    public function getTemplateOptions($simpleArray = true) {
        $templateCollection = $this->_templateCollectionFactory->create();
        $options =  ['0'=> __('None')];
        foreach($templateCollection as $template) {
            $options[$template->getId()] = str_replace("'", "\'", $this->_escaper->escapeHtml($template->getTemplateName()));
        }
        if(!$simpleArray) {
            $options2 = [];
            foreach($options as $k=>$v) {
                $options2[] = ['value' => $k, 'label' => $v];
            }
            return $options2;
        }
        return $options;
    }
    
    public function isInPromo($product, $decimals = 0, $withSymbol = true, $allowEmptyEndDate = true) {
        if (!$product)
            return false;

        if ($product->getFinalPrice() >= $product->getPrice())
            return false;

        $percentage = (100 - round((100 * $product->getFinalPrice()) / $product->getPrice(), $decimals));

        if ($withSymbol)
            $percentage .= '%';

        return $percentage;
    }
    
    
    public function addBundleToCart($cart, $bundleId, $params) {
        $options = isset($params['options']) ? $params['options'] : [];
        $superAttributes = isset($params['super_attribute']) ? $params['super_attribute'] : [];
       
        
        
        $bundle = $this->_bundleFactory->create()->load($bundleId);
        $baseProductId = $bundle->getProductId();
        $baseProductQty = $bundle->getBaseQty();
        $selection = [$baseProductId => $baseProductQty];
        foreach ($bundle->getAssociatedProducts() as $_selection) {
            $selection[$_selection['product']->getId()] = $_selection['qty'];
        }



        $productsToAdd = [];
        foreach ($selection as $pId => $qty) {
            $product = $this->_productFactory->create()
                    ->setStoreId($this->getCurrentStoreId())
                    ->load($pId);
            if (!$product) {
                return false;
            }

            $filter = new \Zend_Filter_LocalizedToNormalized(
                ['locale' => $this->_objectManager->get('Magento\Framework\Locale\ResolverInterface')->getLocale()]
            );

            $productToAdd = ['product' => $product, 'qty' => $filter->filter($qty)];
            if ($pId == $baseProductId && $options) {
                $productToAdd['options'] = $options;
            }
            if ($pId == $baseProductId && $superAttributes) {
                $productToAdd['super_attribute'] = $superAttributes;
            }

            if(isset($params['sbdata']) && isset($params['sbdata'][$pId])) {
                $productToAdd = array_merge($productToAdd, $params['sbdata'][$pId]);
            }

            $additionnalParameters = $this->_getAdditionalParams($product, $cart);

            $productsToAdd[] = array_merge($productToAdd, $additionnalParameters);
        }



        foreach ($productsToAdd as $productToAdd) {
            $product = $productToAdd['product'];
            $productToAdd['product'] = $product->getId();
            $cart->addProduct($product, $productToAdd);
        }


        $this->getCheckoutSession()->setCartWasUpdated(true);
        
        $simpleBundleIds = $this->getCheckoutSession()->getSimpleBundleIds();
        if (!$simpleBundleIds) {
            $simpleBundleIds = [];
        }
        $simpleBundleIds[] = $bundleId;
        $simpleBundleIds = array_unique($simpleBundleIds);
        $this->getCheckoutSession()->setSimpleBundleIds($simpleBundleIds);



        $cart->save();
        return true;
    }
    
    protected function _getAdditionalParams($origProduct, $cart) {
        
        $bundleOptions = $this->_helperProduct->isBundleProductWithoutConfiguration($origProduct);
        
        $additional = [];
        
        if($bundleOptions) {
            $additional = $bundleOptions;
        }
        
        return $additional;
    }
    
    public function displayBundleList($product, $max = null) {
        $block = $this->_layoutFactory->create()->createBlock('simplebundle/catalog_product_view_bundle');
        $block->setTemplate('catalog/product/list/bundle.phtml');
        $block->setProduct($product);
        $block->setLimit($max);
        return $block->toHtml();
    }


}
