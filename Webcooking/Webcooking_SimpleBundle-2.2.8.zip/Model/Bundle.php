<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Model;

use Webcooking\SimpleBundle\Api\Data\BundleInterface;
use Webcooking\All\Model\AbstractModel;

class Bundle extends AbstractModel implements BundleInterface
{
    protected $_itemCollectionFactory;
    protected $_productFactory;
    protected $_helper;
    protected $_templateFactory;
    protected $_selectionsLoaded = false;
    protected $_mainProduct = null;
    protected $_needsConfiguration = null;
    protected $_selectionProducts = null;
    protected $_originalFinalAmount = null;
    protected $_originalAmount = null;
    protected $_originalWeeeAmount = null;
    
    
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory,
        \Webcooking\SimpleBundle\Model\ResourceModel\Bundle $resource,
        \Webcooking\SimpleBundle\Model\ResourceModel\BundleItem\CollectionFactory $itemCollectionFactory,
        \Webcooking\SimpleBundle\Model\TemplateFactory $templateFactory,
        \Webcooking\SimpleBundle\Helper\Data $helper,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->_itemCollectionFactory = $itemCollectionFactory;
        $this->_templateFactory = $templateFactory;
        $this->_productFactory = $productFactory;
        $this->_helper = $helper;
        parent::__construct(
            $context,
            $registry,
            $dateFactory,
            $resource,
            $resourceCollection,
            $data
        );
    }

    protected function _construct() {
        $this->_init('Webcooking\SimpleBundle\Model\ResourceModel\Bundle');
    }

    public function getBaseQty() {
        return $this->getData(self::BASE_QTY);
    }

    public function getBundleName() {
        return $this->getData(self::BUNDLE_NAME);
    }

    public function getCreatedAt() {
        return $this->getData(self::CREATED_AT);
    }

    public function getDiscountAmount() {
        return $this->getData(self::DISCOUNT_AMOUNT);
    }

    public function getDiscountType() {
        return $this->getData(self::DISCOUNT_TYPE);
    }

    public function getExcludeBaseProductFromDiscount() {
        return $this->getData(self::EXCLUDE_BASE_PRODUCT_FROM_DISCOUNT);
    }

    public function getGeneratedByRule() {
        return $this->getData(self::GENERATED_BY_RULE);
    }

    public function getId() {
        return $this->getData(self::SIMPLE_BUNDLE_ID);
    }

    public function getIsActive() {
        return $this->getData(self::IS_ACTIVE);
    }

    public function getPosition() {
        return $this->getData(self::POSITION);
    }

    public function getProductId() {
        return $this->getData(self::PRODUCT_ID);
    }

    public function getSpecialPriceBehavior() {
        if(!$this->hasData(self::SPECIAL_PRICE_BEHAVIOR) || !array_key_exists(intval($this->getData(self::SPECIAL_PRICE_BEHAVIOR)), $this->_helper->getSpecialPriceBehaviorOptions())) {
            $this->setData(self::SPECIAL_PRICE_BEHAVIOR, $this->_helper->getSpecialPriceBehavior());
        }
        return $this->getData(self::SPECIAL_PRICE_BEHAVIOR);
    }

    public function getStoreIds() {
        return $this->getData(self::STORE_IDS);
    }

    public function getTemplateId() {
        return $this->getData(self::TEMPLATE_ID);
    }

    public function getUpdatedAt() {
        return $this->getData(self::UPDATED_AT);
    }

    public function setBaseQty($qty) {
        return $this->setData(self::BASE_QTY, $qty);
    }

    public function setBundleName($name) {
        return $this->setData(self::BUNDLE_NAME, $name);
    }

    public function setDiscountAmount($discountAmount) {
        return $this->setData(self::DISCOUNT_AMOUNT, $discountAmount);
    }

    public function setDiscountType($discountType) {
        return $this->setData(self::DISCOUNT_TYPE, $discountType);
    }

    public function setExcludeBaseProductFromDiscount($flag) {
        return $this->setData(self::EXCLUDE_BASE_PRODUCT_FROM_DISCOUNT, $flag);
    }

    public function setGeneratedByRule($flag) {
        return $this->setData(self::GENERATED_BY_RULE, $flag);
    }

    public function setId($id) {
        return $this->setData(self::SIMPLE_BUNDLE_ID, $id);
    }

    public function setIsActive($flag) {
        return $this->setData(self::IS_ACTIVE, $flag);
    }

    public function setPosition($position) {
        return $this->setData(self::POSITION, $position);
    }

    public function setProductId($productId) {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    public function setSpecialPriceBehavior($specialPriceBehavior) {
        return $this->setData(self::SPECIAL_PRICE_BEHAVIOR, $specialPriceBehavior);
    }

    public function setStoreIds($storeIds) {
        return $this->setData(self::STORE_IDS, $storeIds);
    }

    public function setTemplateId($templateId) {
        return $this->setData(self::TEMPLATE_ID, $templateId);
    }
    
    /**
     * Get Bundle Items
     * 
     * 
     * @return \Webcooking\SimpleBundle\Model\ResourceModel\BundleItem\CollectionFactory|null
     */
    public function getBundleItems() {
        if(!$this->_selectionsLoaded) {
            $this->loadBundleItems();
        }
        return $this->getData('bundle_items');
    }
    
    public function loadBundleItems($withAttributes = true) {
        if ($this->_selectionsLoaded) {
            return;
        }
        $bundleItemCollection = $this->_itemCollectionFactory->create();
        $bundleItemCollection->addFieldToFilter('simple_bundle_id', $this->getId());
        if ($withAttributes) {
            foreach ($bundleItemCollection as $item) {
                $product = $this->_productFactory->create()->load($item->getProductId(), ['name', 'sku', 'small_image', 'short_description', 'price', 'special_price', 'special_from_date', 'special_to_date']);
                $item->setName($product->getName());
                $item->setSku($product->getSku());
                $item->setSmallImage($product->getSmallImage());
                $item->setIsSalable($product->isSaleable());
                $item->setPrice($product->getPrice());
                $item->setFinalPrice($product->getFinalPrice());
            }
        }

        $this->setBundleItems($bundleItemCollection);

        $this->_selectionsLoaded = true;
    }
    
    public function getAssociatedProducts() {
        if (is_null($this->_selectionProducts)) {
            $this->_selectionProducts = [];
            $bundleItemCollection = $this->_itemCollectionFactory->create();
            $bundleItemCollection->addFieldToFilter('simple_bundle_id', $this->getId());
            foreach ($bundleItemCollection as $item) {
                $product = $this->_productFactory->create()->load($item->getProductId());
                $this->_selectionProducts[] = ['product' => $product, 'qty' => $item->getSelectionQty()];
            }
        }
        return $this->_selectionProducts;
    }
    
    public function isSalable() {
        $isSalable = $this->getMainProduct()->isSaleable();
        if (!$isSalable) {
            return false;
        }
        foreach ($this->getBundleItems() as $item) {
            if (!$item->getIsSalable()) {
                return false;
            }
        }
        return true;
    }
    
    public function hasSpecialPrice() {
        $isInPromo = $this->_helper->isInPromo($this->getMainProduct());
        if ($isInPromo && !$this->getExcludeBaseProductFromDiscount()) {
            return true;
        }
        foreach ($this->getBundleItems() as $item) {
            if ($this->_helper->isInPromo($item)) {
                return true;
            }
        }
        return false;
    }
    
    public function getMainProduct() {
        if(is_null($this->_mainProduct)) {
            $this->_mainProduct =$this->_productFactory->create()->load($this->getProductId());
        }
        return $this->_mainProduct;
    }
    
    protected function _productNeedsConfiguration($product) {
        return $this->_helper->productNeedsConfiguration($product);
    }

    public function needsConfiguration() {
        if (is_null($this->_needsConfiguration)) {
            $this->_needsConfiguration = false;
            if ($this->_productNeedsConfiguration($this->getMainProduct())) {
                $this->_needsConfiguration = true;
            }
            foreach ($this->getAssociatedProducts() as $product) {
                if ($this->_productNeedsConfiguration($product['product'])) {
                    $this->_needsConfiguration = true;
                }
            }
        }
        return $this->_needsConfiguration;
    }
    
    
    
    
    
    
    
    public function getDiscountAmountValue($calculationAmount = false, $roundPrecision = 2) {
        $forceRecalculateOriginalAmount = ($this->getHasPromo() && $this->getSpecialPriceBehavior() == BundleInterface::SPECIAL_PRICE_BEHAVIOR_USE_LOWEST_PRICE);
        $discountAmount = 0;
        if ($this->getDiscountType() == 'percent') {
            if(!$calculationAmount || $forceRecalculateOriginalAmount) {
                $calculationAmount = $this->getOriginalAmount();
               
                if ($this->getExcludeBaseProductFromDiscount()) {
                    $calculationAmount -= $this->getBaseAmount();
                }
                //if (!$this->_helper->getStoreConfigFlag('simplebundle/general/apply_discount_on_weee')) {
                //    $calculationAmount -= $this->_originalWeeeAmount;
                //}
            }
            $discountAmount =  round($calculationAmount * $this->getDiscountAmount() / 100, $roundPrecision);
        } else {
            $discountAmount = $this->getDiscountAmount();
        }
        if($this->getSpecialPriceBehavior() == BundleInterface::SPECIAL_PRICE_BEHAVIOR_USE_LOWEST_PRICE && $this->getHasPromo()) {
            //if Use Lowest mode and has promo
            if(($this->getOriginalAmount() - $discountAmount) > $this->getOriginalAmount(true)) { 
                // if standard price - bundle discount is greater than the final price (= price including special price)
                // then we simply use the promo price
                $discountAmount = 0;
                $this->setUsedLowerPrice(true);
            } else {
                //else, we remove the promo part of the bundle discount
                $discountAmount = $discountAmount - ($this->getOriginalAmount() - $this->getOriginalAmount(true));
            }
        }
        return $discountAmount;
    }

    public function getDiscountPercentageValue($roundPrecision = 2, $originalAmount = false) {
        $this->getOriginalAmount();//init amounts
        if (!$originalAmount) {
            $originalAmount = $this->getOriginalAmount();
        }
        $calculationAmount = $originalAmount;
        if ($this->getExcludeBaseProductFromDiscount()) {
            $calculationAmount -= $this->getBaseAmount();
        }
        if($calculationAmount == 0) {
            return 0;
        }
        return round($this->getDiscountAmountValue($calculationAmount, 4) * 100 / $calculationAmount, $roundPrecision);
    }
    
    public function getOriginalAmount($forceFinalPrice = false) {
        $optionPrices = [];
        if ($this->_registry->registry('sb_options_prices')) {
            $optionPrices = $this->_registry->registry('sb_options_prices');
        }
        if (is_null($this->_originalAmount)) {
            $products = $this->getAssociatedProducts();
            $products[] = ['product' => $this->getMainProduct(), 'qty' => $this->getBaseQty()];
            $amount = 0;
            $baseAmount = 0;
            $finalAmount = 0;
            $baseFinalAmount = 0;
            $hasPromo = false;
            $this->_originalWeeeAmount = 0;
            foreach ($products as $data) {
                $product = $data['product'];
                //$quote = $this->_helper->getCheckoutSession()->getQuote();
                
                $tierPrices = $product->getFormatedTierPrice();
                $qty = $data['qty'];
                
                if(!$hasPromo && $this->_helper->isInPromo($product)) {
                    $hasPromo = true;
                }
               
                /*$productPrice = $product->getTypeId() == 'bundle' 
                        ? $product->getPriceModel()->getTotalPrices($product, 'min') 
                        : Mage::helper('tax')->getPrice($product, $product->getPrice(), Mage::helper('tax')->getPriceDisplayType() == Mage_Tax_Model_Config::DISPLAY_TYPE_BOTH ? $this->_helper->getStoreConfigFlag('simplebundle/general/prefer_excluding_tax_prices') : null);
                $productFinalPrice = $product->getTypeId() == 'bundle' 
                        ? $product->getPriceModel()->getTotalPrices($product, 'min') 
                        : Mage::helper('tax')->getPrice($product, $product->getFinalPrice(), Mage::helper('tax')->getPriceDisplayType() == Mage_Tax_Model_Config::DISPLAY_TYPE_BOTH ? $this->_helper->getStoreConfigFlag('simplebundle/general/prefer_excluding_tax_prices') : null);
                 */
                
                $productPrice = $product->getPrice();
                $productFinalPrice = $product->getFinalPrice();
                
                
                //$weeeAmount = Mage::helper('weee')->getAmount($product);
                //$productPrice += $weeeAmount;
                //$productFinalPrice += $weeeAmount;
                //$this->_originalWeeeAmount += $weeeAmount;
                //echo $product->getPriceModel()->getTotalPrices($product, 'min');
                $tierPriceQtyMatched = 0;
                $newProductPrice = $productPrice;
                $newProductFinalPrice = $productFinalPrice;
                if($tierPrices) {
                    foreach ($tierPrices as $tierPrice) {
                        if ($tierPrice['price_qty'] <= $qty && $tierPrice['price_qty'] > $tierPriceQtyMatched) {
                            $tierPriceQtyMatched = $tierPrice['price_qty'];
                            $newProductPrice = $product->getTypeId() == 'bundle' ? $productPrice - ($productPrice * $tierPrice['price'] / 100) : $tierPrice['price'];
                            $newProductFinalPrice = $product->getTypeId() == 'bundle' ? $productFinalPrice - ($productFinalPrice * $tierPrice['price'] / 100) : $tierPrice['price'];
                        }
                    }
                }
                $productPrice = $newProductPrice;
                $productFinalPrice = $newProductFinalPrice;
                if ($product->getId() == $this->getMainProduct()->getId()) {
                    foreach ($optionPrices as $optionPrice) {
                        $optionPrice = explode(':', $optionPrice);
                        if ($optionPrice[1] == 'percent') {
                            $productPrice += $optionPrice[0] * $productPrice / 100;
                            $productFinalPrice += $optionPrice[0] * $productFinalPrice / 100;
                        } else {
                            $productPrice += $optionPrice[0];
                            $productFinalPrice += $optionPrice[0];
                        }
                    }
                }
                if ($product->getId() == $this->getProductId()) {
                    if($this->getExcludeBaseProductFromDiscount()) {
                        $baseAmount = $productFinalPrice * $qty;
                    } else {
                        $baseAmount = $productPrice * $qty;
                    }
                    $baseFinalAmount = $productFinalPrice * $qty;
                }
                $amount += $productPrice * $qty;
                $finalAmount += $productFinalPrice * $qty;
            }
            $this->_originalAmount = round($amount, 2);
            $this->_originalFinalAmount = round($finalAmount, 2);
            $this->setBaseAmount($baseAmount);
            $this->setBaseFinalAmount($baseFinalAmount);
            $this->setHasPromo($hasPromo);
        }
        if($this->getDiscountAmount() && !$forceFinalPrice && $this->getSpecialPriceBehavior() == BundleInterface::SPECIAL_PRICE_BEHAVIOR_USE_LOWEST_PRICE && $this->getHasPromo()) {
            return $this->_originalAmount;
        }
        return $this->_originalFinalAmount;
    }
    
    public function getAmount() {
        return $this->getOriginalAmount(true) - $this->getDiscountAmountValue(false);
    }
    
    
    public function generateSlaveProductsInfo() {
        $items = $this->getBundleItems();
        $infos = [];
        foreach($items as $item) {
            $infos[] = __('%1 / %2 / Qty : %3', $item->getSku(), $item->getName(), intval($item->getSelectionQty()));
        }
        $this->setSlaveProductsInfo( implode(' | ', $infos) );
        return $this;
    }
    
    public function beforeSave() {
        $this->generateSlaveProductsInfo();
        if(is_array($this->getStoreIds())) {
            $this->setStoreIds(implode(',', array_filter($this->getStoreIds())));
        }
        if(!$this->getStoreIds()) {
            $this->setStoreIds(0);
        }
        return parent::beforeSave();
    }
    
    public function afterSave() {
        if (!$this->getBundleUpdated() && $this->dataHasChangedFor('template_id') && $this->getTemplateId()) {
            $this->setBundleUpdated(1);
            $this->getTemplate()->updateBundle($this);
        }
        return parent::afterSave();
    }

    public function getTemplate() {
        if ($this->getTemplateId()) {
            return $this->_templateFactory->create()->load($this->getTemplateId());
        }
        return false;
    }
    
    
    
    

}
