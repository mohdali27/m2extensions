<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Model;

use Webcooking\SimpleBundle\Api\Data\BundleItemInterface;
use Webcooking\All\Model\AbstractModel;

class BundleItem extends AbstractModel implements BundleItemInterface
{
    
    protected $_productFactory;
    protected $_product = null;
    protected $_bundleFactory;
    protected $_bundle = null;
    
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory,
        \Webcooking\SimpleBundle\Model\ResourceModel\BundleItem $resource,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        BundleFactory $bundleFactory,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->_productFactory = $productFactory;
        $this->_bundleFactory = $bundleFactory;
        parent::__construct(
            $context,
            $registry,
            $dateFactory,
            $resource,
            $resourceCollection,
            $data
        );
    }
    
  
    public function getId() {
        return $this->getData(self::SIMPLE_BUNDLE_ITEM_ID);
    }

    public function getPosition() {
        return $this->getData(self::POSITION);
    }

    public function getProductId() {
        return $this->getData(self::PRODUCT_ID);
    }

    public function getSelectionQty() {
        return $this->getData(self::SELECTION_QTY);
    }

    public function getSimpleBundleId() {
        return $this->getData(self::SIMPLE_BUNDLE_ID);
    }

    public function setId($id) {
        return $this->setData(self::SIMPLE_BUNDLE_ITEM_ID, $id);
    }

    public function setPosition($position) {
        return $this->setData(self::POSITION, $position);
    }

    public function setProductId($productId) {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    public function setSelectionQty($qty) {
        return $this->setData(self::SELECTION_QTY, $qty);
    }

    public function setSimpleBundleId($simpleBundleId) {
        return $this->setData(self::SIMPLE_BUNDLE_ID, $simpleBundleId);
    }
    
    public function getProduct() {
       if(is_null($this->_product)) {
           $this->_product = $this->_productFactory->create()->load($this->getProductId());
       }
       return $this->_product;
    }
    
    public function getBundle() {
        if(is_null($this->_bundle)) {
           $this->_bundle = $this->_bundleFactory->create()->load($this->getSimpleBundleId());
       }
       return $this->_bundle;
    }
    
    public function afterSave() {
       $this->getBundle()->generateSlaveProductsInfo()->save();
       return parent::afterSave();
    }

}
