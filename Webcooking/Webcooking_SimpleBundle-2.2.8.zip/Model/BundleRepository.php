<?php

/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Model;

use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Webcooking\SimpleBundle\Api\Data;
use Webcooking\SimpleBundle\Api\BundleRepositoryInterface;
use Webcooking\SimpleBundle\Model\ResourceModel\Bundle as ResourceBundle;
use Webcooking\SimpleBundle\Model\ResourceModel\BundleItem as ResourceBundleItem;
use Webcooking\SimpleBundle\Model\ResourceModel\Bundle\CollectionFactory as BundleCollectionFactory;

/**
 * Class BundleRepository
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class BundleRepository implements BundleRepositoryInterface
{

    /**
     * @var ResourceBundle
     */
    protected $resource;

    /**
     * @var ResourceBundleItem
     */
    protected $itemResource;
    protected $itemCollectionFactory;

    /**
     * @var BundleFactory
     */
    protected $bundleFactory;

    /**
     * @var BundleCollectionFactory
     */
    protected $bundleCollectionFactory;

    /**
     * @var Data\BundleSearchResultsInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * @var DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * @var DataObjectProcessor
     */
    protected $dataObjectProcessor;

    /**
     * @var \Webcooking\SimpleBundle\Api\Data\BundleInterfaceFactory
     */
    protected $dataBundleFactory;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;
    protected $collectionFactory = null;

    /**
     * @param ResourceBundle $resource
     * @param ResourceBundleItem $itemResource
     * @param BundleFactory $bundleFactory
     * @param Data\BundleInterfaceFactory $dataBundleFactory
     * @param BundleCollectionFactory $bundleCollectionFactory
     * @param Data\BundleSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
    ResourceBundle $resource,
            ResourceBundleItem $itemResource,
            BundleFactory $bundleFactory,
            \Webcooking\SimpleBundle\Api\Data\BundleInterfaceFactory $dataBundleFactory,
            \Webcooking\SimpleBundle\Model\ResourceModel\BundleItem\CollectionFactory $itemCollectionFactory,
            BundleCollectionFactory $bundleCollectionFactory,
            Data\BundleSearchResultsInterfaceFactory $searchResultsFactory,
            DataObjectHelper $dataObjectHelper,
            DataObjectProcessor $dataObjectProcessor,
            StoreManagerInterface $storeManager
    ) {
        $this->resource = $resource;
        $this->itemResource = $itemResource;
        $this->itemCollectionFactory = $itemCollectionFactory;
        $this->bundleFactory = $bundleFactory;
        $this->bundleCollectionFactory = $bundleCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataBundleFactory = $dataBundleFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
    }

    /**
     * Save Bundle data
     *
     * @param \Webcooking\SimpleBundle\Api\Data\BundleInterface $simpleBundle
     * @return Bundle
     * @throws CouldNotSaveException
     */
    public function save(Data\BundleInterface $simpleBundle) {
        $storeId = $this->storeManager->getStore()->getId();
        $simpleBundle->setStoreId($storeId);
        try {
            $this->resource->save($simpleBundle);

            $updatedSelections = [];
            if ($simpleBundle->getSimplebundleSelections()) {
                $oldSelections = $this->itemCollectionFactory->create();
                $oldSelections->addFieldToFilter('simple_bundle_id',
                        $simpleBundle->getId());
                $oldSelections->load();

                foreach ($simpleBundle->getSimplebundleSelections() as $selection) {
                    if ($selection->getSimpleBundleItemId()) {
                        $selection->setSimpleBundleItemId((int) $selection->getSimpleBundleItemId());
                    } else {
                        $selection->setSimpleBundleItemId(null);
                    }

                    if ($selection->getId()) {
                        $updatedSelections[$selection->getId()] = true;
                    }

                    if ($selection->getData('delete') == 1) {
                        /* deprecated - not working anymore in 2.2.x */
                        $this->itemResource->delete($selection);
                    } else {
                        $selection->setSimpleBundleId($simpleBundle->getId());
                        $this->itemResource->save($selection);
                    }
                }
                
                foreach ($oldSelections as $oldSelection) {
                    if (!isset($updatedSelections[$oldSelection->getId()])) {
                        $oldSelection->delete();
                    }
                }
            }

        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }
        return $simpleBundle;
    }

    /**
     * Load Bundle data by given Bundle Identity
     *
     * @param string $bundleId
     * @return Bundle
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($bundleId) {
        $bundle = $this->bundleFactory->create();
        $this->resource->load($bundle, $bundleId);
        if (!$bundle->getId()) {
            throw new NoSuchEntityException(__('Bundle with id "%1" does not exist.',
                    $bundleId));
        }
        return $bundle;
    }

    /**
     * Load Bundle data collection by given search criteria
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @param \Magento\Framework\Api\SearchCriteriaInterface $criteria
     * @return \Webcooking\SimpleBundle\Model\ResourceModel\Bundle\Collection
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $criteria) {
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $collection = $this->bundleCollectionFactory->create();
        foreach ($criteria->getFilterGroups() as $filterGroup) {
            foreach ($filterGroup->getFilters() as $filter) {
                if ($filter->getField() === 'store_id') {
                    $collection->addStoreFilter($filter->getValue(), false);
                    continue;
                }
                $condition = $filter->getConditionType() ?: 'eq';
                $collection->addFieldToFilter($filter->getField(),
                        [$condition => $filter->getValue()]);
            }
        }
        $searchResults->setTotalCount($collection->getSize());
        $sortOrders = $criteria->getSortOrders();
        if ($sortOrders) {
            foreach ($sortOrders as $sortOrder) {
                $collection->addOrder(
                        $sortOrder->getField(),
                        ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        }
        $collection->setCurPage($criteria->getCurrentPage());
        $collection->setPageSize($criteria->getPageSize());
        $bundles = [];
        /** @var Bundle $bundleModel */
        foreach ($collection as $bundleModel) {
            $bundleData = $this->dataBundleFactory->create();
            $this->dataObjectHelper->populateWithArray(
                    $bundleData, $bundleModel->getData(),
                    'Webcooking\SimpleBundle\Api\Data\BundleInterface'
            );
            $bundles[] = $this->dataObjectProcessor->buildOutputDataArray(
                    $bundleData,
                    'Webcooking\SimpleBundle\Api\Data\BundleInterface'
            );
        }
        $searchResults->setItems($bundles);
        return $searchResults;
    }

    /**
     * Delete Bundle
     *
     * @param \Webcooking\SimpleBundle\Api\Data\BundleInterface $bundle
     * @return bool
     * @throws CouldNotDeleteException
     */
    public function delete(Data\BundleInterface $bundle) {
        try {
            $this->resource->delete($bundle);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }
        return true;
    }

    /**
     * Delete Bundle by given Bundle Identity
     *
     * @param string $bundleId
     * @return bool
     * @throws CouldNotDeleteException
     * @throws NoSuchEntityException
     */
    public function deleteById($bundleId) {
        return $this->delete($this->getById($bundleId));
    }

    public function getListByProduct(ProductInterface $product) {
        $collection = $this->getCollectionFactory()->create()->addFieldToFilter('product_id',
                        $product->getId());
        $collection->load();
        return $collection;
    }

    private function getCollectionFactory() {
        if (null === $this->collectionFactory) {
            $this->collectionFactory = \Magento\Framework\App\ObjectManager::getInstance()
                    ->get('Webcooking\SimpleBundle\Model\ResourceModel\Bundle\CollectionFactory');
        }
        return $this->collectionFactory;
    }

}
