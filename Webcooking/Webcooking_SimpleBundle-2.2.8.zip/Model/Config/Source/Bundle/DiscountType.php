<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Model\Config\Source\Bundle;



use Webcooking\SimpleBundle\Api\Data\BundleInterface as BundleInterface;

class DiscountType extends \Webcooking\All\Model\Config\Source
{
   
    
   public function getData() {
       return [
                BundleInterface::DISCOUNT_TYPE_FIXED   => __('Fixed'),
                BundleInterface::DISCOUNT_TYPE_PERCENT => __('Percentage')
              ];
   }
}
