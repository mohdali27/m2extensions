<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Model\Config\Source\Bundle;


use Webcooking\SimpleBundle\Model\ResourceModel\Template\CollectionFactory as TemplateCollectionFactory;

class Template extends \Webcooking\All\Model\Config\Source
{
    protected $_templateCollectionFactory;

    public function __construct(
        TemplateCollectionFactory $templateCollectionFactory
    ) {
        $this->_templateCollectionFactory = $templateCollectionFactory;
    }
    
    
   public function getData() {
       $templateCollection = $this->_templateCollectionFactory->create();
       $data = [''=>__('None')];
       foreach($templateCollection as $template) {
           $data[$template->getId()] = $template->getTemplateName();
       }
       return $data;
   }
}
