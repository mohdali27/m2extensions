<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Model\Plugin\SalesRule\Quote;

class Discount 
{
    
    protected $_helper;
    protected $_backendQuoteSession;
    protected $_bundleCollectionFactory; 
    protected $_priceCurrency; /**
     * Discount calculation object
     *
     * @var \Magento\SalesRule\Model\Validator
     */
    protected $calculator;
    
    protected $_baseSimpleBundleAmount = 0;
    protected $_simpleBundleAmount = 0;
    protected $_baseSimpleBundleTaxAmount = 0;
    protected $_simpleBundleTaxAmount = 0;
    protected $_simpleBundleTaxDetails = [];
    protected $_baseSimpleBundleTaxDetails = [];

    public function __construct(
        \Webcooking\SimpleBundle\Helper\Data $helper,
        \Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency,
        \Magento\SalesRule\Model\Validator $validator,
        \Webcooking\SimpleBundle\Model\ResourceModel\Bundle\CollectionFactory $bundleCollectionFactory,
        \Magento\Backend\Model\Session\Quote $backendQuoteSession
            
    ) {
        $this->_helper = $helper;
        $this->_backendQuoteSession = $backendQuoteSession;
        $this->_priceCurrency = $priceCurrency;
        $this->calculator = $validator;
        $this->_bundleCollectionFactory = $bundleCollectionFactory;
    }
    
    public function getSession() {
        if($this->_helper->isAdmin()) {
             return $this->_backendQuoteSession;
        }
        return $this->_helper->getCheckoutSession();
    }
    
    public function aroundCollect(
            \Magento\SalesRule\Model\Quote\Discount $quoteDiscountObj, 
            \Closure $proceed,
            \Magento\Quote\Model\Quote $quote,
            \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment,
            \Magento\Quote\Model\Quote\Address\Total $total)
    {
        $address = $shippingAssignment->getShipping()->getAddress();
        $items = $shippingAssignment->getItems();
        foreach ($items as $item) {
            $item->setDiscountAmount(0);
            $item->setBaseDiscountAmount(0);
            $item->setDiscountPercent(0);
        }
        
        
        $proceed($quote, $shippingAssignment, $total);
       
        if (!count($items)) {
            return $this;
        }
        
        $this->processSimpleBundles($quote, $address);
        foreach ($items as $item) {
            if ($item->getParentItemId() && in_array($item->getParentItem()->getProductType(), ['bundle'])) {
               continue;
            }
          
            $item->setDiscountAmount($item->getDiscountAmount() + $item->getSimpleBundleDiscountAmount());
            $item->setBaseDiscountAmount($item->getBaseDiscountAmount() + $item->getBaseSimpleBundleDiscountAmount());
          
            $item->setOriginalDiscountAmount($item->getOriginalDiscountAmount() + $item->getSimpleBundleDiscountAmount());
            $item->setBaseOriginalDiscountAmount($item->getBaseOriginalDiscountAmount() + $item->getBaseSimpleBundleDiscountAmount());
            
        }
            
        $total->addTotalAmount($quoteDiscountObj->getCode(), -$quote->getSbundleDiscountAmount());
        $total->addBaseTotalAmount($quoteDiscountObj->getCode(), -$quote->getBaseSbundleDiscountAmount());
        
        if($quote->getSbundleDiscountAmount()> 0) {
            $description = $address->getDiscountDescriptionArray();
            $description['simplebundle'] = __('Bundle discounts');
            $address->setDiscountDescriptionArray($description);

            $this->calculator->prepareDescription($address); // calculator is protected :(
        }
        
        $total->setSubtotalWithDiscount($total->getSubtotal() + $total->getDiscountAmount());
        $total->setBaseSubtotalWithDiscount($total->getBaseSubtotal() + $total->getBaseDiscountAmount());
        
        return $this;
    }
    
    
    
    
    
    
    
   

    public function processSimpleBundles($quote, $address = false) {
        $this->_baseSimpleBundleAmount = 0;
        $this->_simpleBundleAmount = 0;
        $this->_baseSimpleBundleTaxAmount = 0;
        $this->_simpleBundleTaxAmount = 0;
        $this->_simpleBundleTaxDetails = [];
        $this->_baseSimpleBundleTaxDetails = [];
        
        if(!$address) {
            if ($quote->isVirtual()) {
                $address    = $quote->getBillingAddress();
            } else {
                $address    = $quote->getShippingAddress();
            }
        }
        
        $quote->setSbundleDiscountAmount(0);
        $quote->setBaseSbundleDiscountAmount(0);
        $quote->setSbundleDiscountTax(0);
        $quote->setBaseSbundleDiscountTax(0);
        $address->setSbundleDiscountAmount(0);
        $address->setBaseSbundleDiscountAmount(0);
        $address->setSbundleDiscountTax(0);
        $address->setBaseSbundleDiscountTax(0);
        
        
        $quote->setSimpleBundleProcessed(true);
        
        $quoteItems = $quote->getAllItems();
        
        foreach ($quoteItems as $quoteItem) {
            $quoteItem->setSimpleBundleIds(null);
            $quoteItem->setUsedInSimpleBundle(0);
            $quoteItem->setSimpleBundlePercentDiscount(0);
            $quoteItem->setSimpleBundleDiscountAmount(0);
            $quoteItem->setBaseSimpleBundleDiscountAmount(0);
            $quoteItem->setSimpleBundleDiscountTaxAmount(0);
            $quoteItem->setBaseSimpleBundleDiscountTaxAmount(0);
        }


        $bundleIdsAdded = $this->getSession()->getSimpleBundleIds();
        
        if (!$bundleIdsAdded)
            $bundleIdsAdded = [];
        
        
        $bundleIdsMatched = [];

        $productIds = [];
        foreach($quote->getAllItems() as $_item) {
            $productIds[] = $_item->getProductId();
        }

        $bundleCollection = $this->_bundleCollectionFactory->create()
                ->skipAllChecks()
                ->addStoreFilter($this->_helper->isAdmin()?$this->_backendQuoteSession->getStoreId():$this->_helper->getCurrentStoreId())
                ->addFieldToFilter('is_active', 1)
                ->setAddedIds($bundleIdsAdded)
                ->appendSelections(false);

        //we try to add at least one of each added bundles
        
        foreach($bundleIdsAdded as $bundleId) {
            foreach ($bundleCollection as $bundle) {
                if($bundle->getId() == $bundleId) {
                    if($this->_checkBundle($quote, $bundle, $quoteItems, 1)) {
                        $bundleIdsMatched[] = $bundle->getId();
                    } else {
                        $idx = array_search($bundle->getId(), $bundleIdsAdded);
                        if($idx !== false) {
                            unset($bundleIdsAdded[$idx]);
                        }
                    }
                }
            }
        }
        
        
        //we check for the rest
        foreach ($bundleCollection as $bundle) {
            do {
                $bundle->setHasMultipleMatches(false);
                $bundleMatched = $this->_checkBundle($quote, $bundle, $quoteItems);
                if($bundleMatched) {
                    $bundleIdsMatched[] = $bundle->getId();
                }
            } while($bundle->getHasMultipleMatches());
        }
        
        
        
        $address->setSbundleDiscountAmount($this->_simpleBundleAmount);
        $address->setBaseSbundleDiscountAmount($this->_baseSimpleBundleAmount);
        $address->setSbundleDiscountTax($this->_simpleBundleTaxAmount);
        $address->setBaseSbundleDiscountTax($this->_baseSimpleBundleTaxAmount);

        $quote->setSbundleDiscountAmount($this->_simpleBundleAmount);
        $quote->setBaseSbundleDiscountAmount($this->_baseSimpleBundleAmount);
        $quote->setSbundleDiscountTax($this->_simpleBundleTaxAmount);
        $quote->setBaseSbundleDiscountTax($this->_baseSimpleBundleTaxAmount);
        
        
        
        
        $bundleIdsMatched = array_unique($bundleIdsMatched);
        $bundleIdsMatched = array_filter($bundleIdsMatched);
        //refresh bundle added
        $this->getSession()->setSimpleBundleIds($bundleIdsAdded);
        $this->getSession()->setSimpleBundleMatchedIds($bundleIdsMatched);
        $address->setSimpleBundleIds(implode(',', $bundleIdsMatched));
       
        return $this;
    }
    
    protected function _checkBundle($quote, $bundle, $quoteItems, $maxMachedQty=false) {
        $baseProductMatched = 0;
        $baseProductItem = null;
        $baseQty = $bundle->getBaseQty();

        //Check if base product matches
        foreach ($quoteItems as $quoteItem) {
            if ($quoteItem->getProductId() == $bundle->getProductId()) {
                $baseProductMatchedTemp = floor(($quoteItem->getQty() - $quoteItem->getUsedInSimpleBundle()) / ($baseQty<=0?1:$baseQty));
                if($baseProductMatchedTemp && $baseProductMatched) {
                    $bundle->setHasMultipleMatches(true);
                } else {
                    $baseProductMatched = $baseProductMatchedTemp;
                    $baseProductItem = $quoteItem;
                }
            }
        }

        if ($baseProductMatched <= 0) {
            $bundle->setHasMultipleMatches(false);
            return false; // base Product is not in cart, so we stop here
        }

        //Check if selections matches
        $selectionMatches = [];
        $selectionPrices = [];
        $selectionMatch = true;
        foreach ($bundle->getBundleItems() as $selection) {
            $selectionProductMatched = 0;
            foreach ($quoteItems as $quoteItem) {
                if($selectionProductMatched) {
                    continue;
                }
                if ($quoteItem->getProductId() == $selection->getProductId()) {

                    $selectionProductMatched = floor(($quoteItem->getQty() - $quoteItem->getUsedInSimpleBundle()) / $selection->getSelectionQty());
                    if ($selectionProductMatched > 0) {
                        $selectionPrices[] = [
                            'item' => $quoteItem,
                            'selection_qty' => $selection->getSelectionQty()
                        ];
                    }
                }
            }
            if ($selectionProductMatched <= 0) {
                $selectionMatch = false; // a selection Product is not in cart, so we stop here
            }
            $selectionMatches[] = $selectionProductMatched;
        }

        if (!$selectionMatch) {
            $bundle->setHasMultipleMatches(false);
            return false;
        }


        $selectionMatches[] = $baseProductMatched;
        $bundleMatchedQty = min($selectionMatches);
        if($maxMachedQty && $maxMachedQty < $bundleMatchedQty) {
            $bundleMatchedQty = $maxMachedQty;
        }

        if (!$bundle->getExcludeBaseProductFromDiscount()) {
            $selectionPrices[] = [
                'item' => $baseProductItem,
                'selection_qty' => $bundle->getBaseQty()
            ];
        } else {
            $baseProductItem->setUsedInSimpleBundle($baseProductItem->getUsedInSimpleBundle() + $bundle->getBaseQty() * $bundleMatchedQty);
            $simpleBundleIds = explode(',', $baseProductItem->getSimpleBundleIds());
            $simpleBundleIds[] = $bundle->getId();
            $simpleBundleIds = array_unique(array_filter($simpleBundleIds));
            $baseProductItem->setSimpleBundleIds(implode(',', $simpleBundleIds));
        }

        $originalAmount = 0;
        if($bundle->getExcludeBaseProductFromDiscount()) {
            $originalAmount += ($this->_getQuoteItemPrice($baseProductItem, true) * $bundle->getBaseQty());
        }
        foreach ($selectionPrices as $selection) {
            $quoteItem = $selection['item'];
            $originalAmount += ($this->_getQuoteItemPrice($quoteItem, true) * $selection['selection_qty']);
        }



        $percentDiscount = $bundle->getDiscountPercentageValue(10, $originalAmount) / 100;
        $baseValueDiscount = $bundle->getDiscountAmountValue();
        $valueDiscount =  $this->_priceCurrency->convert($baseValueDiscount);
        
        


        $bundleDiscountAmount = 0;
        $bundleBaseDiscountAmount = 0;
        $bundleDiscountTaxAmount = 0;
        $bundleBaseDiscountTaxAmount = 0;

        foreach ($selectionPrices as $idx => $selection) {
            //Mark applyed redeem
            $quoteItem = $selection['item'];
            $quoteItem->setUsedInSimpleBundle($quoteItem->getUsedInSimpleBundle() + $selection['selection_qty'] * $bundleMatchedQty);
            $simpleBundleIds = explode(',', $quoteItem->getSimpleBundleIds());
            $simpleBundleIds[] = $bundle->getId();
            $simpleBundleIds = array_unique(array_filter($simpleBundleIds));
            $quoteItem->setSimpleBundleIds(implode(',', $simpleBundleIds));
            $quoteItem->setSimpleBundlePercentDiscount($percentDiscount);

            //caculate total discount
            $itemPrice = $this->_getQuoteItemPrice($quoteItem);//$quoteItem->getPriceInclTax();
            $baseItemPrice = $this->_getQuoteItemPrice($quoteItem, true);//$quoteItem->getBasePriceInclTax();
             
            if(floatval($quoteItem->getWeeeTaxAppliedAmount()) > 0 && !$this->_helper->getStoreConfigFlag('simplebundle/general/apply_discount_on_weee')) {
                $itemPrice -= $quoteItem->getWeeeTaxAppliedAmount();
                $baseItemPrice -= $quoteItem->getBaseWeeeTaxAppliedAmount();
            } 

            $itemDiscountAmount = $this->_priceCurrency->round($itemPrice * $selection['selection_qty'] * $bundleMatchedQty * $percentDiscount);
            $itemBaseDiscountAmount = $this->_priceCurrency->round($baseItemPrice * $selection['selection_qty'] * $bundleMatchedQty * $percentDiscount);

            
            if($idx == count($selectionPrices)-1 && abs($bundleDiscountAmount + $itemDiscountAmount - $valueDiscount) > 0 ) {
                $roundingAdjustment = $this->_priceCurrency->round($valueDiscount- ($bundleDiscountAmount + $itemDiscountAmount));
                if(abs($roundingAdjustment) > 1) {
                    //todo Should never happen. there is an error somewhere. Log ? Exception ?
                } else {
                    $itemDiscountAmount += $roundingAdjustment;
                }
                $baseRoundingAdjustment = $this->_priceCurrency->round($baseValueDiscount- ($bundleBaseDiscountAmount + $itemBaseDiscountAmount));
                if(abs($baseRoundingAdjustment) > 1) {
                    //todo Should never happen. there is an error somewhere. Log ? Exception ?
                } else {
                    $itemBaseDiscountAmount += $baseRoundingAdjustment;
                }
            }
       
            
            $quoteItem->setSimpleBundleDiscountAmount($quoteItem->getSimpleBundleDiscountAmount() + $itemDiscountAmount);
            $quoteItem->setBaseSimpleBundleDiscountAmount($quoteItem->getBaseSimpleBundleDiscountAmount() + $itemBaseDiscountAmount);

            

            $bundleDiscountAmount += $itemDiscountAmount;
            $bundleBaseDiscountAmount += $itemBaseDiscountAmount;
            

            $quoteItemsToParse = [];
            if ($quoteItem->getProductType() == 'bundle') {
                foreach ($quoteItems as $quoteItem2) {
                    if ($quoteItem2->getParentItemId() == $quoteItem->getId()) {
                        $ratioBasePrice = $quoteItem2->getBasePrice() != 0 ? $quoteItem->getBasePrice() / $quoteItem2->getBasePrice() : 0;
                        $ratioPrice = $quoteItem2->getPrice() != 0 ? $quoteItem->getPrice() / $quoteItem2->getPrice() : 0;
                        if($ratioPrice==0) {
                            $ratioPrice = 1;
                        }
                        if($ratioBasePrice==0) {
                            $ratioBasePrice = 1;
                        }
                        $quoteItem2->setSimpleBundleDiscountAmount($quoteItem2->getSimpleBundleDiscountAmount() + $quoteItem2->getQty()*$quoteItem->getSimpleBundleDiscountAmount()/$ratioPrice);
                        $quoteItem2->setBaseSimpleBundleDiscountAmount($quoteItem2->getBaseSimpleBundleDiscountAmount() + $quoteItem2->getQty()*$quoteItem->getBaseSimpleBundleDiscountAmount()/$ratioBasePrice);
                        $quoteItemClone = clone $quoteItem2;
                        $quoteItemClone->setQty($quoteItemClone->getQty() * $quoteItem->getQty());
                        $quoteItemsToParse[] = $quoteItemClone;
                    }
                }
            } else {
                $quoteItemsToParse = [$quoteItem];
            }

            foreach ($quoteItemsToParse as $quoteItemToParse) {
                $taxPercent = floatval($quoteItemToParse->getTaxPercent());
                if (!isset($this->_simpleBundleTaxDetails[$taxPercent])) {
                    $this->_simpleBundleTaxDetails[$taxPercent] = 0;
                }
                if (!isset($this->_baseSimpleBundleTaxDetails[$taxPercent])) {
                    $this->_baseSimpleBundleTaxDetails[$taxPercent] = 0;
                }

                $itemTaxAmount = $quoteItemToParse->getTaxAmount() + $quoteItemToParse->getHiddenTaxAmount();
                $baseItemTaxAmount = $quoteItemToParse->getBaseTaxAmount() + $quoteItemToParse->getBaseHiddenTaxAmount();
                $itemDiscountTaxAmount = (($itemTaxAmount / $quoteItemToParse->getQty()) * $selection['selection_qty'] * $bundleMatchedQty * $percentDiscount);
                $baseItemDiscountTaxAmount = (($baseItemTaxAmount / $quoteItemToParse->getQty()) * $selection['selection_qty'] * $bundleMatchedQty * $percentDiscount);

                $this->_simpleBundleTaxDetails[$taxPercent] += $itemDiscountTaxAmount;
                $this->_baseSimpleBundleTaxDetails[$taxPercent] += $baseItemDiscountTaxAmount;
                
                foreach ($quoteItems as $quoteItem2) {
                    if($quoteItem2->getProductId() == $quoteItemToParse->getProductId()) {
                        $quoteItem2->setSimpleBundleDiscountTaxAmount($quoteItem2->getSimpleBundleDiscountTaxAmount() + $itemDiscountTaxAmount);
                        $quoteItem2->setBaseSimpleBundleDiscountTaxAmount($quoteItem2->getBaseSimpleBundleDiscountTaxAmount() + $baseItemDiscountTaxAmount);
                    }
                }
                
                if ($quoteItem->getProductType() == 'bundle' && $quoteItemToParse->getParentItemId() == $quoteItem->getId()) {
                    $quoteItem->setSimpleBundleDiscountTaxAmount($quoteItem->getSimpleBundleDiscountTaxAmount() + $itemDiscountTaxAmount);
                }
               
                $bundleDiscountTaxAmount += $itemDiscountTaxAmount;
                $bundleBaseDiscountTaxAmount += $baseItemDiscountTaxAmount;
            }

        }
        
        $this->_baseSimpleBundleAmount += $this->_priceCurrency->round($bundleBaseDiscountAmount);
        $this->_simpleBundleAmount += $this->_priceCurrency->round($bundleDiscountAmount);
        $this->_baseSimpleBundleTaxAmount += $this->_priceCurrency->round($bundleBaseDiscountTaxAmount);
        $this->_simpleBundleTaxAmount += $this->_priceCurrency->round($bundleDiscountTaxAmount);
        return true;
    }
    
    protected function _getQuoteItemPrice($quoteItem, $base = false) {
       if($base) {
           return floatval($quoteItem->getPriceInclTax() ? $quoteItem->getPriceInclTax() : $quoteItem->getPrice() + $quoteItem->getTaxAmount());
       }
       return floatval($quoteItem->getBasePriceInclTax() ? $quoteItem->getBasePriceInclTax() : $quoteItem->getBasePrice() + $quoteItem->getBaseTaxAmount());
    }
    
    
    
    
    
    
    
    
    

}
