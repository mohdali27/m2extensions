<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */
namespace Webcooking\SimpleBundle\Model\Product;

use Webcooking\SimpleBundle\Api\BundleRepositoryInterface as BundleRepository;
use Magento\Framework\EntityManager\Operation\ExtensionInterface;

/**
 * Class ReadHandler
 */
class ReadHandler implements ExtensionInterface
{
    /**
     * @var BundleRepository
     */
    private $bundleRepository;

    /**
     * ReadHandler constructor.
     *
     * @param BundleRepository $bundleRepository
     */
    public function __construct(BundleRepository $bundleRepository)
    {
        $this->bundleRepository = $bundleRepository;
    }

    /**
     * @param object $entity
     * @param array $arguments
     * @return \Magento\Catalog\Api\Data\ProductInterface
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function execute($entity, $arguments = [])
    {
        $simpleBundles = $this->bundleRepository->getListByProduct($entity);
        $entityExtension = $entity->getExtensionAttributes();
        //$entity->setSimplebundles($simpleBundles->getItems());
        $entityExtension->setSimplebundles($simpleBundles->getItems());
        $entity->setExtensionAttributes($entityExtension);
        return $entity;
    }
}
