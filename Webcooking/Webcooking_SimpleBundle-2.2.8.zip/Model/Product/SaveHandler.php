<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */
namespace Webcooking\SimpleBundle\Model\Product;


use Webcooking\SimpleBundle\Api\BundleRepositoryInterface as BundleRepository;
use Webcooking\SimpleBundle\Model\BundleFactory as BundleFactory;
use Webcooking\SimpleBundle\Model\BundleItemFactory as BundleItemFactory;
use Magento\Framework\EntityManager\Operation\ExtensionInterface;

/**
 * Class SaveHandler
 */
class SaveHandler implements ExtensionInterface
{
    /**
     * @var BundleRepository
     */
    protected $bundleRepository;
    protected $bundleFactory;

    /**
     * @param BundleRepository $bundleRepository
     */
    public function __construct(
        BundleRepository $bundleRepository,
        BundleFactory $bundleFactory
    ) {
        $this->bundleRepository = $bundleRepository;
        $this->bundleFactory = $bundleFactory;
    }

    /**
     * @param object $entity
     * @param array $arguments
     * @return \Magento\Catalog\Api\Data\ProductInterface|object
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function execute($entity, $arguments = [])
    {
        $simpleBundles = $entity->getExtensionAttributes()->getSimplebundles();
        if ($entity->getCopyFromView()) {
            return $entity;
        }
        $updatedBundles = [];
        if(is_array($simpleBundles)) {
            $oldBundles = $this->bundleRepository->getListByProduct($entity);
            foreach($simpleBundles as $simpleBundleData) {
                if(is_object($simpleBundleData)) {
                    $simpleBundle = $simpleBundleData;
                } else {
                    $simpleBundleData['product_id'] = $entity->getId();
                    $simpleBundle = $this->bundleFactory->create()->setData($simpleBundleData);
                }
                if(!$simpleBundle->getSimpleBundleId()) {
                    $simpleBundle->setSimpleBundleId(null);
                    $simpleBundle->setProductId($entity->getId());
                } else {
                    $updatedBundles[$simpleBundle->getSimpleBundleId()] = true;
                }
                if($simpleBundle->getData('delete') == 1) {
                    /* deprecated - not working anymore in 2.2.x */
                    $this->bundleRepository->delete($simpleBundle);
                } elseif($simpleBundle->getDiscountAmount() > 0 || $simpleBundle->getTemplateId()) {
                    $this->bundleRepository->save($simpleBundle);
                    $updatedBundles[$simpleBundle->getSimpleBundleId()] = true;
                }
            }
            
            foreach ($oldBundles as $oldBundle) {
                if (!isset($updatedBundles[$oldBundle->getSimpleBundleId()])) {
                     $this->bundleRepository->delete($oldBundle);
                }
            }
        }
        
        return $entity;
    }

}
