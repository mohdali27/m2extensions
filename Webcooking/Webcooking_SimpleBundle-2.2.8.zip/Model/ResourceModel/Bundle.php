<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Model\ResourceModel;

class Bundle extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{

    protected function _construct() {
        $this->_init('simple_bundle', 'simple_bundle_id');
    }

}
