<?php

/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Model\ResourceModel\Bundle;

use Webcooking\SimpleBundle\Api\Data\BundleInterface as BundleInterface;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    protected $_helper;
    protected $_helperAttribute;
    protected $_skipSalableCheck = false;
    protected $_skipPromoCheck = false;

    public function __construct(
            \Magento\Framework\Data\Collection\EntityFactoryInterface $entityFactory,
            \Psr\Log\LoggerInterface $logger,
            \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
            \Magento\Framework\Event\ManagerInterface $eventManager,
            \Webcooking\SimpleBundle\Helper\Data $helper,
            \Webcooking\All\Helper\Attribute $helperAttribute,
            \Magento\Framework\DB\Adapter\AdapterInterface $connection = null,
            \Magento\Framework\Model\ResourceModel\Db\AbstractDb $resource = null
    ) {
        $this->_helper = $helper;
        $this->_helperAttribute = $helperAttribute;
        parent::__construct(
                $entityFactory, $logger, $fetchStrategy, $eventManager,
                $connection, $resource
        );
    }

    /**
     * @var string
     */
    protected $_idFieldName = 'simple_bundle_id';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('Webcooking\SimpleBundle\Model\Bundle',
                'Webcooking\SimpleBundle\Model\ResourceModel\Bundle');
        $this->setOrder('position', 'ASC');
    }

    public function addStoreFilter($storeId) {
        $this->addFieldToFilter('store_ids',
                [
            ['finset' => $storeId],
            ['finset' => 0]
                ]
        );

        //$this->getSelect()->where('FIND_IN_SET('.$storeId.', store_ids) or FIND_IN_SET(0, store_ids)');
        return $this;
    }

    public function addEnabledFilter() {
        $this->getSelect()->where('is_active = ?', 1);
        return $this;
    }

    public function skipSalableCheck() {
        $this->_skipSalableCheck = true;
        return $this;
    }

    public function skipPromoCheck() {
        $this->_skipPromoCheck = true;
        return $this;
    }

    public function skipAllChecks() {
        return $this
                        ->skipPromoCheck()
                        ->skipSalableCheck();
    }

    public function addProductIdsFilter($productsIds) {
        if (empty($productsIds))
            return $this;
        $this->addFieldToFilter('product_id', $productsIds);
        return $this;
    }

    public function joinMasterProduct() {
        $productNameAttributeId = $this->_helperAttribute->getAttribute('name')->getId();

        $this->getSelect()
                ->joinLeft(
                        ['sku_table' => $this->getTable('catalog_product_entity')],
                        'sku_table.entity_id=product_id', ['sku' => 'sku']
        );

        $this->getSelect()
                ->joinLeft(
                        ['name_table' => $this->getTable('catalog_product_entity_varchar')],
                        'name_table.entity_id=product_id and name_table.attribute_id = ' . $productNameAttributeId,
                        ['name' => 'value']
        );

        $this->getSelect()->group('simple_bundle_id');
        return $this;
    }

    public function getSize() {
        if (is_null($this->_totalRecords)) {
            $sql = $this->getSelectCountSql();

            $result = $this->getConnection()->fetchAll($sql, $this->_bindParams);


            foreach ($result as $row) {
                $this->_totalRecords += reset($row);
            }
        }
        return intval($this->_totalRecords);
    }

    public function appendSelections($withAttributes = true) {
        $withAttributes = !$this->_skipSalableCheck || $withAttributes;
        $bundleToRemove = [];
        foreach ($this as $bundle) {

            $bundleIsValidated = true;

            $bundle->loadBundleItems($withAttributes);
            if (!$this->_skipPromoCheck) {
                if ($bundle->getSpecialPriceBehavior() == BundleInterface::SPECIAL_PRICE_BEHAVIOR_DISABLE && $bundle->hasSpecialPrice()) {
                    $bundleIsValidated = false;
                }
            }

            if ($bundleIsValidated && !$this->_skipSalableCheck) {
                $bundleIsValidated = $bundle->isSalable();
            }

            if (!$bundleIsValidated) {
                $bundleToRemove[] = $bundle->getId();
            }
        }


        foreach ($bundleToRemove as $unsaleableBundle) {
            $this->removeItemByKey($unsaleableBundle);
        }

        return $this;
    }

    public function setAddedIds($bundleIds) {
        if ($this->_helper->getStoreConfig('simplebundle/general/always_discount')) {
            if (empty($bundleIds)) {
                return $this;
            }
            $this->unshiftOrder(new \Zend_Db_Expr('IF(simple_bundle_id in (' . implode(',',
                            $bundleIds) . '),1,0)'), 'DESC');
        } else {
            $this->addFieldToFilter('simple_bundle_id',
                    ['in' => $bundleIds]);
        }
        return $this;
    }

}
