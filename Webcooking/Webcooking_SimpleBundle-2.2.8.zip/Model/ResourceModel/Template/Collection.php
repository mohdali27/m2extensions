<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Model\ResourceModel\Template;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

     protected $_helper;
     public function __construct(
        \Magento\Framework\Data\Collection\EntityFactoryInterface $entityFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Webcooking\SimpleBundle\Helper\Data $helper,
        \Magento\Framework\DB\Adapter\AdapterInterface $connection = null,
        \Magento\Framework\Model\ResourceModel\Db\AbstractDb $resource = null
    ){
        $this->_helper = $helper;
        parent::__construct(
                $entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource
        );
    }
    
    /**
     * @var string
     */
    protected $_idFieldName = 'template_id';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('Webcooking\SimpleBundle\Model\Template',
                'Webcooking\SimpleBundle\Model\ResourceModel\Template');
    }
    
    public function addStoreFilter($storeId) {
        $this->getSelect()->where('FIND_IN_SET('.$storeId.', store_ids) or FIND_IN_SET(0, store_ids)');
        return $this;
    }

    public function addEnabledFilter() {
        $this->getSelect()->where('is_active = ?', 1);
        return $this;
    }


}
