<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Model;

use Webcooking\SimpleBundle\Api\Data\TemplateInterface;

class Template extends \Webcooking\All\Model\Rule implements TemplateInterface
{

    protected $_templateItemCollectionFactory;
    protected $_productFactory;
    protected $_productCollectionFactory;
    protected $_bundleCollectionFactory;
    protected $_bundleItemCollectionFactory;
    protected $_bundleFactory;
    protected $_bundleItemFactory;
    protected $_helper;
    protected $_sbCondCombineFactory;
    protected $_selectionsLoaded = false;
    protected $_selectionProducts = null;
    protected $_bundleUpdateFields = [
        'is_active' => 'is_active',
        'store_ids' => 'store_ids',
        'position' => 'position',
        'discount_amount' => 'discount_amount',
        'discount_type' => 'discount_type',
        'base_qty' => 'base_qty',
        'exclude_base_product_from_discount' => 'exclude_base_product_from_discount',
        'special_price_behavior' => 'special_price_behavior',
        'bundle_name' => 'bundle_name'];
    protected $_itemUpdateFields = ['product_id', 'selection_qty', 'position'];
    protected $_rule = null;
    
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Webcooking\All\Model\ResourceModel\Catalog\Product\CollectionFactory $productCollectionFactory,
        \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory,
        \Webcooking\SimpleBundle\Model\ResourceModel\Template $resource,
        \Webcooking\SimpleBundle\Model\ResourceModel\TemplateItem\CollectionFactory $itemCollectionFactory,
        \Webcooking\SimpleBundle\Model\ResourceModel\Bundle\CollectionFactory $bundleCollectionFactory,
        \Webcooking\SimpleBundle\Model\ResourceModel\BundleItem\CollectionFactory $bundleItemCollectionFactory,
        \Webcooking\SimpleBundle\Model\BundleFactory $bundleFactory,
        \Webcooking\SimpleBundle\Model\BundleItemFactory $bundleItemFactory,
        \Webcooking\All\Model\Rule\Condition\CombineFactory $condCombineFactory,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \Webcooking\SimpleBundle\Model\TemplateRule\Condition\CombineFactory $sbCondCombineFactory,
        \Webcooking\SimpleBundle\Helper\Data $helper,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->_templateItemCollectionFactory = $itemCollectionFactory;
        $this->_productFactory = $productFactory;
        $this->_bundleFactory = $bundleFactory;
        $this->_bundleItemFactory = $bundleItemFactory;
        $this->_bundleCollectionFactory = $bundleCollectionFactory;
        $this->_bundleItemCollectionFactory = $bundleItemCollectionFactory;
        $this->_sbCondCombineFactory = $sbCondCombineFactory;
        $this->_helper = $helper;
        parent::__construct(
            $context,
            $registry,
            $formFactory,
            $dateFactory,
            $condCombineFactory,
            $localeDate,
            $resource,
            $resourceCollection,
            $data
        );
    }
    
    protected function _construct() {
        $this->_init('Webcooking\SimpleBundle\Model\ResourceModel\Template');
    }


    public function getBaseQty() {
        return $this->getData(self::BASE_QTY);
    }

    public function getBundleName() {
        return $this->getData(self::BUNDLE_NAME);
    }

    public function getConditionsSerialized() {
        return $this->getData(self::CONDITIONS_SERIALIZED);
    }

    public function getCreatedAt() {
        return $this->getData(self::CREATED_AT);
    }

    public function getDiscountAmount() {
        return $this->getData(self::DISCOUNT_AMOUNT);
    }

    public function getDiscountType() {
        return $this->getData(self::DISCOUNT_TYPE);
    }

    public function getExcludeBaseProductFromDiscount() {
        return $this->getData(self::EXCLUDE_BASE_PRODUCT_FROM_DISCOUNT);
    }

    public function getId() {
        return $this->getData(self::TEMPLATE_ID);
    }

    public function getIsActive() {
        return $this->getData(self::IS_ACTIVE);
    }

    public function getPosition() {
        return $this->getData(self::POSITION);
    }

    public function getRuleStatus() {
        return $this->getData(self::RULE_STATUS);
    }

    public function getSpecialPriceBehavior() {
        return $this->getData(self::SPECIAL_PRICE_BEHAVIOR);
    }

    public function getStoreIds() {
        return $this->getData(self::STORE_IDS);
    }

    public function getTemplateName() {
        return $this->getData(self::TEMPLATE_NAME);
    }

    public function getUpdatedAt() {
        return $this->getData(self::UPDATED_AT);
    }

    public function setBaseQty($qty) {
        return $this->setData(self::BASE_QTY, $qty);
    }

    public function setBundleName($name) {
        return $this->setData(self::BUNDLE_NAME, $name);
    }

    public function setConditionsSerialized($conditionsSerialized) {
        return $this->setData(self::CONDITIONS_SERIALIZED, $conditionsSerialized);
    }

    public function setDiscountAmount($discountAmount) {
        return $this->setData(self::DISCOUNT_AMOUNT, $discountAmount);
    }

    public function setDiscountType($discountType) {
        return $this->setData(self::DISCOUNT_TYPE, $discountType);
    }

    public function setExcludeBaseProductFromDiscount($flag) {
        return $this->setData(self::EXCLUDE_BASE_PRODUCT_FROM_DISCOUNT, $flag);
    }

    public function setId($id) {
        return $this->setData(self::TEMPLATE_ID, $id);
    }

    public function setIsActive($flag) {
        return $this->setData(self::IS_ACTIVE, $flag);
    }

    public function setPosition($position) {
        return $this->setData(self::POSITION, $position);
    }

    public function setRuleStatus($ruleStatus) {
        return $this->setData(self::RULE_STATUS, $ruleStatus);
    }

    public function setSpecialPriceBehavior($specialPriceBehavior) {
        return $this->setData(self::SPECIAL_PRICE_BEHAVIOR, $specialPriceBehavior);
    }

    public function setStoreIds($storeIds) {
        return $this->setData(self::STORE_IDS, $storeIds);
    }

    public function setTemplateName($name) {
        return $this->setData(self::TEMPLATE_NAME, $name);
    }
    
    
    public function getTemplateSelections() {
        return $this->getTemplateItems();
    }
    
    public function getTemplateItems() {
        if(!$this->_selectionsLoaded) {
            $this->loadTemplateItems();
        }
        return $this->getData('template_items');
    }
    
    public function clearTemplateItems() {
        $this->_selectionsLoaded = false;
        return $this;
    }
    
    public function loadTemplateItems($withAttributes = true) {
        if ($this->_selectionsLoaded) {
            return;
        }
        $templateItemCollection = $this->_templateItemCollectionFactory->create();
        $templateItemCollection->addFieldToFilter('template_id', $this->getId());
        $templateItemCollection->setOrder('position', 'ASC');
        if ($withAttributes) {
            foreach ($templateItemCollection as $item) {
                $product = $this->_productFactory->create()->load($item->getProductId(), ['name', 'sku', 'small_image', 'short_description', 'price', 'special_price', 'special_from_date', 'special_to_date']);
                $item->setName($product->getName());
                $item->setSku($product->getSku());
                $item->setSmallImage($product->getSmallImage());
                $item->setIsSalable($product->isSaleable());
                $item->setPrice($product->getPrice());
                $item->setFinalPrice($product->getFinalPrice());
            }
        }

        $this->setTemplateItems($templateItemCollection);

        $this->_selectionsLoaded = true;
    }
    
    public function generateSlaveProductsInfo() {
        $items = $this->getTemplateItems();
        $infos = [];
        foreach($items as $item) {
            $infos[] = __('%1 / %2 / Qty : %3', $item->getSku(), $item->getName(), intval($item->getSelectionQty()));
        }
        $this->setSlaveProductsInfo( implode(' | ', $infos) );
        return $this;
    }
    
    public function getAssignProducts() {
        $bundleCollection = $this->_bundleCollectionFactory->create();
        $bundleCollection->addFieldToFilter('template_id', $this->getId());
        $productIds = [];
        foreach($bundleCollection as $bundle) {
            $productIds[$bundle->getProductId()] = [];
        }
        return $productIds;
    }
    
    public function beforeSave() {
        $this->generateSlaveProductsInfo();
        return parent::beforeSave();
    }
    
    public function afterSave()
    {
        $this->updateLinkedBundles();
        return parent::afterSave();
    }
    
    public function updateLinkedBundles() {
        $isSelectionMode = false;
        if ($this->getData('template_products')) {
            $isSelectionMode = true;
            $selectedProducts = is_array($this->getData('template_products')) ? $this->getData('template_products') : json_decode($this->getData('template_products'), true);
            
            $bundleCollection = $this->_bundleCollectionFactory->create();
            $bundleCollection->addFieldToFilter('template_id', $this->getId());
            $bundleCollection->load();
            foreach ($selectedProducts as $productId=>$dummy) {
                if(!$productId || !is_int($productId)) {
                    continue;
                }
                $bundleExist = false;
                foreach ($bundleCollection as $bundle) {
                    if ($bundle->getProductId() == $productId) {
                        $bundleExist = true;
                    }
                }
                if (!$bundleExist) {
                    $bundle = $this->_bundleFactory->create();
                    $bundle->setProductId($productId);
                    $bundle->setTemplateId($this->getId());
                    $bundle->save();
                }
            }
        }
        $bundleCollection = $this->_bundleCollectionFactory->create();
        $bundleCollection->addFieldToFilter('template_id', $this->getId());
        foreach ($bundleCollection as $bundle) {
            if ($isSelectionMode && !isset($selectedProducts[$bundle->getProductId()])) {
                $bundle->delete();
            } else {
                $this->updateBundle($bundle);
            }
        }
    }


    public function getProductCollectionMatchingRule($addHasTemplate=false, $productCollection = false) {
        if(!$productCollection) {
            $productCollection = $this->_productCollectionFactory->create();;
        }
        $this->applyConditionToProductCollection($productCollection);
        if($addHasTemplate) {
            $productCollection->getSelect()
                ->joinLeft(
                        array('sb' => $productCollection->getTable('simple_bundle')),
                        'sb.product_id = e.entity_id and sb.template_id = ' . intval($this->getId()),
                        array('has_template'=>new \Zend_Db_Expr('if(template_id, 1, 0)'))
                );
        }
        return $productCollection;
    }

    
    public function applyRule() {
        $matchedProductIds = [];
        $productCollection = $this->getProductCollectionMatchingRule(true);
        //$productCollection->getSelect()->where('sb.template_id IS NULL');
        foreach($productCollection as $product) {
            $matchedProductIds[] = $product->getId();
            if(!$product->getHasTemplate()) {
                $bundle = $this->_bundleFactory->create();
                $bundle->setProductId($product->getId());
                $bundle->setTemplateId($this->getId());
                $bundle->setGeneratedByRule(1);
                $bundle->save();
            }
        }
        
        
        // Delete products that no longer match the rule 
        $bundleCollection = $this->_bundleCollectionFactory->create();
        $bundleCollection->addFieldToFilter('template_id', $this->getId());
        $bundleCollection->addFieldToFilter('generated_by_rule', 1);
        $bundleCollection->addFieldToFilter('product_id', array('nin'=>$matchedProductIds));
        $bundleCollection->walk('delete');
        
    }
    
    public function updateBundle(\Webcooking\SimpleBundle\Model\Bundle $bundle) {
        if (!$this->getId()) {
            return;
        }
        $shouldSaveBundle = false;
        foreach ($this->_bundleUpdateFields as $templateField => $bundleField) {
            $bundle->setData($bundleField, $this->getData($templateField));
            if ($bundle->dataHasChangedFor($bundleField)) {
                $shouldSaveBundle = true;
            }
        }
        $bundleItemCollection = $this->_bundleItemCollectionFactory->create();
        $bundleItemCollection->addFieldToFilter('simple_bundle_id', $bundle->getId());
        $bundleItems = [];
        foreach ($bundleItemCollection as $bundleItem) {
            $key = $this->_getItemKey($bundleItem);
            $bundleItems[$key] = $bundleItem;
        }
        $templateItemcollection = $this->_templateItemCollectionFactory->create();
        $templateItemcollection->addFieldToFilter('template_id', $this->getId());
        foreach ($templateItemcollection as $templateItem) {
            $key = $this->_getItemKey($templateItem);
            if($templateItem->getProductId() == $bundle->getProductId()) {
                $bundle->setBaseQty($bundle->getBaseQty() + $templateItem->getSelectionQty());
                $bundle->save();
                if (isset($bundleItems[$key])) {
                    $bundleItems[$key]->delete();
                }
                continue;
            }
            if (isset($bundleItems[$key])) {
                //update item
                foreach ($this->_itemUpdateFields as $field) {
                    $bundleItems[$key]->setData($field, $templateItem->getData($field));
                    if ($bundleItems[$key]->dataHasChangedFor($field)) {
                        $bundleItems[$key]->setShouldSave(true);
                    }
                }
                $bundleItems[$key]->setFoundInTemplate(true);
            } else {
                $newBundleItem = $this->_bundleItemFactory->create();
                $newBundleItem->setSimpleBundleId($bundle->getId());
                $newBundleItem->setProductId($templateItem->getProductId());
                $newBundleItem->setSelectionQty($templateItem->getSelectionQty());
                $newBundleItem->setPosition($templateItem->getPosition());
                $newBundleItem->setShouldSave(true);
                $newBundleItem->setFoundInTemplate(true);
                $key = $this->_getItemKey($templateItem);
                $bundleItems[$key] = $newBundleItem;
            }
        }
        foreach ($bundleItems as $bundleItem) {
            if ($bundleItem->getShouldSave()) {
                $bundleItem->save();
                $shouldSaveBundle = true;
            } else if (!$bundleItem->getFoundInTemplate()) {
                $bundleItem->delete();
                $shouldSaveBundle = true;
            }
        }
        
        if ($shouldSaveBundle) {
            $bundle->setOrigData('template_id', $bundle->getTemplateId());
            $bundle->save();
        }
    }
    
    protected function _getItemKey($item) {
        $key = '';
        foreach ($this->_itemUpdateFields as $field) {
            $key .= $item->getData($field) . '%%';
        }
        return $key;
    }
    
       public function getConditionsInstance()
    {
        return $this->_sbCondCombineFactory->create();
    }
    
    
    public function getActionsInstance()
    {
        return $this->_sbCondCombineFactory->create();
    }

}
