<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Model;

use Webcooking\SimpleBundle\Api\Data\TemplateItemInterface;
use Webcooking\All\Model\AbstractModel;

class TemplateItem extends AbstractModel implements TemplateItemInterface
{

    protected $_productFactory;
    protected $_templateFactory;
    protected $_product = null;
    protected $_template = null;
    
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory,
        \Webcooking\SimpleBundle\Model\ResourceModel\TemplateItem $resource,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Webcooking\SimpleBundle\Model\TemplateFactory $templateFactory,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->_productFactory = $productFactory;
        $this->_templateFactory = $templateFactory;
        parent::__construct(
            $context,
            $registry,
            $dateFactory,
            $resource,
            $resourceCollection,
            $data
        );
    }
    
    public function getId() {
        return $this->getData(self::TEMPLATE_ITEM_ID);
    }

    public function getPosition() {
        return $this->getData(self::POSITION);
    }

    public function getProductId() {
        return $this->getData(self::PRODUCT_ID);
    }

    public function getSelectionQty() {
        return $this->getData(self::SELECTION_QTY);
    }

    public function getTemplateId() {
        return $this->getData(self::TEMPLATE_ID);
    }

    public function setId($id) {
        return $this->setData(self::TEMPLATE_ITEM_ID, $id);
    }

    public function setPosition($position) {
        return $this->setData(self::POSITION, $position);
    }

    public function setProductId($productId) {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    public function setSelectionQty($qty) {
        return $this->setData(self::SELECTION_QTY, $qty);
    }

    public function setTemplateId($templateId) {
        return $this->setData(self::TEMPLATE_ID, $templateId);
    }

    public function getProduct() {
       if(is_null($this->_product)) {
           $this->_product = $this->_productFactory->create()->load($this->getProductId());
       }
       return $this->_product;
    }
    
    

    public function getTemplate() {
        if(is_null($this->_template)) {
           $this->_template = $this->_templateFactory->create()->load($this->getTemplateId());
       }
       return $this->_template;
    }
    
    
}
