<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Observer;

use Magento\Framework\Event\ObserverInterface;

class AdminhtmlBlockSalesruleActionsPrepareform implements ObserverInterface
{

    protected $_helper;
   
    public function __construct(\Webcooking\SimpleBundle\Helper\Data $helper) {
        $this->_helper = $helper; 
   }

    public function execute(\Magento\Framework\Event\Observer $observer) {
        return;
        //replaced by ui_components
        $form = $observer->getEvent()->getForm();
        $form->getElement('actions_fieldset')->addField('exclude_simple_bundle', 'select', [
            'label' => __('Exclude simple bundle items ?'),
            'title' => __('Exclude simple bundle items ?'),
            'name' => 'exclude_simple_bundle',
            'options' => [
                '1' => __('Yes'),
                '0' => __('No'),
            ],
        ], 'stop_rules_processing');
    }

}
