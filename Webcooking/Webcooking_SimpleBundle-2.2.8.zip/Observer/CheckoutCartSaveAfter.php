<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Observer;

use Magento\Framework\Event\ObserverInterface;

class CheckoutCartSaveAfter implements ObserverInterface
{

    protected $_helper;
   
    public function __construct(\Webcooking\SimpleBundle\Helper\Data $helper) {
        $this->_helper = $helper;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) {
        $cart = $observer->getEvent()->getCart();
        if($cart->getItemsCount() <= 0) {
            $this->_helper->getCheckoutSession()->setSimpleBundleIds(array());
        }
    }

}
