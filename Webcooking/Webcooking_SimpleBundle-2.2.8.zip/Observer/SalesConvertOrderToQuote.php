<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Observer;

use Magento\Framework\Event\ObserverInterface;

class SalesConvertOrderToQuote implements ObserverInterface
{

    protected $_helper;
    protected $_backendQuoteSession;
   
    public function __construct(
            \Webcooking\SimpleBundle\Helper\Data $helper,
            \Magento\Backend\Model\Session\Quote $backendQuoteSession) {
        $this->_helper = $helper;
        $this->_backendQuoteSession = $backendQuoteSession;
    }

    public function getSession() {
        if($this->_helper->isAdmin()) {
             return $this->_backendQuoteSession;
        }
        return $this->_helper->getCheckoutSession();
    }
    
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $order = $observer->getEvent()->getOrder();
        $quote = $observer->getEvent()->getQuote();
        $this->getSession()->setSimpleBundleIds($order->getSimpleBundleIds());
        $quote->setTotalsCollectedFlag(false)->collectTotals();
    }

}
