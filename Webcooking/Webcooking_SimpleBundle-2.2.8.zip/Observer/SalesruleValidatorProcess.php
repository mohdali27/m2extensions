<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Observer;

use Magento\Framework\Event\ObserverInterface;

class SalesruleValidatorProcess implements ObserverInterface
{

    protected $_helper;
    protected $_simpleBundleDiscount;
   
    public function __construct(\Webcooking\SimpleBundle\Helper\Data $helper,
                                \Webcooking\SimpleBundle\Model\Plugin\SalesRule\Quote\Discount $simpleBundleDiscount ) {
        $this->_helper = $helper;
        $this->_simpleBundleDiscount = $simpleBundleDiscount;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) {
        $rule = $observer->getEvent()->getRule();
        $item = $observer->getEvent()->getItem();
        $address = $observer->getEvent()->getAddress();
        $quote = $observer->getEvent()->getQuote();
        $qty = $observer->getEvent()->getQty();
        $result = $observer->getEvent()->getResult();
        $this->_manageExcludeSimpleBundleInShoppingcartRules($rule, $item, $address, $quote, $qty, $result);
        $this->_manageDiscountOnBundlePrice($rule, $item, $address, $quote, $qty, $result);
    }
    
    protected function _manageDiscountOnBundlePrice($rule, $item, $address, $quote, $qty, $result) {
        if (!$this->_helper->getStoreConfigFlag('simplebundle/general/apply_sales_rules_on_bundle_price')) {
            return;
        }
        if(!in_array($rule->getSimpleAction(), [\Magento\SalesRule\Model\Rule::TO_PERCENT_ACTION, \Magento\SalesRule\Model\Rule::BY_PERCENT_ACTION])) {
            return;
        }
        if ($item->getSimpleBundlePercentDiscount() && $item->getUsedInSimpleBundle() <= $qty) {
            $percent = $item->getSimpleBundlePercentDiscount();
            $discountAmount = $result->getAmount();
            $baseDiscountAmount = $result->getBaseAmount();
            
            $unitDiscountAmount = $discountAmount / $qty;
            $unitBaseDiscountAmount = $baseDiscountAmount / $qty;

            $discountAmount = $unitDiscountAmount * ($qty - $item->getUsedInSimpleBundle()); // normal discount
            $discountAmount += (($unitDiscountAmount - $unitDiscountAmount * $percent) * $item->getUsedInSimpleBundle()); //discount on simple bundle discount
            $baseDiscountAmount = $unitBaseDiscountAmount * ($qty - $item->getUsedInSimpleBundle()); // normal discount
            $baseDiscountAmount += (($unitBaseDiscountAmount - $unitBaseDiscountAmount * $percent) * $item->getUsedInSimpleBundle()); //discount on simple bundle discount

            $result->setAmount($discountAmount);
            $result->setBaseAmount($baseDiscountAmount);
        }
    }

    protected function _manageExcludeSimpleBundleInShoppingcartRules($rule, $item, $address, $quote, $qty, $result) {
        if (!$quote->getSimpleBundleProcessed()) {
            $this->_simpleBundleDiscount->processSimpleBundles($quote);
        }
        if ($rule->getExcludeSimpleBundle() && $item->getUsedInSimpleBundle()) {
            $qtyUsedInBundles = $item->getUsedInSimpleBundle();
            $result->setAmount(($result->getAmount() / $qty) * ($qty - $qtyUsedInBundles));
            $result->setBaseAmount(($result->getBaseAmount() / $qty) * ($qty - $qtyUsedInBundles));
        }
    }

}
