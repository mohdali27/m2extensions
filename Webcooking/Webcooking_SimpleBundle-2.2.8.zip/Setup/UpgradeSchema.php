<?php
/**
 * Copyright (c) 2011-2017 Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class UpgradeSchema implements UpgradeSchemaInterface
{

    /**
     * {@inheritdoc}
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '2.2.1', '<')) {
            $this->upgrade2_2_1($setup, $context);
        }
        $setup->endSetup();
    }

    public function upgrade2_2_1($setup, $context) {
        $salesruleTable = $setup->getTable('salesrule');
        $setup->getConnection()->addColumn($salesruleTable, 
                'exclude_simple_bundle',
                [
            'type' => \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
            'length' => '1',
            'default' => '0',
            'comment' => 'Exclude Simple Bundle from discount calculation',
        ]);
    }
}
