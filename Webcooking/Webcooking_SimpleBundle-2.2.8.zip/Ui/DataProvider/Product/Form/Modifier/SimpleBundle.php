<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */
namespace Webcooking\SimpleBundle\Ui\DataProvider\Product\Form\Modifier;

use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;
use Magento\Catalog\Model\Locator\LocatorInterface;
use Magento\Store\Model\System\Store;
use Magento\Framework\Phrase;
use Magento\Framework\UrlInterface;
use Magento\Framework\Stdlib\ArrayManager;
use Magento\Ui\Component\Modal;
use Magento\Ui\Component\Container;
use Magento\Ui\Component\DynamicRows;
use Magento\Ui\Component\Form\Fieldset;
use Magento\Ui\Component\Form\Field;
use Magento\Ui\Component\Form\Element\Input;
use Magento\Ui\Component\Form\Element\Select;
use Magento\Ui\Component\Form\Element\MultiSelect;
use Magento\Ui\Component\Form\Element\Type;
use Magento\Ui\Component\Form\Element\Checkbox;
use Magento\Ui\Component\Form\Element\ActionDelete;
use Magento\Ui\Component\Form\Element\DataType\Boolean;
use Magento\Ui\Component\Form\Element\DataType\Text;
use Magento\Ui\Component\Form\Element\DataType\Number;
use Magento\Ui\Component\Form\Element\DataType\Price;
use Magento\Framework\Locale\CurrencyInterface;
use Webcooking\SimpleBundle\Api\Data\BundleInterface;

/**
 * Class Bundle customizes Bundle product creation flow
 */
class SimpleBundle extends AbstractModifier
{
 
    /**#@+
     * Group values
     */
    const GROUP_SIMPLEBUNDLE_NAME = 'simplebundle';
    const GROUP_SIMPLEBUNDLE_SCOPE = AbstractModifier::DATA_SCOPE_PRODUCT;
    const GROUP_SIMPLEBUNDLE_PREVIOUS_NAME = 'search-engine-optimization';
    const GROUP_SIMPLEBUNDLE_DEFAULT_SORT_ORDER = 31;
    
    /**#@+
     * Container values
     */
    const CONTAINER_HEADER_NAME = 'container_header';
    const CONTAINER_SIMPLEBUNDLE = 'container_simplebundle';
    const CONTAINER_SIMPLEBUNDLE_SELECTIONS = 'container_simplebundle_selections';
    /**#@-*/
    
    /**#@+
     * Button values
     */
    const BUTTON_ADD = 'button_add';
    /**#@-*/
    
    /**#@+
     * Grid values
     */
    const GRID_BUNDLES_NAME = 'simplebundles';
    /**#@-*/
    
    
    /**#@+
     * Field values
     */
    const FIELD_IS_ACTIVE = BundleInterface::IS_ACTIVE;
    const FIELD_SIMPLEBUNDLE_ID = BundleInterface::SIMPLE_BUNDLE_ID;
    const FIELD_TEMPLATE = BundleInterface::TEMPLATE_ID;
    const FIELD_BUNDLE_NAME = BundleInterface::BUNDLE_NAME;
    const FIELD_DISCOUNT_AMOUNT = BundleInterface::DISCOUNT_AMOUNT;
    const FIELD_DISCOUNT_TYPE = BundleInterface::DISCOUNT_TYPE;
    const FIELD_SORT_ORDER = BundleInterface::POSITION;
    const FIELD_STORES = BundleInterface::STORE_IDS;
    const FIELD_BASE_QTY = BundleInterface::BASE_QTY;
    const FIELD_EXCLUDE_BASE_PRODUCT_FROM_DISCOUNT = BundleInterface::EXCLUDE_BASE_PRODUCT_FROM_DISCOUNT;
    const FIELD_SPECIAL_PRICE_BEHAVIOR = BundleInterface::SPECIAL_PRICE_BEHAVIOR;
    const FIELD_SIMPLEBUNDLE_SELECTIONS = 'simplebundle_selections';
    /**#@-*/
    
    
    /**#@+
     * Data values
     */
    const DATA_SCOPE_SELECTION = 'simplebundle_selections';
    /**#@-*/
    
    
    
    
    /**
     * @var LocatorInterface
     */
    protected $locator;

    /**
     * @var array
     */
    protected $modifiers = [];


    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;
    
    
    protected $_helper;
    
    protected $urlBuilder;
    
    
    protected $store;
    /**
     * @var array
     */
    protected $meta = [];

    /**
     * @param LocatorInterface $locator
     * @param StoreManagerInterface $storeManager
     * @param UrlInterface $urlBuilder
     * @param ArrayManager $arrayManager
     */
    public function __construct(
        LocatorInterface $locator,
        Store $store,
        \Webcooking\SimpleBundle\Helper\Data $helper,
        UrlInterface $urlBuilder,
        ArrayManager $arrayManager
    ) {
        $this->locator = $locator;
        $this->store = $store;
        $this->_helper = $helper;
        $this->urlBuilder = $urlBuilder;
        $this->arrayManager = $arrayManager;
    }

    /**
     * {@inheritdoc}
     */
    public function modifyMeta(array $meta)
    {
        $this->meta = $meta;

        $this->createSimpleBundlePanel();
        
        return $this->meta;
    }
    
    public function createSimpleBundlePanel() {
        
        $this->meta = array_replace_recursive(
            $this->meta,
                [self::GROUP_SIMPLEBUNDLE_NAME => [
                    'children' => [
                        'affect_simple_bundles' => [
                            'arguments' => [
                                'data' => [
                                    'config' => [
                                        'componentType' => Field::NAME,
                                        'dataType' => Text::NAME,
                                        'value' => 1,
                                        'formElement' => Input::NAME,
                                        'dataScope' => 'affect_simple_bundles',
                                        'visible' => false,
                                        'additionalClasses' => ['_hidden' => true],
                                        'sortOrder' => 0,
                                    ],
                                ],
                            ],
                        ],
                        'modal' => $this->getGenericModal(
                            __('Choose one or several selection to add to the bundle'),
                            static::DATA_SCOPE_SELECTION
                        ),
                       // static::DATA_SCOPE_SELECTION => $this->getGrid(static::DATA_SCOPE_SELECTION),
                        static::CONTAINER_HEADER_NAME => $this->getHeaderContainerConfig(10),
                        static::GRID_BUNDLES_NAME => $this->getBundlePanelsConfig(30),
                    ],
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'componentType' => Fieldset::NAME,
                                'component' => 'Webcooking_SimpleBundle/js/components/fieldset',
                                'label' => __('Simple Bundles'),
                                'collapsible' => true,
                                'dataScope' => '',
                                'sortOrder' => $this->getNextGroupSortOrder(
                                            $this->meta,
                                            static::GROUP_SIMPLEBUNDLE_PREVIOUS_NAME,
                                            static::GROUP_SIMPLEBUNDLE_DEFAULT_SORT_ORDER
                                        )
                            ]
                        ]
                    ]
                ]
            ]
        );
        
        
        return $this->meta;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function modifyData(array $data)
    {
        $bundles = [];
        $productSimpleBundles = $this->locator->getProduct()->getExtensionAttributes()->getSimplebundles() ?: [];

        /** @var \Webcooking\Simplebundle\Model\Bundle $bundle */
        foreach ($productSimpleBundles as $bundle) {
            $selections = [];
            foreach($bundle->getBundleItems() as $item) {
                
                $selections[] = [
                        'simple_bundle_item_id' => $item->getSimpleBundleItemId(),
                        'simple_bundle_id' => $item->getSimpleBundleId(),
                        'product_id' => $item->getProductId(),
                        'name' => $item->getName(),
                        'sku' => $item->getSku(),
                        'selection_qty' => $item->getSelectionQty(),
                        'position' => $item->getPosition(),
                        'delete' => '0',
                    ];
            }
            $bundleData = $bundle->getData();
            $bundleData['simplebundle_selections'] = $selections;
            $bundleData['delete'] = '0';
            $bundles[] = $bundleData;
        }
       
        return array_replace_recursive(
            $data,
            [
                $this->locator->getProduct()->getId() => [
                    static::GRID_BUNDLES_NAME => [
                            static::GRID_BUNDLES_NAME => $bundles
                    ],
                    'affect_simple_bundles' => 1
                ]
            ]
        );
    }
    
    
    /**
     * Get config for header container
     *
     * @param int $sortOrder
     * @return array
     */
    protected function getHeaderContainerConfig($sortOrder)
    {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'label' => null,
                        'formElement' => Container::NAME,
                        'componentType' => Container::NAME,
                        'template' => 'ui/form/components/complex',
                        'sortOrder' => $sortOrder,
                        'content' => __('Create, edit and delete simple bundles for this product.'),
                    ],
                ],
            ],
            'children' => [
                static::BUTTON_ADD => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'title' => __('Add Simple Bundle'),
                                'formElement' => Container::NAME,
                                'componentType' => Container::NAME,
                                'component' => 'Magento_Ui/js/form/components/button',
                                'sortOrder' => 20,
                                'actions' => [
                                    [
                                        'targetName' => 'ns = ${ $.ns }, index = ' . static::GRID_BUNDLES_NAME,
                                        'actionName' => 'processingAddChild',
                                    ]
                                ]
                            ]
                        ],
                    ],
                ],
            ],
        ];
    }
    
    
    protected function getBundlePanelsConfig($sortOrder)
    {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => DynamicRows::NAME,
                        'component' => 'Magento_Ui/js/dynamic-rows/dynamic-rows',
                        'template' => 'ui/dynamic-rows/templates/collapsible',
                        'additionalClasses' => 'admin__field-wide',
                        'deleteProperty' => 'delete',
                        'deleteValue' => '1',
                        'addButton' => false,
                        'renderDefaultRecord' => false,
                        'columnsHeader' => false,
                        'collapsibleHeader' => true,
                        'sortOrder' => $sortOrder,
                        //'source' => 'product',
                        'dataScope' => 'data.' . self::GRID_BUNDLES_NAME
                    ],
                ],
            ],
            'children' => [
                'record' => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'headerLabel' => __('Simple Bundle'),
                                'componentType' => Container::NAME,
                                'component' => 'Magento_Ui/js/dynamic-rows/record',
                                'positionProvider' => static::CONTAINER_SIMPLEBUNDLE . '.' . static::FIELD_SORT_ORDER,
                                'isTemplate' => true,
                                'is_collection' => true,
                                'imports' => [
                                    'label' => '${ $.name }' . '.container_simplebundle.simplebundle_info.bundle_name:value'
                                ],
                            ],
                        ],
                    ],
                    'children' => [
                        static::CONTAINER_SIMPLEBUNDLE => [
                            'arguments' => [
                                'data' => [
                                    'config' => [
                                        'componentType' => Fieldset::NAME,
                                        'component' => 'Webcooking_SimpleBundle/js/components/fieldset',
                                        'label' => null,
                                        'sortOrder' => 10,
                                        'opened' => true, 
                                    ],
                                ],
                            ],
                            'children' => [
                                'simplebundle_info' => $this->getSimpleBundleInfo(),
                                static::FIELD_SIMPLEBUNDLE_ID => $this->getIdFieldConfig(),
                                static::FIELD_SORT_ORDER => $this->getHiddenColumn('position', 1),
                                static::FIELD_SIMPLEBUNDLE_SELECTIONS => $this->getSimpleBundleSelectionsFieldConfig(900),
                                'delete' => $this->getHiddenColumn('delete', 40),
                                'modal_set' => $this->getModalSet()
                           ]
                        ],
                    ]
                ]
            ]
        ];
    }
    
    
    protected function getSimpleBundleInfo()
    {
        $result = [
            'arguments' => [
                'data' => [
                    'config' => [
                        'formElement' => 'container',
                        'componentType' => Container::NAME,
                        'component' => 'Magento_Ui/js/form/components/group',
                        'showLabel' => false,
                        'additionalClasses' => 'admin__field-group-columns admin__control-group-equal',
                        'breakLine' => true,
                        'sortOrder' => 10,
                    ],
                ],
            ],
            'children' => [
                static::FIELD_TEMPLATE => $this->getTemplateFieldConfig(10),
                static::FIELD_IS_ACTIVE => $this->getIsActiveFieldConfig(20),
                static::FIELD_BUNDLE_NAME => $this->getBundleNameFieldConfig(30),
                static::FIELD_DISCOUNT_AMOUNT => $this->getDiscountAmountFieldConfig(40),
                static::FIELD_DISCOUNT_TYPE => $this->getDiscountTypeFieldConfig(50),
                static::FIELD_STORES => $this->getStoresFieldConfig(60), 
                static::FIELD_BASE_QTY => $this->getBaseQtyFieldConfig(70), 
                static::FIELD_EXCLUDE_BASE_PRODUCT_FROM_DISCOUNT => $this->getExcludeBaseProductFromDiscountFieldConfig(80),
                static::FIELD_SPECIAL_PRICE_BEHAVIOR => $this->getSpecialPriceBehaviorFieldConfig(90),
            ],
        ];

        return $result;
    }
    
    
    
    protected function getModalSet()
    {
        $modalTarget = 'product_form.product_form.' . static::GROUP_SIMPLEBUNDLE_NAME  . '.modal';
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'sortOrder' => 999990,
                        'formElement' => 'container',
                        'componentType' => 'container',
                        'dataScope' => 'simplebundle_button_proxy',
                        'component' => 'Webcooking_SimpleBundle/js/simplebundle-proxy-button',
                        'provider' => 'product_form.product_form_data_source',
                        'listingDataProvider' => static::DATA_SCOPE_SELECTION.'_product_listing',
                        'actions' => [
                            [
                                'targetName' => $modalTarget,
                                'actionName' => 'toggleModal'
                            ],
                            [
                                'targetName' => $modalTarget . '.' . static::DATA_SCOPE_SELECTION.'_product_listing',
                                'actionName' => 'render'
                            ]
                        ],
                        'title' => __('Add Products to Simple Bundle'),
                    ],
                ],
            ],
        ];
    }
    
    protected function getIdFieldConfig() {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => Field::NAME,
                        'formElement' => Input::NAME,
                        'dataScope' => static::FIELD_SIMPLEBUNDLE_ID,
                        'dataType' => Number::NAME,
                        'visible' => false
                    ],
                ],
            ],
        ];
    }
    
    protected function getIsActiveFieldConfig($sortOrder) {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => Field::NAME,
                        'formElement' => Input::NAME,
                        'component' => 'Magento_Ui/js/form/element/single-checkbox',//ui-select',
                        'elementTmpl' => 'ui/form/element/switcher',//'ui/grid/filters/elements/ui-select',
                        'dataScope' => static::FIELD_IS_ACTIVE,
                        'dataType' => Number::NAME,
                        'visible' => true,
                        'label'    => __('Is active ?'),
                        'sortOrder' => $sortOrder,
                       /* 'options' => [
                            ['value' => 0, 'label' => __('No')],
                            ['value' => 1, 'label' => __('Yes')],
                        ],*/
                        'value' => 1,
                        'disableLabel' => true,
                        //'multiple' => false,
                        'validation' => [
                            'required-entry' => true
                        ],
                       /* 'imports' => [
                            'visbile' => '${$.provider}:${$.parentScope}.template_id'
                        ]*/
                    ],
                ],
            ],
        ];
    }
    
    protected function getTemplateFieldConfig($sortOrder) {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'label' => __('Template'),
                        'componentType' => Field::NAME,
                        'formElement' => Select::NAME,
                        'component' => 'Webcooking_SimpleBundle/js/simplebundle-template-select',
                        'elementTmpl' => 'ui/grid/filters/elements/ui-select',
                        'dataScope' => static::FIELD_TEMPLATE,
                        'dataType' => Text::NAME,
                        'sortOrder' => $sortOrder,
                        'options' => $this->_helper->getTemplateOptions(false),
                        'disableLabel' => true,
                        'multiple' => false,
                        'value' => '0',
                        'validation' => [
                            'required-entry' => false
                        ],
                    ],
                ],
            ],
        ];
    }
    
    protected function getBundleNameFieldConfig($sortOrder) {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => Field::NAME,
                        'formElement' => Input::NAME,
                        'dataScope' => static::FIELD_BUNDLE_NAME,
                        'dataType' => Number::NAME,
                        'visible' => true,
                        'label'    => __('Bundle name'),
                        'tooltip'  => [
                                        'description' => __('Leave empty to display products names.'),
                                      ],
                        'sortOrder' => $sortOrder,
                    ],
                ],
            ],
        ];
    }
    
    protected function getDiscountAmountFieldConfig($sortOrder) {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => Field::NAME,
                        'formElement' => Input::NAME,
                        'dataScope' => static::FIELD_DISCOUNT_AMOUNT,
                        'dataType' => Number::NAME,
                        'visible' => true,
                        'label'    => __('Discount amount'),
                        'sortOrder' => $sortOrder,
                        'validation' => [
                            'required-entry' => true,
                            'validate-zero-or-greater' => true
                        ],
                    ],
                ],
            ],
        ];
    }
    
    protected function getDiscountTypeFieldConfig($sortOrder) {
        $options = $this->_helper->getObject('Webcooking\SimpleBundle\Model\Config\Source\Bundle\DiscountType');
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'label' => __('Discount Type'),
                        'componentType' => Field::NAME,
                        'formElement' => Select::NAME,
                        'component' => 'Magento_Ui/js/form/element/ui-select',
                        'elementTmpl' => 'ui/grid/filters/elements/ui-select',
                        'dataScope' => static::FIELD_DISCOUNT_TYPE,
                        'dataType' => Text::NAME,
                        'sortOrder' => $sortOrder,
                        'options' => $options->toOptionArray(),
                        'value' => BundleInterface::DISCOUNT_TYPE_FIXED,
                        'disableLabel' => true,
                        'multiple' => false,
                        'validation' => [
                            'required-entry' => false
                        ]
                    ],
                ],
            ],
        ];
    }
    
    
    protected function getStoresFieldConfig($sortOrder) {
        $options = $this->_helper->getObject('Magento\Cms\Ui\Component\Listing\Column\Cms\Options');
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'label' => __('Stores'),
                        'componentType' => Field::NAME,
                        'formElement' => MultiSelect::NAME,
                        'dataScope' => static::FIELD_STORES,
                        'dataType' => Text::NAME,
                        'sortOrder' => $sortOrder,
                        'options' => $options->toOptionArray(),
                        'value' => '0',
                        'validation' => [
                            'required-entry' => false
                        ]
                    ],
                ],
            ],
        ];
    }
    
    
    protected function getBaseQtyFieldConfig($sortOrder)
    {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => Field::NAME,
                        'formElement'   => Input::NAME,
                        'dataScope'     => static::FIELD_BASE_QTY,
                        'dataType'      => Number::NAME,
                        'visible'       => true,
                        'label'         => __('Qty of base product'),
                        'value'         => 1,
                        'sortOrder'     => $sortOrder,
                    ],
                ],
            ],
        ];
    }
    
    protected function getExcludeBaseProductFromDiscountFieldConfig($sortOrder) {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => Field::NAME,
                        'formElement' => Input::NAME,
                        'component' => 'Magento_Ui/js/form/element/ui-select',
                        'elementTmpl' => 'ui/grid/filters/elements/ui-select',
                        'dataScope' => static::FIELD_EXCLUDE_BASE_PRODUCT_FROM_DISCOUNT,
                        'dataType' => Number::NAME,
                        'visible' => true,
                        'label'    => __('Exclude Base Product From Discount calculation ?'),
                        'sortOrder' => $sortOrder,
                        'options' => [
                            ['value' => '0', 'label' => __('No')],
                            ['value' => '1', 'label' => __('Yes')],
                        ],
                        'value' => '0',
                        'disableLabel' => true,
                        'multiple' => false,
                        'validation' => [
                            'required-entry' => true
                        ]
                    ],
                ],
            ],
        ];
    }
    
    protected function getSpecialPriceBehaviorFieldConfig($sortOrder) {
        $options = $this->_helper->getObject('Webcooking\SimpleBundle\Model\Config\Source\Bundle\SpecialPriceBehavior');
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'label' => __('Behavior when there is special price(s) within the bundle'),
                        'componentType' => Field::NAME,
                        'formElement' => Select::NAME,
                        'component' => 'Magento_Ui/js/form/element/ui-select',
                        'elementTmpl' => 'ui/grid/filters/elements/ui-select',
                        'dataScope' => static::FIELD_SPECIAL_PRICE_BEHAVIOR,
                        'dataType' => Text::NAME,
                        'sortOrder' => $sortOrder,
                        'options' => $options->toOptionArray(),
                        'value' => BundleInterface::SPECIAL_PRICE_BEHAVIOR_DISABLE,
                        'disableLabel' => true,
                        'multiple' => false,
                        'tooltip' => [
                            'description' => __("•‣ Use Lowest Price : Bundle price = lowest between (Regular prices - bundle discount) and (Special prices without any bundle discount)  •‣ Disable : Bundle will disappear if one of its product has special prices. •‣ Cumulate discounts : Bundle discount will be calculated on special prices.")
                        ],
                        'validation' => [
                            'required-entry' => false
                        ]
                    ],
                ],
            ],
        ];
    }
    
    
    public function getSimpleBundleSelectionsFieldConfig($sortOrder) {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => DynamicRows::NAME,
                        'label' => '',
                        'sortOrder' => $sortOrder,
                        'additionalClasses' => 'admin__field-wide',
                        'component' => 'Magento_Ui/js/dynamic-rows/dynamic-rows-grid',
                        'template' => 'ui/dynamic-rows/templates/default',
                        'columnsHeader' => false,
                        'columnsHeaderAfterRender' => true,
                        'deleteProperty' => 'delete',
                        'deleteValue' => '1',
                        'provider' => 'product_form.product_form_data_source',
                        'dataProvider' => '${ $.dataScope }' . '.simplebundle_button_proxy',
                        'identificationDRProperty' => 'product_id',
                        'identificationProperty' => 'product_id',
                        'map' => [
                            'simple_bundle_id' => '',
                            'simple_bundle_item_id' => '',
                            'product_id' => 'entity_id',
                            'name' => 'name',
                            'sku' => 'sku',
                            'price' => 'price',
                            'delete' => '0',
                            'selection_qty' => '',
                        ],
                        'links' => [
                            'insertData' => '${ $.provider }:${ $.dataProvider }'
                        ],
                        'source' => 'product',
                        'addButton' => false,
                    ],
                ],
            ],
            'children' => [
                'record' => $this->getBundleSelections(),
            ]
        ];
    }
    protected function getBundleSelections()
    {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => Container::NAME,
                        'isTemplate' => true,
                        'component' => 'Magento_Ui/js/dynamic-rows/record',
                        'is_collection' => true,
                    ],
                ],
            ],
            'children' => [
                'simple_bundle_item_id' => $this->getHiddenColumn('simple_bundle_item_id', 10),
                'simple_bundle_id' => $this->getHiddenColumn('simple_bundle_id', 20),
                'product_id' => $this->getHiddenColumn('product_id', 30),
                'delete' => $this->getHiddenColumn('delete', 40),
                'name' => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'componentType' => Field::NAME,
                                'dataType' => Text::NAME,
                                'formElement' => Input::NAME,
                                'elementTmpl' => 'ui/dynamic-rows/cells/text',
                                'label' => __('Name'),
                                'dataScope' => 'name',
                                'sortOrder' => 60,
                            ],
                        ],
                    ],
                ],
                'sku' => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'componentType' => Field::NAME,
                                'dataType' => Text::NAME,
                                'formElement' => Input::NAME,
                                'elementTmpl' => 'ui/dynamic-rows/cells/text',
                                'label' => __('SKU'),
                                'dataScope' => 'sku',
                                'sortOrder' => 70,
                            ],
                        ],
                    ],
                ],
                'selection_qty' => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'component' => 'Webcooking_SimpleBundle/js/components/bundle-option-qty',
                                'formElement' => Input::NAME,
                                'componentType' => Field::NAME,
                                'dataType' => Number::NAME,
                                'label' => __('Quantity'),
                                'dataScope' => 'selection_qty',
                                'value' => '1',
                                'sortOrder' => 100,
                                'validation' => [
                                    'required-entry' => true,
                                    'validate-zero-or-greater' => true
                                ],
                                'imports' => [
                                    'isInteger' => '${ $.provider }:${ $.parentScope }.selection_qty_is_integer'
                                ],
                            ],
                        ],
                    ],
                ],
                'position' => $this->getHiddenColumn('position', 120),
                'action_delete' => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'componentType' => 'actionDelete',
                                'dataType' => Text::NAME,
                                'label' => '',
                                'fit' => true,
                                'sortOrder' => 130,
                            ],
                        ],
                    ],
                ],
            ],
        ];
    }
    
    
    
    /**
     * Prepares config for modal slide-out panel
     *
     * @param Phrase $title
     * @param string $scope
     * @return array
     */
    protected function getGenericModal(Phrase $title, $scope)
    {
        $listingTarget = $scope . '_product_listing';

        $modal = [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => Modal::NAME,
                        'isTemplate' => false,
                        'provider' => 'product_form.product_form_data_source',
                        'dataScope' => '',
                        'options' => [
                            'title' => $title,
                            'buttons' => [
                                [
                                    'text' => __('Cancel'),
                                    'actions' => [
                                        'closeModal'
                                    ]
                                ],
                                [
                                    'text' => __('Add Selected Products'),
                                    'class' => 'action-primary',
                                    'actions' => [
                                        [
                                            'targetName' => 'index = ' . $listingTarget,
                                            'actionName' => 'save'
                                        ],
                                        'closeModal'
                                    ]
                                ],
                            ],
                        ],
                    ],
                ],
            ],
            'children' => [
                $listingTarget => [
                    'arguments' => [
                        'data' => [
                            'config' => [
                                'autoRender' => false,
                                'componentType' => 'insertListing',
                                'dataScope' => $listingTarget,
                                'externalProvider' => $listingTarget . '.' . $listingTarget . '_data_source',
                                'selectionsProvider' => $listingTarget . '.' . $listingTarget . '.product_columns.ids',
                                'ns' => $listingTarget,
                                'render_url' => $this->urlBuilder->getUrl('mui/index/render'),
                                'realTimeLink' => false,//true,
                                'dataLinks' => [
                                    'imports' => false,
                                    'exports' => true
                                ],
                                'behaviourType' => 'simple',
                                'externalFilterMode' => true,
                               /* 'imports' => [
                                    'productId' => '${ $.provider }:data.product.current_product_id',
                                    'storeId' => '${ $.provider }:data.product.current_store_id',
                                ],
                                'exports' => [
                                    'productId' => '${ $.externalProvider }:params.current_product_id',
                                    'storeId' => '${ $.externalProvider }:params.current_store_id',
                                ]*/
                            ],
                        ],
                    ],
                ],
            ],
        ];

        return $modal;
    }
    

    /**
     * Retrieve text column structure
     *
     * @param string $dataScope
     * @param bool $fit
     * @param Phrase $label
     * @param int $sortOrder
     * @return array
     */
    protected function getTextColumn($dataScope, $fit, Phrase $label, $sortOrder)
    {
        $column = [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => Field::NAME,
                        'formElement' => Input::NAME,
                        'elementTmpl' => 'ui/dynamic-rows/cells/text',
                        'component' => 'Magento_Ui/js/form/element/text',
                        'dataType' => Text::NAME,
                        'dataScope' => $dataScope,
                        'fit' => $fit,
                        'label' => $label,
                        'sortOrder' => $sortOrder,
                    ],
                ],
            ],
        ];

        return $column;
    }
    
    protected function getHiddenColumn($columnName, $sortOrder)
    {
        return [
            'arguments' => [
                'data' => [
                    'config' => [
                        'componentType' => Field::NAME,
                        'dataType' => Text::NAME,
                        'formElement' => Input::NAME,
                        'dataScope' => $columnName,
                        'visible' => false,
                        'additionalClasses' => ['_hidden' => true],
                        'sortOrder' => $sortOrder,
                    ],
                ],
            ],
        ];
    }
    
}
