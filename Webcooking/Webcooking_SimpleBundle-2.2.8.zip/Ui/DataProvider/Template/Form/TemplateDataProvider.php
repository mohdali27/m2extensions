<?php
/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

namespace Webcooking\SimpleBundle\Ui\DataProvider\Template\Form;

use Webcooking\SimpleBundle\Model\ResourceModel\Template\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;

/**
 * Class DataProvider
 */
class TemplateDataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var \Webcooking\SimpleBundle\Model\ResourceModel\Template\Collection
     */
    protected $collection;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var array
     */
    protected $loadedData;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $pageCollectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->meta = $this->prepareMeta($this->meta);
    }

    /**
     * Prepares Meta
     *
     * @param array $meta
     * @return array
     */
    public function prepareMeta(array $meta)
    {
        return $meta;
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        
        foreach ($items as $item) {
            $templateSelections = [];
            foreach($item->getTemplateItems() as $templateItem) {
                $templateSelections[] = [
                    'template_id' => $templateItem->getTemplateId(),
                    'template_item_id' => $templateItem->getId(),
                    'product_id' => $templateItem->getProductId(),
                    'name' => $templateItem->getName(),
                    'sku' => $templateItem->getSku(),
                    'price' => $templateItem->getPrice(),
                    'selection_qty' => $templateItem->getSelectionQty(),
                    'delete' => '',
                ];
            }
            $this->loadedData[$item->getId()]['template'] = $item->getData();
            $this->loadedData[$item->getId()]['template_selections'] = $templateSelections;
        }

        $data = $this->dataPersistor->get('simplebundle_template');
        if (!empty($data)) {
            $item = $this->collection->getNewEmptyItem();
            $item->setData($data);
            $this->loadedData[$item->getId()]['template'] = $item->getData();
            $this->loadedData[$item->getId()]['template_selections'] = [];
            $this->dataPersistor->clear('simplebundle_template');
        }

        return $this->loadedData;
    }
}
