/**
 * Copyright (c) 2011-2020 SAS WEB COOKING - Vincent René Lucien Enjalbert. All rights reserved.
 * See LICENSE-EN.txt for license details.
 */

define([
    'Magento_Ui/js/form/element/ui-select',
    'uiRegistry'
], function (Select, registry) {
    'use strict';

    return Select.extend({
        defaults: {
          filterPlaceholder: 'ns = ${ $.ns }, parentScope = ${ $.parentScope }',
          fieldsToToggle: ['bundle_name', 'is_active', 'discount_type', 'discount_amount', 'store_ids', 'base_qty', 'exclude_base_product_from_discount', 'special_price_behavior'],
        },
        initialize: function() {
            this._super();
            this.updateVisibility(this.getInitialValue());
            self = this;
            setTimeout(function(){//Todo for modal on pageload.... Ugly.
                self.updateVisibility(self.getInitialValue());
            }, 2000);
            return this;
        },
        onUpdate: function (currentValue) {
            this.updateVisibility(currentValue);
            this._super();
        },
        updateVisibility : function(value) {
            var visibleFlag = true;
            var selectionsComponent = registry.get('product_form.product_form.simplebundle.simplebundles.'+this.getIndex()+'.container_simplebundle.simplebundle_selections');
            var modalSetComponent = registry.get('product_form.product_form.simplebundle.simplebundles.'+this.getIndex()+'.container_simplebundle.modal_set');
            var components = [];
            if(selectionsComponent) {
                components.push(selectionsComponent);
            }
            if(modalSetComponent) {
                components.push(modalSetComponent);
            }
            for(var i=0; i<this.fieldsToToggle.length; i++) {
                components.push(this.filterPlaceholder + ', index=' + this.fieldsToToggle[i]);
            }
              
            if (value > 0) {
                visibleFlag = false;
            } else {
                visibleFlag = true;
            }
            
            for(var i=0; i<components.length; i++) {
                this.changeVisible(components[i], visibleFlag);
            }
           
            

        },
        changeVisible: function (filter, visible) {
            registry.async(filter)(
                function (currentComponent) {
                    currentComponent.visible(visible);
                }
            );
        },
        getIndex: function () {
            return this.dataScope.replace(new RegExp('[^0-9]', 'g'), '');
        }
    });
});
