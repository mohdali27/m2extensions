/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

/* global $, $H */

define([
    'mage/adminhtml/grid'
], function () {
    'use strict';

    return function (config) {
        var selectedProducts = config.selectedProducts,
            templateProducts = $H(selectedProducts),
            gridJsObject = window[config.gridJsObjectName],
            tabIndex = 1000;

        $('in_template_products').value = Object.toJSON(templateProducts);

        /**
         * Register Template Product
         *
         * @param {Object} grid
         * @param {Object} element
         * @param {Boolean} checked
         */
        function registerTemplateProduct(grid, element, checked) {
            if (checked) {
                    templateProducts.set(element.value, '');
            } else {
                templateProducts.unset(element.value);
            }
            $('in_template_products').value = Object.toJSON(templateProducts);
            grid.reloadParams = {
                'selected_products[]': templateProducts.keys()
            };
        }

        /**
         * Click on product row
         *
         * @param {Object} grid
         * @param {String} event
         */
        function templateProductRowClick(grid, event) {
            var trElement = Event.findElement(event, 'tr'),
                isInput = Event.element(event).tagName === 'INPUT',
                checked = false,
                checkbox = null;

            if (trElement) {
                checkbox = Element.getElementsBySelector(trElement, 'input');

                if (checkbox[0]) {
                    checked = isInput ? checkbox[0].checked : !checkbox[0].checked;
                    gridJsObject.setCheckboxChecked(checkbox[0], checked);
                }
            }
        }


        /**
         * Initialize template product row
         *
         * @param {Object} grid
         * @param {String} row
         */
        function templateProductRowInit(grid, row) {
            var checkbox = $(row).getElementsByClassName('checkbox')[0];
        }

        gridJsObject.rowClickCallback = templateProductRowClick;
        gridJsObject.initRowCallback = templateProductRowInit;
        gridJsObject.checkboxCheckCallback = registerTemplateProduct;

        if (gridJsObject.rows) {
            gridJsObject.rows.each(function (row) {
                templateProductRowInit(gridJsObject, row);
            });
        }
    };
});
