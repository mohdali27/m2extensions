define(['jquery', 'mage/translate'], function($) {
    return {
        
        openSimpleBundlePopup: function(popupUrl) {
            $.ajax({
                showLoader: true,
                url: popupUrl,
                data: {'form_key':$.cookie('form_key')},
                type: "POST",
                dataType: 'json'
            }).done(function (data) {
                if(data.success) {
                    sbundleContent = $('<div />').html(data.popup);
                    sbundleContent.modal({
                        title: $.mage.__('Some products of this bundle need configuration'),
                        autoOpen: true,
                        opened: function () {
                            // on open
                            sbundleContent.trigger('contentUpdated');
                        },
                        closed: function () {
                            // on close
                        },
                        buttons: [{
                            text: $.mage.__('Add to cart'),
                            'class': 'action-primary',
                            click: function() {
                                formValidate = true;
                                formsValues = [];
                                sbundleContent.find('form').each(function() {
                                    formElem = $(this);
                                    formElem.find('select.required, input.required, textarea.required').each(function() {
                                        inputElem = $(this);
                                        if (!inputElem.val()) {
                                            formValidate = false;
                                            inputElem.addClass('mage-error');
                                        } else {
                                            inputElem.removeClass('mage-error');
                                        }
                                    });
                                    formsValues.push(formElem.serialize());
                                    //console.log(formsValues);
                                });

                                if (formValidate) {
                                    addToCartUrl = sbundleContent.find('.sb-popup').data('simplebundle-addtocart-url');
                                    cartUrl = sbundleContent.find('.sb-popup').data('cart-url');
                                    $.ajax(
                                            {
                                                showLoader: true,
                                                url : addToCartUrl,
                                                type: 'POST',
                                                dataType: 'json',
                                                data: {'sbdata[]': formsValues, 'form_key':$.cookie('form_key')},
                                            }
                                    ).done(function(data){
                                        if(data.success) {
                                            window.location.href = cartUrl;
                                        } else {
                                            
                                        }
                                    });
                                } else {
                                    $('.modal-title').css({color:'#e02b27'});
                                }
                            }
                        }]
                     });
                     
                    
                 } else {
                     //TODO
                 }
            });
        }
    }
});