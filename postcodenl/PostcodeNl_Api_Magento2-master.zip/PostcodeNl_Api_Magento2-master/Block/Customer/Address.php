<?php

namespace Flekto\Postcode\Block\Customer;

class Address extends \Magento\Framework\View\Element\Template
{

}