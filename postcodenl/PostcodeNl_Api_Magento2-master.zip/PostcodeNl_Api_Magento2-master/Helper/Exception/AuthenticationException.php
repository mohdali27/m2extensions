<?php

namespace Flekto\Postcode\Helper\Exception;


class AuthenticationException extends ClientException
{

}