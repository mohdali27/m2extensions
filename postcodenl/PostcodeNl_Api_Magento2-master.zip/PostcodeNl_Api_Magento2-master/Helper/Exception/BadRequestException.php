<?php

namespace Flekto\Postcode\Helper\Exception;


class BadRequestException extends ClientException
{

}