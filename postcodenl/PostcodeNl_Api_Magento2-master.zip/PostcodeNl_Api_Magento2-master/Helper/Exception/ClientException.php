<?php

namespace Flekto\Postcode\Helper\Exception;


class ClientException extends \Exception
{

}