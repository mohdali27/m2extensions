<?php

namespace Flekto\Postcode\Helper\Exception;


class CurlException extends ClientException
{

}