<?php

namespace Flekto\Postcode\Helper\Exception;


class CurlNotLoadedException extends ClientException
{

}