<?php

namespace Flekto\Postcode\Helper\Exception;


class ForbiddenException extends ClientException
{

}