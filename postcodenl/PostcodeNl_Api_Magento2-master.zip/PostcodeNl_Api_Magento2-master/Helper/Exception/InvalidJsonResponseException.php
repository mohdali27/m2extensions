<?php

namespace Flekto\Postcode\Helper\Exception;


class InvalidJsonResponseException extends ClientException
{

}