<?php

namespace Flekto\Postcode\Helper\Exception;


class InvalidPostcodeException extends ClientException
{

}