<?php

namespace Flekto\Postcode\Helper\Exception;


class ServerUnavailableException extends ClientException
{

}