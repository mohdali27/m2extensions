<?php

namespace Flekto\Postcode\Helper\Exception;


class TooManyRequestsException extends ClientException
{

}