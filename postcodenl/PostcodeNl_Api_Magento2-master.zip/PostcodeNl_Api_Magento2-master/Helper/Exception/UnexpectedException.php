<?php

namespace Flekto\Postcode\Helper\Exception;


class UnexpectedException extends ClientException
{

}