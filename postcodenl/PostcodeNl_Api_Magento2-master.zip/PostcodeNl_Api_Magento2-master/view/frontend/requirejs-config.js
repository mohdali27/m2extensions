var config = {
    map: {
        '*': {
	        flekto_postcode: 'Flekto_Postcode/js/postcode_autofill'

        }
    }
    
};